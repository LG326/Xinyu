import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  // Keep the documented backend port as the default while allowing local
  // multi-instance verification without editing the proxy configuration.
  server: {
    host: '127.0.0.1',
    port: 5173,
    proxy: {
      '/api': process.env.XINYU_API_PROXY_TARGET || 'http://127.0.0.1:8000',
    },
  },
});
