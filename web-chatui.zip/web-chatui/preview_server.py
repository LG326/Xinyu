"""Serve the built frontend and proxy /api requests to the local FastAPI app."""

from __future__ import annotations

import argparse
import http.client
import os
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit


class PreviewHandler(SimpleHTTPRequestHandler):
    backend_host = "127.0.0.1"
    backend_port = 8000

    def do_GET(self) -> None:  # noqa: N802
        if self.path.startswith("/api/"):
            self.proxy_request()
            return
        super().do_GET()

    def do_POST(self) -> None:  # noqa: N802
        self.proxy_request()

    def do_PUT(self) -> None:  # noqa: N802
        self.proxy_request()

    def do_PATCH(self) -> None:  # noqa: N802
        self.proxy_request()

    def do_DELETE(self) -> None:  # noqa: N802
        self.proxy_request()

    def proxy_request(self) -> None:
        parsed = urlsplit(self.path)
        body = self.rfile.read(int(self.headers.get("Content-Length", "0")))
        headers = {
            key: value
            for key, value in self.headers.items()
            if key.lower() not in {"host", "connection", "content-length"}
        }
        connection = http.client.HTTPConnection(self.backend_host, self.backend_port, timeout=30)
        try:
            connection.request(self.command, parsed.path + (f"?{parsed.query}" if parsed.query else ""), body=body, headers=headers)
            response = connection.getresponse()
            payload = response.read()
            self.send_response(response.status, response.reason)
            for key, value in response.getheaders():
                if key.lower() not in {"connection", "transfer-encoding", "content-length"}:
                    self.send_header(key, value)
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
        except OSError as error:
            self.send_error(502, f"Backend unavailable: {error}")
        finally:
            connection.close()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=5173)
    parser.add_argument("--directory", default=os.path.join(os.path.dirname(__file__), "dist"))
    args = parser.parse_args()
    os.chdir(args.directory)
    server = ThreadingHTTPServer((args.host, args.port), PreviewHandler)
    print(f"Preview server listening on http://{args.host}:{args.port}/", flush=True)
    server.serve_forever()


if __name__ == "__main__":
    main()
