/**
 * 手帐本地存储。
 * 用户在手帐面板里写下的内容只保存在浏览器本地，不需要后端参与；
 * 打开手帐时再和后端已有的长期记忆合并成同一本手帐。
 * 同一条内容本地和后端都有时，只在手帐里显示一次。
 */

export interface JournalEntry {
  id: string;
  content: string;
  created_at: string;
}

const STORAGE_KEY = 'xinyu-journal-entries';
const CHANGE_EVENT = 'xinyu-journal-change';

function storageKey(scope = 'default'): string {
  return scope ? `${STORAGE_KEY}:${scope}` : STORAGE_KEY;
}

function read(scope = 'default'): JournalEntry[] {
  try {
    const parsed = JSON.parse(window.localStorage.getItem(storageKey(scope)) || '[]');
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter((entry) => entry && typeof entry.content === 'string' && entry.content.trim())
      .map((entry) => ({
        id: String(entry.id || `local-${Math.random().toString(36).slice(2)}`),
        content: String(entry.content).trim(),
        created_at: String(entry.created_at || new Date().toISOString()),
      }));
  } catch {
    return [];
  }
}

function persist(entries: JournalEntry[], scope = 'default') {
  try { window.localStorage.setItem(storageKey(scope), JSON.stringify(entries)); } catch { /* 存储不可用时只影响本地手帐 */ }
  window.dispatchEvent(new CustomEvent(CHANGE_EVENT));
}

export function loadJournalEntries(scope = 'default'): JournalEntry[] {
  return read(scope);
}

export function addJournalEntry(content: string, scope = 'default'): JournalEntry[] {
  const text = content.trim();
  if (!text) return read(scope);
  const entry: JournalEntry = {
    id: `local-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    content: text,
    created_at: new Date().toISOString(),
  };
  const next = [...read(scope), entry];
  persist(next, scope);
  return next;
}

export function updateJournalEntry(id: string, content: string, scope = 'default'): JournalEntry[] {
  const text = content.trim();
  const next = read(scope).map((entry) => (entry.id === id ? { ...entry, content: text } : entry));
  persist(next, scope);
  return next;
}

export function removeJournalEntry(id: string, scope = 'default'): JournalEntry[] {
  const next = read(scope).filter((entry) => entry.id !== id);
  persist(next, scope);
  return next;
}

export function subscribeJournal(listener: (entries: JournalEntry[]) => void, scope = 'default'): () => void {
  const handler = () => listener(read(scope));
  window.addEventListener(CHANGE_EVENT, handler);
  return () => window.removeEventListener(CHANGE_EVENT, handler);
}

/** 去掉「帮我记住：」这类口头前缀，让手帐里留下的是一条干净记录。 */
export function cleanJournalContent(text: string): string {
  return text.replace(/^(?:帮我记住|请记住)[：:，,\s]*/, '').trim();
}

/** 合并本地手帐与后端记忆时用来去重：忽略「用户」前缀、口头前缀和标点。 */
export function journalSignature(text: string): string {
  return cleanJournalContent(text).replace(/^用户/, '').replace(/[\s。！!，,、.；;：:？?]/g, '');
}
