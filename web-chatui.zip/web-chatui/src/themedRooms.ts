/**
 * 心屿 · 主题小屋
 *
 * 九间不同风格的房间，家具按聊天累积的亲密度逐件解锁。
 * 在家具布置页选中某间小屋时，小屋实景图会整张作为房间背景，
 * 点亮过的家具在图上挂出自己的名字，还没解锁的家具则标成「未解锁」。
 */
import { THEMED_ROOMS } from './themedRooms.generated';
import type { ThemedRoom } from './themedRooms.generated';

export type { ThemedFurniture, ThemedRoom } from './themedRooms.generated';
export { THEMED_ROOMS };

/** 房间 id -> 这间房里已经点亮的家具 key */
export type LitMap = Record<string, string[]>;

const LIT_KEY = 'xinyu-room-lit';
const PEAK_KEY = 'xinyu-themed-room-peak';

export function loadLitItems(scope = 'default'): LitMap {
  try {
    const raw = window.localStorage.getItem(`${LIT_KEY}:${scope}`);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as LitMap;
    if (!parsed || typeof parsed !== 'object') return {};
    const cleaned: LitMap = {};
    Object.entries(parsed).forEach(([roomId, keys]) => {
      if (Array.isArray(keys)) cleaned[roomId] = keys.filter((key): key is string => typeof key === 'string');
    });
    return cleaned;
  } catch {
    return {};
  }
}

export function saveLitItems(map: LitMap, scope = 'default'): void {
  try {
    window.localStorage.setItem(`${LIT_KEY}:${scope}`, JSON.stringify(map));
  } catch {
    /* 存储不可用时只影响下次打开 */
  }
}

/**
 * 亲密度用「历史最高值」判定解锁：领养旅伴会消耗亲密度，
 * 但已经解锁的家具不应该因此再锁回去。
 */
export function loadPeakIntimacy(current: number, scope = 'default'): number {
  try {
    const stored = Number(window.localStorage.getItem(`${PEAK_KEY}:${scope}`));
    const peak = Math.max(current, Number.isFinite(stored) ? stored : 0);
    if (peak !== stored) window.localStorage.setItem(`${PEAK_KEY}:${scope}`, String(peak));
    return peak;
  } catch {
    return current;
  }
}

export function isRoomUnlocked(room: ThemedRoom, intimacy: number): boolean {
  return intimacy >= room.unlock;
}

/** 测试用：直接给历史最高亲密度加值，用来一次性解锁家具 */
export function grantPeakIntimacy(delta: number, scope = 'default'): void {
  try {
    const stored = Number(window.localStorage.getItem(`${PEAK_KEY}:${scope}`));
    const base = Number.isFinite(stored) ? stored : 0;
    window.localStorage.setItem(`${PEAK_KEY}:${scope}`, String(base + delta));
  } catch {
    /* 存储不可用时忽略 */
  }
}

export function countUnlocked(room: ThemedRoom, intimacy: number): number {
  return room.items.filter((item) => intimacy >= item.intimacy).length;
}

export function generateRoomIntro(room: ThemedRoom, intimacy: number, alias: string): string {
  const unlocked = countUnlocked(room, intimacy);
  if (!isRoomUnlocked(room, intimacy)) {
    return `再和 ${alias} 聊 ${room.unlock - intimacy} 点亲密度，就能打开这间小屋`;
  }
  if (unlocked >= room.items.length) return '这间小屋的家具已经全部解锁，想点亮哪件就点哪件';
  return `已解锁 ${unlocked} / ${room.items.length} 件，继续陪聊还能添置更多`;
}
