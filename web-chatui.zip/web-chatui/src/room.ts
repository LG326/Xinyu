export type RoomFurnitureId = 'window' | 'sofa' | 'coffee' | 'bookshelf' | 'rug' | 'record' | 'lamp' | 'plant';
export type AccessoryId = 'leaf_hat' | 'moon_scarf' | 'daisy_pin' | 'star_glasses' | 'lantern_charm' | 'sleep_cap';

export interface FurnitureItem {
  id: RoomFurnitureId;
  name: string;
  icon: string;
  price: number;
  description: string;
  action: string;
}

export interface AccessoryItem {
  id: AccessoryId;
  name: string;
  description: string;
  accent: string;
  icon: string;
  slot: 'hat' | 'neck' | 'pin' | 'eyes' | 'charm';
}

export interface RoomState {
  starCoins: number;
  ownedFurniture: RoomFurnitureId[];
  activeFurniture: RoomFurnitureId;
  accessories: AccessoryId[];
  /** 手动拖动配饰后的位置偏移，按 `${speciesId}:${accessoryId}` 记录，单位是方形区域的百分比 */
  accessoryOffsets: Record<string, AccessoryOffset>;
  /** 房间换装：已摆放到画布上的家具，坐标是画布内的归一化值 */
  decor: PlacedDecor[];
  lastDailyClaim: string;
}

/** 一件已摆放的换装家具 */
export interface PlacedDecor {
  /** 所属主题房间 */
  roomId: string;
  key: string;
  x: number;
  y: number;
}

/** 配饰相对默认佩戴锚点的偏移量 */
export interface AccessoryOffset {
  dx: number;
  dy: number;
  /** 手动调整的大小倍率，未设置时为 1 */
  scale?: number;
}

export const DAILY_STARLIGHT_REWARD = 12;

export const ROOM_FURNITURE: FurnitureItem[] = [
  { id: 'window', name: '星光落地窗', icon: '✦', price: 0, description: '把今天的光留在房间里', action: '小屿站在窗边看星星' },
  { id: 'sofa', name: '软绵沙发', icon: '▰', price: 18, description: '适合坐下来读一会儿', action: '小屿坐在沙发上看书' },
  { id: 'coffee', name: '暖光咖啡机', icon: '☕', price: 26, description: '每一次靠岸都有热气', action: '小屿在咖啡机前泡咖啡' },
  { id: 'bookshelf', name: '漂浮书架', icon: '▤', price: 32, description: '收好你们聊过的故事', action: '小屿在书架前挑选书' },
  { id: 'rug', name: '云朵地毯', icon: '⌁', price: 12, description: '把房间变得更柔软', action: '小屿坐在地毯上整理唱片' },
  { id: 'record', name: '月光唱片机', icon: '◉', price: 24, description: '放一首今晚喜欢的歌', action: '小屿在唱片机旁听歌' },
  { id: 'lamp', name: '潮汐落地灯', icon: '♧', price: 20, description: '为晚归的人留一束光', action: '小屿在落地灯旁写日记' },
  { id: 'plant', name: '小小绿洲', icon: '♣', price: 16, description: '一起照顾一片新叶子', action: '小屿给绿植浇水' },
];

export const ACCESSORIES: AccessoryItem[] = [
  { id: 'leaf_hat', name: '苔叶小帽', description: '一顶轻巧的日常帽子', accent: '#7f9d82', icon: '🧢', slot: 'hat' },
  { id: 'moon_scarf', name: '月光围巾', description: '柔软的蓝色小围巾', accent: '#76aeb9', icon: '🧣', slot: 'neck' },
  { id: 'daisy_pin', name: '雏菊发夹', description: '别一朵小花在耳边', accent: '#e6b94c', icon: '🌼', slot: 'pin' },
  { id: 'star_glasses', name: '星星眼镜', description: '圆圆镜片里装着星光', accent: '#8d91b7', icon: '🤓', slot: 'eyes' },
  { id: 'lantern_charm', name: '灯笼挂坠', description: '系在身边的小小暖光', accent: '#e8a87c', icon: '🏮', slot: 'charm' },
  { id: 'sleep_cap', name: '晚安睡帽', description: '睡前戴上的软绵小帽', accent: '#d39b9c', icon: '🌙', slot: 'hat' },
];

const LEGACY_OUTFIT_ACCESSORY: Record<string, AccessoryId> = {
  island: 'leaf_hat',
  starlight: 'moon_scarf',
  mist: 'sleep_cap',
};

export const INITIAL_ROOM_STATE: RoomState = {
  starCoins: 24,
  ownedFurniture: ['window'],
  activeFurniture: 'window',
  accessories: [],
  accessoryOffsets: {},
  decor: [],
  lastDailyClaim: '',
};

/** 只保留坐标合法的已摆放家具，避免损坏的本地数据把家具甩出画布 */
function sanitizeDecor(raw: unknown): PlacedDecor[] {
  if (!Array.isArray(raw)) return [];
  return raw
    .filter((item): item is PlacedDecor => !!item && typeof (item as PlacedDecor).key === 'string')
    .map((item) => ({
      roomId: typeof item.roomId === 'string' && item.roomId ? item.roomId : 'cloud-star',
      key: String(item.key),
      x: Math.max(0, Math.min(1, Number(item.x) || 0)),
      y: Math.max(0, Math.min(1, Number(item.y) || 0)),
    }));
}

const MAX_ACCESSORY_OFFSET = 80;
const MIN_ACCESSORY_SCALE = 0.4;
const MAX_ACCESSORY_SCALE = 2;

/** 只保留合法且有限的偏移，避免损坏的本地数据把配饰甩出画面 */
function sanitizeOffsets(raw: unknown): Record<string, AccessoryOffset> {
  if (!raw || typeof raw !== 'object') return {};
  const result: Record<string, AccessoryOffset> = {};
  for (const [key, value] of Object.entries(raw as Record<string, unknown>)) {
    const source = value as Partial<AccessoryOffset> | null;
    const dx = Number(source?.dx);
    const dy = Number(source?.dy);
    if (!Number.isFinite(dx) || !Number.isFinite(dy)) continue;
    const entry: AccessoryOffset = {
      dx: Math.max(-MAX_ACCESSORY_OFFSET, Math.min(MAX_ACCESSORY_OFFSET, dx)),
      dy: Math.max(-MAX_ACCESSORY_OFFSET, Math.min(MAX_ACCESSORY_OFFSET, dy)),
    };
    const scale = Number(source?.scale);
    if (Number.isFinite(scale)) {
      entry.scale = Math.max(MIN_ACCESSORY_SCALE, Math.min(MAX_ACCESSORY_SCALE, scale));
    }
    result[key] = entry;
  }
  return result;
}

export function getLocalDateKey(date = new Date()): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getInitialRoomState(scope = 'default'): RoomState {
  try {
    const saved = window.localStorage.getItem(`xinyu-room-state:${scope}`);
    if (!saved) return INITIAL_ROOM_STATE;
    const parsed = JSON.parse(saved) as Partial<RoomState> & { outfit?: string };
    const ownedFurniture = Array.isArray(parsed.ownedFurniture)
      ? parsed.ownedFurniture.filter((id): id is RoomFurnitureId => ROOM_FURNITURE.some((item) => item.id === id))
      : INITIAL_ROOM_STATE.ownedFurniture;
    const activeFurniture = ROOM_FURNITURE.some((item) => item.id === parsed.activeFurniture) && ownedFurniture.includes(parsed.activeFurniture as RoomFurnitureId)
      ? parsed.activeFurniture as RoomFurnitureId
      : ownedFurniture[0] || 'window';
    const legacyAccessory = typeof parsed.outfit === 'string' ? LEGACY_OUTFIT_ACCESSORY[parsed.outfit] : undefined;
    const accessories = Array.isArray(parsed.accessories)
      ? [...new Set(parsed.accessories.filter((id): id is AccessoryId => ACCESSORIES.some((item) => item.id === id)))]
      : legacyAccessory
        ? [legacyAccessory]
        : [];
    return {
      starCoins: Number.isFinite(Number(parsed.starCoins)) ? Math.max(0, Number(parsed.starCoins)) : INITIAL_ROOM_STATE.starCoins,
      ownedFurniture: ownedFurniture.length ? ownedFurniture : ['window'],
      activeFurniture,
      accessories,
      accessoryOffsets: sanitizeOffsets((parsed as Partial<RoomState>).accessoryOffsets),
      decor: sanitizeDecor((parsed as Partial<RoomState>).decor),
      lastDailyClaim: typeof parsed.lastDailyClaim === 'string' ? parsed.lastDailyClaim : '',
    };
  } catch {
    return INITIAL_ROOM_STATE;
  }
}
