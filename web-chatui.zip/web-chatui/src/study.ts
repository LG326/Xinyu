/**
 * 心屿 · 自习室计时器与励志配图配置。
 *
 * 进入自习模式后按 timer_interval 定时轮换文案；配图由文案的 type 自动拼接提示词生成，
 * 图片本身不含文字，文案统一由前端叠加渲染，保证清晰、可读、可访问。
 */

export type SentenceType = 'poem' | 'quote';
export type ImageRatio = 'web' | 'mobile';

export interface StudySentence {
  id: number;
  content: string;
  type: SentenceType;
  suggestImageElement: string;
  /** 出处，有值时单独渲染在文案下方（例如「人民日报」） */
  source?: string;
}

export interface StudyPromptTemplate {
  positive_template: string;
  negative_prompt: string;
}

interface StudyConfig {
  image_ratio: Record<ImageRatio, string>;
  general_prefix: string;
  element_pool: { poem_elements: string[]; quote_elements: string[] };
  prompt_template: Record<SentenceType, StudyPromptTemplate>;
  sentence_library: StudySentence[];
  logic: {
    timer_interval: number;
    cache_image: boolean;
    user_switch: boolean;
    render_text: string;
  };
}

export const STUDY_CONFIG: StudyConfig = {
  image_ratio: { web: '16:9', mobile: '9:16' },
  general_prefix:
    '横向16:9，极简构图，留白充足，画面下方预留文字区域，柔和低饱和度配色，暗光护眼，柔和漫射光，高清细腻，无杂乱物体，无多余人物，氛围感安静专注，适合学习背景，干净不刺眼，8k，细节柔和，不要强烈阴影，不要高对比强光',
  element_pool: {
    poem_elements: ['远山', '孤竹', '寒梅', '一叶扁舟', '流云', '枯荷', '松枝', '空山', '小溪', '月影', '芦苇'],
    quote_elements: ['窗边微光', '摊开的书本', '星光', '薄雾海岸线', '落叶', '一盏台灯', '清晨薄雾', '漫射阳光'],
  },
  prompt_template: {
    poem: {
      positive_template:
        '横向16:9，极简构图，留白充足，画面下方预留文字区域，柔和低饱和度配色，暗光护眼，柔和漫射光，高清细腻，无杂乱物体，无多余人物，氛围感安静专注，适合学习背景，干净不刺眼，8k，细节柔和，不要强烈阴影，不要高对比强光，中国传统水墨画，写意山水，淡墨晕染，浅青灰、米白宣纸底色，宣纸肌理，毛笔笔触，{{element}},淡彩浅染，空灵悠远，意境沉静，古风雅致，东方美学，画面大量留白，不拥挤',
      negative_prompt:
        '鲜艳彩色，厚重油彩，3d渲染，写实照片，人脸，动物，文字，水印，边框，刺眼高光，杂乱元素，卡通，厚涂，浓墨重彩，高饱和度',
    },
    quote: {
      positive_template:
        '横向16:9，极简构图，留白充足，画面下方预留文字区域，柔和低饱和度配色，暗光护眼，柔和漫射光，高清细腻，无杂乱物体，无多余人物，氛围感安静专注，适合学习背景，干净不刺眼，8k，细节柔和，不要强烈阴影，不要高对比强光，简约肌理插画，哑光纸张质感，低饱和莫兰迪色系，柔和朦胧光影，{{element}},扁平肌理，低对比度，温柔安静，现代文艺感，画面大量留白',
      negative_prompt:
        '鲜艳色彩，3d，写实人像，杂乱物体，水印，边框，刺眼强光，卡通Q版，浓色彩，文字',
    },
  },
  sentence_library: [
    { id: 1, content: '千磨万击还坚劲，任尔东西南北风', type: 'poem', suggestImageElement: '青竹，山间薄雾' },
    { id: 2, content: '路漫漫其修远兮，吾将上下而求索', type: 'poem', suggestImageElement: '远山，孤行者，流云' },
    { id: 3, content: '长风破浪会有时，直挂云帆济沧海', type: 'poem', suggestImageElement: '江面，孤舟，远山云雾' },
    { id: 4, content: '宝剑锋从磨砺出，梅花香自苦寒来', type: 'poem', suggestImageElement: '寒梅，浅雪' },
    { id: 5, content: '你今天的努力，是幸运的伏笔', type: 'quote', suggestImageElement: '窗边微光，摊开的书本' },
    { id: 6, content: '星光不问赶路人，时光不负有心人', type: 'quote', suggestImageElement: '星光，安静书桌' },
    { id: 7, content: '所有看似幸运的背后，都是无人知晓的坚持', type: 'quote', suggestImageElement: '一盏台灯，薄雾' },
    { id: 8, content: '想，都是问题；做，才有答案', type: 'quote', source: '人民日报', suggestImageElement: '清晨微光，写满字的笔记本' },
    { id: 9, content: '慢也好，步子小也好，是在往前走就好', type: 'quote', suggestImageElement: '薄雾小径，向前延伸的路' },
    { id: 10, content: '看似不起眼的日复一日，终会看见坚持的意义', type: 'quote', suggestImageElement: '窗边台灯，叠起的书本' },
    { id: 11, content: '不必焦虑别人比你提前拥有，每个人花期不同', type: 'quote', suggestImageElement: '窗台花苞，柔和晨光' },
    { id: 12, content: '回头轻舟已过万重山，向前前路漫漫亦灿灿', type: 'quote', suggestImageElement: '江上轻舟，连绵远山' },
  ],
  logic: {
    timer_interval: 5,
    cache_image: true,
    user_switch: true,
    render_text: '前端渲染文案，AI绘图不生成文字',
  },
};

/** 文案轮换间隔，单位秒。 */
export const STUDY_INTERVAL_SECONDS = Math.max(1, STUDY_CONFIG.logic.timer_interval) * 60;

/** 文案与配图一一对应，直接复用配置里的句子库。 */
export const STUDY_SENTENCES: StudySentence[] = STUDY_CONFIG.sentence_library;

export const STUDY_IMAGE_ENDPOINT = 'https://trae-api-cn.mchost.guru/api/ide/v1/text_to_image';

const IMAGE_SIZE: Record<ImageRatio, string> = { web: 'landscape_16_9', mobile: 'portrait_16_9' };
const RATIO_PREFIX: Record<ImageRatio, string> = { web: '横向16:9', mobile: '竖向9:16' };
const CACHE_KEY = 'xinyu-study-image-cache';

/** 当前视口应该用哪种出图比例：窄屏走移动端 9:16。 */
export function pickImageRatio(): ImageRatio {
  if (typeof window === 'undefined') return 'web';
  return window.matchMedia('(max-width: 760px)').matches ? 'mobile' : 'web';
}

/** 句子自带建议元素时优先使用，否则从对应元素池中随机取一个。 */
export function pickStudyElement(sentence: StudySentence): string {
  if (sentence.suggestImageElement) return sentence.suggestImageElement;
  const pool = sentence.type === 'poem'
    ? STUDY_CONFIG.element_pool.poem_elements
    : STUDY_CONFIG.element_pool.quote_elements;
  return pool[Math.floor(Math.random() * pool.length)] ?? '';
}

/** 模板里的留白提示以「横向16:9」开头，移动端换成竖版，其余提示词保持不变。 */
function adaptRatioPrefix(template: string, ratio: ImageRatio): string {
  return template.replace(/^横向16:9/, RATIO_PREFIX[ratio]);
}

/** 按 type 拼接正向提示词，并把负向提示词作为「避免出现」追加，图片不生成任何文字。 */
export function buildStudyPrompt(sentence: StudySentence, element: string, ratio: ImageRatio): string {
  const template = STUDY_CONFIG.prompt_template[sentence.type];
  const positive = adaptRatioPrefix(template.positive_template, ratio).replace('{{element}}', element);
  return `${positive}。避免出现：${template.negative_prompt}`;
}

export function buildStudyImageUrl(prompt: string, ratio: ImageRatio): string {
  return `${STUDY_IMAGE_ENDPOINT}?prompt=${encodeURIComponent(prompt)}&image_size=${IMAGE_SIZE[ratio]}`;
}

type ImageCache = Record<string, string>;

let imageCache: ImageCache | null = null;

function readCache(): ImageCache {
  try {
    const raw = window.localStorage.getItem(CACHE_KEY);
    return raw ? (JSON.parse(raw) as ImageCache) : {};
  } catch {
    return {};
  }
}

/**
 * 取得该文案对应的背景图地址。同一句 + 同一比例只拼一次，
 * 并按配置写进 localStorage，刷新后不必重新出图。
 */
export function resolveStudyImage(sentence: StudySentence, element: string, ratio: ImageRatio): string {
  if (!imageCache) imageCache = readCache();
  const key = `${sentence.id}-${ratio}-${element}`;
  const cached = imageCache[key];
  if (cached) return cached;
  const url = buildStudyImageUrl(buildStudyPrompt(sentence, element, ratio), ratio);
  imageCache[key] = url;
  if (STUDY_CONFIG.logic.cache_image) {
    try {
      window.localStorage.setItem(CACHE_KEY, JSON.stringify(imageCache));
    } catch {
      /* localStorage 不可用时忽略，只影响下次打开 */
    }
  }
  return url;
}
