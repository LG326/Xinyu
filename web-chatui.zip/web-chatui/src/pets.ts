/**
 * 心屿 · 旅伴系统（旅行青蛙式玩法）
 *
 * 玩法链路：聊天赚好感度 → 用好感度领养旅伴 → 派遣旅伴去世界各地旅行
 *        → 旅途结束带回吉卜力风格的风景明信片和一句写给你的祝福。
 *
 * 和「小屿的房间」一样，状态保存在浏览器 localStorage，不需要后端改动；
 * 旅行进度用时间戳推算，所以关掉页面再打开也会继续走。
 */

export type PetSpeciesId = 'frog' | 'cat' | 'dog' | 'penguin' | 'parrot' | 'alpaca' | 'deer' | 'fox';

/** 明信片风景的构图类型，每种对应 PostcardArt 里的一套绘制逻辑 */
export type MotifId =
  | 'meadow' | 'village' | 'coast' | 'mountain' | 'aurora' | 'desert' | 'city'
  | 'forest' | 'terrace' | 'lake' | 'flower' | 'temple' | 'island' | 'canyon';

export type ContinentId = 'asia' | 'europe' | 'north-america' | 'south-america' | 'africa' | 'oceania';

export interface Continent {
  id: ContinentId;
  name: string;
}

export const CONTINENTS: Continent[] = [
  { id: 'asia', name: '亚洲' },
  { id: 'europe', name: '欧洲' },
  { id: 'north-america', name: '北美洲' },
  { id: 'south-america', name: '南美洲' },
  { id: 'africa', name: '非洲' },
  { id: 'oceania', name: '大洋洲' },
];

export interface PetSpecies {
  id: PetSpeciesId;
  name: string;
  /** 默认名字，领养时可以改 */
  defaultName: string;
  price: number;
  accent: string;
  intro: string;
}

export interface Destination {
  id: string;
  /** 简称：地图圆点与列表用 */
  name: string;
  /** 详细地点：明信片与卡片上展示的小镇 / 城市 */
  place: string;
  /** 国家或地区 */
  region: string;
  continent: ContinentId;
  /** 明信片左上角的英文地名 */
  label: string;
  /** 世界地图坐标（等距圆柱投影百分比） */
  x: number;
  y: number;
  /** 单程旅行分钟数 */
  minutes: number;
  motif: MotifId;
  /** 吉卜力配色：天空、远景、中景、地面 */
  palette: [string, string, string, string];
  /** 小众目的地：不是热门打卡地，人少、安静 */
  niche?: boolean;
  blessings: string[];
  /** 回家时的播报 */
  arrival: string;
}

export interface PetTrip {
  destinationId: string;
  departedAt: number;
  returnsAt: number;
}

export interface Pet {
  id: string;
  speciesId: PetSpeciesId;
  name: string;
  adoptedAt: number;
  trips: number;
  trip: PetTrip | null;
}

export interface Postcard {
  id: string;
  petId: string;
  petName: string;
  speciesId: PetSpeciesId;
  destinationId: string;
  createdAt: number;
  blessing: string;
  seed: number;
}

export interface PetState {
  bond: number;
  pets: Pet[];
  postcards: Postcard[];
  daily: { date: string; earned: number };
}

export const MAX_DAILY_BOND = 40;
export const CHAT_BOND_BASE = 2;
export const CHAT_BOND_BONUS = 2;
export const MAX_POSTCARDS = 60;

export const PET_SPECIES: PetSpecies[] = [
  { id: 'frog', name: '青蛙', defaultName: '小蛙', price: 0, accent: '#7fb069', intro: '免费旅伴 · 安静又爱看雨，背包里永远塞着一把小伞' },
  { id: 'cat', name: '猫咪', defaultName: '咪咪', price: 20, accent: '#e0a86a', intro: '喜欢窗台和晒太阳，行李里装了三本书' },
  { id: 'dog', name: '小狗', defaultName: '豆豆', price: 22, accent: '#d9a15b', intro: '热情又可靠，出门前会转三圈' },
  { id: 'penguin', name: '企鹅', defaultName: '团团', price: 30, accent: '#5b7c99', intro: '只在冷的地方精神好，喜欢冰和极光' },
  { id: 'parrot', name: '鹦鹉', defaultName: '啾啾', price: 36, accent: '#5fb0a5', intro: '一路都在学当地口音，回来会讲个不停' },
  { id: 'alpaca', name: '羊驼', defaultName: '毛毛', price: 48, accent: '#e6d3b3', intro: '毛很软，走路很慢，什么都想多看一眼' },
  { id: 'deer', name: '小鹿', defaultName: '点点', price: 40, accent: '#e6b98c', intro: '胆子小，容易被落叶吓一跳，却很愿意陪你坐着' },
  { id: 'fox', name: '狐狸', defaultName: '阿橘', price: 34, accent: '#e08a4a', intro: '好奇心最重，什么都要先闻一闻、看一看' },
];

export const DESTINATIONS: Destination[] = [
  // ── 欧洲 ────────────────────────────────────────────────
  {
    id: 'paris', name: '巴黎', place: '巴黎 · 塞纳河左岸', region: '法国', continent: 'europe', label: 'PARIS', x: 50.7, y: 22.9, minutes: 9, motif: 'city',
    palette: ['#cfe3f2', '#f2d9c2', '#c99a72', '#7f6a52'],
    blessings: ['{pet}在塞纳河边坐到天黑，替你看完了整场日落。愿你也总有一盏灯为你亮着。', '{pet}把面包屑分给了鸽子，它们围着它转了三圈。今天也要好好吃饭呀。'],
    arrival: '铁塔下的风里有烤面包的味道',
  },
  {
    id: 'provence', name: '普罗旺斯', place: '瓦朗索勒 · 薰衣草田', region: '法国', continent: 'europe', label: 'VALENSOLE', x: 51.7, y: 25.9, minutes: 9, motif: 'flower',
    palette: ['#d8e6f5', '#e6d6ef', '#a98cc4', '#7d9a68'],
    blessings: ['{pet}在花田里转了一整个下午，身上全是薰衣草的味道，说想把这味道寄给你。', '{pet}看见蜂群忙个不停，觉得大家都辛苦，就坐下来陪它们歇了一会儿。'],
    arrival: '信封里掉出几粒紫色花籽',
  },
  {
    id: 'colmar', name: '科尔马', place: '科尔马 · 小威尼斯运河', region: '法国', continent: 'europe', label: 'COLMAR', x: 52.0, y: 23.3, minutes: 8, motif: 'village',
    palette: ['#c9e0f2', '#f4dcc8', '#c07f63', '#6f8f66'],
    blessings: ['{pet}沿着运河走了很久，看每一扇彩色窗户，说像翻开了一本童话。', '{pet}在桥头买了一小块蛋糕，觉得还是没有你分给它的好吃。'],
    arrival: '带回一片小小的木屋瓦片',
  },
  {
    id: 'hallstatt', name: '哈尔施塔特', place: '哈尔施塔特 · 湖畔小镇', region: '奥地利', continent: 'europe', label: 'HALLSTATT', x: 53.8, y: 24.1, minutes: 9, motif: 'lake',
    palette: ['#cfe4f2', '#a9c6d8', '#8fae8c', '#4f6f66'],
    blessings: ['{pet}坐着小船漂在湖心，山的影子落在水里，它说安静原来也会发光。', '{pet}学会了当地的一句早安，清晨对着湖说了一遍，说那是给你的。'],
    arrival: '绒毛里有一点点湖水的凉',
  },
  {
    id: 'cinque', name: '五渔村', place: '马纳罗拉 · 悬崖渔村', region: '意大利', continent: 'europe', label: 'MANAROLA', x: 52.7, y: 25.6, minutes: 8, motif: 'coast',
    palette: ['#bfe0f5', '#f6e0c4', '#e0a273', '#4a7f8c'],
    blessings: ['{pet}数了悬崖上的彩房子，一共数十一次就睡着了，海风替它数完。', '{pet}看着渔船归港，说希望每个晚归的人都有饭香在等。'],
    arrival: '脚上沾着一点点海盐',
  },
  {
    id: 'rome', name: '罗马', place: '罗马 · 特雷维喷泉', region: '意大利', continent: 'europe', label: 'ROME', x: 53.5, y: 26.7, minutes: 8, motif: 'city',
    palette: ['#f6e3c8', '#eec9a4', '#c68f6e', '#7a6350'],
    blessings: ['{pet}在许愿池边投了一枚硬币，愿望里写的是你的名字。', '{pet}坐在台阶上吃完一整个冰淇淋，说夏天的味道就该是这样。'],
    arrival: '围巾上还留着柑橘香',
  },
  {
    id: 'prague', name: '布拉格', place: '布拉格 · 查理大桥', region: '捷克', continent: 'europe', label: 'PRAGUE', x: 54.0, y: 23.0, minutes: 9, motif: 'village',
    palette: ['#d5dcee', '#f0d3c2', '#b4785f', '#5d6b78'],
    blessings: ['{pet}数着桥上的石像走过黄昏，说每一尊都在替谁守着一段旧故事。', '{pet}在旧城广场等到了天文钟报时，把那一刻的钟声留给今晚的你。'],
    arrival: '背包上系了一条小铃铛',
  },
  {
    id: 'santorini', name: '圣托里尼', place: '伊亚小镇 · 蓝顶教堂', region: '希腊', continent: 'europe', label: 'OIA', x: 57.1, y: 29.8, minutes: 9, motif: 'coast',
    palette: ['#eaf3ff', '#cfe2f7', '#7ea6d6', '#f6f1e2'],
    blessings: ['{pet}在白房子之间迷了路，却一点也不着急，说误路也有好看的风景。', '{pet}坐在蓝顶教堂前写信，海风把纸页吹得哗啦响，像在替你鼓掌。'],
    arrival: '把爱琴海的蓝带回来了',
  },
  {
    id: 'iceland', name: '雷克雅未克', place: '雷克雅未克 · 极光营地', region: '冰岛', continent: 'europe', label: 'REYKJAVIK', x: 43.9, y: 14.4, minutes: 12, motif: 'aurora',
    palette: ['#2f4a6e', '#5f8ba8', '#8fd8c8', '#e5f5f0'],
    blessings: ['{pet}在雪地里看到了极光，绿光像绸子一样飘。它说那很像你说话时的样子。', '{pet}泡了很久的温泉，脸被热气熏得红红的，一直说下次想带你来。'],
    arrival: '围巾上还沾着雪的味道',
  },
  {
    id: 'norway', name: '挪威峡湾', place: '盖朗厄尔 · 峡湾深处', region: '挪威', continent: 'europe', label: 'GEIRANGER', x: 51.9, y: 16.1, minutes: 12, motif: 'mountain',
    palette: ['#cfe3ec', '#9dc0d0', '#5f8ba8', '#37596b'],
    blessings: ['{pet}坐在船头看了很久的峡谷，说世界很大，你的难过会被稀释掉。', '{pet}在冷风里喝了一碗热汤，想起你总忘记吃早饭，托我提醒你。'],
    arrival: '胡子还冻着一点点冰',
  },

  // ── 亚洲 ────────────────────────────────────────────────
  {
    id: 'kyoto', name: '京都', place: '京都 · 岚山竹林小径', region: '日本', continent: 'asia', label: 'ARASHIYAMA', x: 87.7, y: 30.5, minutes: 8, motif: 'temple',
    palette: ['#f7dfe2', '#e2b3bd', '#a97f92', '#5f6f58'],
    blessings: ['{pet}在鸟居下听了很久的风铃，把最好听的那一声装进明信片给你。', '{pet}沿着石板路走了很远，买了小小的御守，说要把好运分你一半。'],
    arrival: '带回一片被风吹落的枫叶',
  },
  {
    id: 'shirakawago', name: '白川乡', place: '白川乡 · 合掌造村落', region: '日本岐阜县', continent: 'asia', label: 'SHIRAKAWA-GO', x: 87.9, y: 33.0, minutes: 9, motif: 'village',
    palette: ['#d9e8f2', '#e8e3d4', '#9d9a7a', '#5f8560'],
    blessings: ['{pet}坐在合掌屋的屋檐下看雪，说尖尖的屋顶像两只合起来的手。', '{pet}在村里喝了热味噌汤，觉得整个人从里到外都安静下来了。'],
    arrival: '毛上落着一点点雪',
  },
  {
    id: 'kamakura', name: '镰仓', place: '镰仓 · 江之电海边道口', region: '日本神奈川', continent: 'asia', label: 'KAMAKURA', x: 88.8, y: 30.5, minutes: 7, motif: 'coast',
    palette: ['#cbe6f7', '#f7e6cd', '#7fa8bf', '#6f8f5f'],
    blessings: ['{pet}在道口等了一趟慢车，海就在轨道尽头，它说那是动画里的画面。', '{pet}坐在海堤上吃完了饭团，把最后一口留给了海风。'],
    arrival: '口袋里有一张小小的车票',
  },
  {
    id: 'maldives', name: '马尔代夫', place: '马累环礁 · 水上木屋', region: '马尔代夫', continent: 'asia', label: 'MALDIVES', x: 70.3, y: 48.2, minutes: 7, motif: 'island',
    palette: ['#c8ecf7', '#8fd7ea', '#4fb3c9', '#f6ecd2'],
    blessings: ['{pet}浮在水面上睡了一觉，说海水凉凉的很安心，想让你也歇一歇。', '{pet}捡到了会反光的贝壳，说要把海的声音一起寄给你。'],
    arrival: '身上还挂着咸咸的海风',
  },
  {
    id: 'hoian', name: '会安', place: '会安古城 · 灯笼街', region: '越南广南省', continent: 'asia', label: 'HOI AN', x: 80.1, y: 40.9, minutes: 8, motif: 'village',
    palette: ['#e6dcc6', '#f0c089', '#c98a5e', '#4f7f74'],
    blessings: ['{pet}在灯笼街走了一晚上，说每盏灯都像有人在小声说晚安。', '{pet}放了一盏河灯，让它顺着水漂到你那边去。'],
    arrival: '带回一盏会亮的小灯笼',
  },
  {
    id: 'chiangmai', name: '清迈', place: '清迈 · 素贴山森林', region: '泰国北部', continent: 'asia', label: 'CHIANG MAI', x: 77.5, y: 39.6, minutes: 8, motif: 'forest',
    palette: ['#dcefdc', '#bfdfae', '#6f9f68', '#3d6347'],
    blessings: ['{pet}在雨林里听了一整天叶子上的水声，说那是地球在慢慢呼吸。', '{pet}遇到一只小松鼠，分给了它半块饼干，两个都吃得很开心。'],
    arrival: '背包里钻出一片蕨叶',
  },
  {
    id: 'wuzhen', name: '乌镇', place: '乌镇 · 西栅水巷', region: '中国浙江', continent: 'asia', label: 'WUZHEN', x: 83.5, y: 32.6, minutes: 7, motif: 'village',
    palette: ['#dbe7ef', '#efe3cf', '#8fa4a8', '#4f6f66'],
    blessings: ['{pet}坐着摇橹船穿过石桥，水声很轻，它说想把这安静分你一半。', '{pet}在临水的长廊坐到打烊，说这里的夜比想象中温柔。'],
    arrival: '带回一小包桂花糕',
  },
  {
    id: 'wuyuan', name: '婺源', place: '婺源 · 篁岭油菜花田', region: '中国江西', continent: 'asia', label: 'WUYUAN', x: 82.7, y: 33.7, minutes: 7, motif: 'flower',
    palette: ['#dff0f7', '#f7e9a8', '#e8c85f', '#6f9a5f'],
    blessings: ['{pet}在花田里被风推着走，黄花开到坡顶，它说像走进了一幅画。', '{pet}在晒秋的屋檐下坐了很久，觉得日子原来可以这么慢。'],
    arrival: '毛里夹着几瓣黄花',
  },
  {
    id: 'lijiang', name: '丽江', place: '丽江古城 · 大研花巷', region: '中国云南', continent: 'asia', label: 'LIJIANG', x: 77.8, y: 35.1, minutes: 7, motif: 'village',
    palette: ['#dbeaf3', '#e7dccc', '#a8907a', '#54756a'],
    blessings: ['{pet}在小桥上坐了一会儿，水声很轻，它说想把这份安静送你一半。', '{pet}跟着老奶奶学了一句当地的问候，说得颠三倒四，但很认真。'],
    arrival: '带回一小罐桂花蜜',
  },
  {
    id: 'dali', name: '大理', place: '大理 · 洱海生态廊道', region: '中国云南', continent: 'asia', label: 'ERHAI', x: 77.8, y: 35.8, minutes: 8, motif: 'lake',
    palette: ['#d6ecf7', '#c3dcea', '#8fb6b0', '#6f9a72'],
    blessings: ['{pet}沿着湖边骑了一下午车，风把耳朵都吹热了，说特别自由。', '{pet}看着苍山的云散开又聚起，说人也可以这样慢慢来。'],
    arrival: '带回一小袋洱海的沙',
  },
  {
    id: 'yuanyang', name: '元阳', place: '元阳 · 多依树梯田', region: '中国云南', continent: 'asia', label: 'YUANYANG', x: 78.6, y: 37.3, minutes: 8, motif: 'terrace',
    palette: ['#e2eef2', '#dfd3bd', '#93b39a', '#5b7d6a'],
    blessings: ['{pet}在梯田边等日出，水面一层一层醒过来，它说辛苦的人也值得这样的清晨。', '{pet}数了梯田的层数，数到七十七就放弃了，改去看云。'],
    arrival: '带回一撮带水的田土',
  },
  {
    id: 'sanya', name: '三亚', place: '三亚 · 蜈支洲岛', region: '中国海南', continent: 'asia', label: 'SANYA', x: 80.4, y: 39.8, minutes: 6, motif: 'island',
    palette: ['#d2f0ff', '#9fdcf0', '#4fa9c9', '#ffeec9'],
    blessings: ['{pet}在椰子树下睡着了，梦里全是海浪的声音，醒来晒得暖烘烘。', '{pet}把脚埋进沙子里，说这样就不会被生活推着走了。'],
    arrival: '壳里还存着一点海浪声',
  },
  {
    id: 'hulunbuir', name: '呼伦贝尔', place: '额尔古纳 · 草原牧场', region: '中国内蒙古', continent: 'asia', label: 'HULUNBUIR', x: 83.3, y: 22.7, minutes: 9, motif: 'meadow',
    palette: ['#dceffb', '#cfe3b6', '#9dc47f', '#5f8c5a'],
    blessings: ['{pet}在草原上跑成一个小点，回来时累得直喘，却说特别自由。', '{pet}数了很久的羊，最后睡着在草地上，身上全是青草味。'],
    arrival: '绒毛里藏着草籽',
  },
  {
    id: 'dunhuang', name: '敦煌', place: '敦煌 · 鸣沙山月牙泉', region: '中国甘肃', continent: 'asia', label: 'DUNHUANG', x: 76.3, y: 27.7, minutes: 8, motif: 'desert',
    palette: ['#ffe0b8', '#f0bf82', '#d09a63', '#8f6136'],
    blessings: ['{pet}在鸣沙山听了沙子唱歌，说那是大地在哼一首很老的歌。', '{pet}在壁画前站了很久，把漂亮的颜色一个个记了下来带给你。'],
    arrival: '帽子里藏着一把细沙',
  },
  {
    id: 'zhangjiajie', name: '张家界', place: '张家界 · 天子山云海', region: '中国湖南', continent: 'asia', label: 'ZHANGJIAJIE', x: 80.7, y: 33.8, minutes: 9, motif: 'mountain',
    palette: ['#e4f0ef', '#b7cfc9', '#7f9d8c', '#456356'],
    blessings: ['{pet}在云里走了一路，说原来仙境就是有雾的普通山谷。', '{pet}在山顶等到了云开的那一刻，替你把第一缕光收好了。'],
    arrival: '毛上还带着山里的雾气',
  },

  // ── 北美洲 ──────────────────────────────────────────────
  {
    id: 'newyork', name: '纽约', place: '纽约 · 布鲁克林大桥', region: '美国', continent: 'north-america', label: 'NEW YORK', x: 29.4, y: 27.4, minutes: 9, motif: 'city',
    palette: ['#d3daef', '#b9c3e0', '#7f8bb5', '#4a5270'],
    blessings: ['{pet}在楼顶看了整座城市的灯，说每一盏都像有人在等谁回家。', '{pet}排了很久的队买了热狗，觉得还是你做的饭比较好吃。'],
    arrival: '时差还没倒过来，先睡一觉',
  },
  {
    id: 'canyon', name: '大峡谷', place: '亚利桑那 · 大峡谷南缘', region: '美国', continent: 'north-america', label: 'GRAND CANYON', x: 18.9, y: 30.0, minutes: 10, motif: 'canyon',
    palette: ['#ffe6c4', '#f0bd90', '#c47a52', '#7d4b38'],
    blessings: ['{pet}站在悬崖边看了很久，说时间把石头都磨软了，你的难过也会过去。', '{pet}对着峡谷喊了一声，回声传回来三次，像有人陪你一起。'],
    arrival: '身上落了一层红土',
  },
  {
    id: 'banff', name: '班夫', place: '班夫 · 露易丝湖', region: '加拿大艾伯塔', continent: 'north-america', label: 'LOUISE', x: 17.9, y: 21.5, minutes: 11, motif: 'lake',
    palette: ['#d5e9f5', '#bfe0ea', '#79b7bd', '#4f7f74'],
    blessings: ['{pet}看着湖面把雪山照得干干净净，说心里也跟着空出一块地方。', '{pet}在木栈道上走了很久，捡了一颗小石子，说要给你压书页。'],
    arrival: '带回一小块被水磨圆的石头',
  },

  // ── 南美洲 ──────────────────────────────────────────────
  {
    id: 'rio', name: '里约', place: '里约热内卢 · 面包山', region: '巴西', continent: 'south-america', label: 'RIO', x: 38.0, y: 62.7, minutes: 10, motif: 'coast',
    palette: ['#ffe4c2', '#ffb98a', '#6f9f7f', '#39665a'],
    blessings: ['{pet}在山顶跟着鼓点晃了一路，说快乐原来是可以传染的。', '{pet}看了一场海边日落，替你许了个愿：希望你也被人好好喜欢着。'],
    arrival: '带回一小袋会响的沙子',
  },
  {
    id: 'amazon', name: '亚马逊', place: '马瑙斯 · 雨林深处', region: '巴西', continent: 'south-america', label: 'AMAZON', x: 33.3, y: 51.7, minutes: 10, motif: 'forest',
    palette: ['#d9eecb', '#a8d090', '#4f8f5f', '#2a5238'],
    blessings: ['{pet}在雨里听了一下午的叶子声，说那是地球的心跳，让它别怕。', '{pet}认识了一只蓝色的蝴蝶，蝴蝶说会带你走到想去的地方。'],
    arrival: '背包里钻出一片蕨叶',
  },
  {
    id: 'machupicchu', name: '马丘比丘', place: '库斯科 · 马丘比丘', region: '秘鲁', continent: 'south-america', label: 'MACHU PICCHU', x: 29.8, y: 57.3, minutes: 12, motif: 'mountain',
    palette: ['#d9e8e2', '#b7cfc2', '#7f9d7f', '#4f6f52'],
    blessings: ['{pet}在云雾散开的瞬间看到了整座古城，说有些等待真的值得。', '{pet}和一只羊驼合了影，它说这里的羊驼走路比它还慢。'],
    arrival: '毛上还带着山雾',
  },

  // ── 非洲 ────────────────────────────────────────────────
  {
    id: 'sahara', name: '撒哈拉', place: '梅尔祖卡 · 沙丘营地', region: '摩洛哥', continent: 'africa', label: 'MERZOUGA', x: 48.5, y: 33.6, minutes: 11, motif: 'desert',
    palette: ['#ffe4b0', '#f2c078', '#c98f55', '#8a5a35'],
    blessings: ['{pet}在沙丘上滚了三圈，说风把它的烦恼都吹走了。你也不要一个人扛着。', '{pet}数了一整夜的星星，最后发现最亮的那颗像你桌上的台灯。'],
    arrival: '鞋子里倒出半把沙漠',
  },
  {
    id: 'capetown', name: '开普敦', place: '开普敦 · 桌山与好望角', region: '南非', continent: 'africa', label: 'CAPE TOWN', x: 55.1, y: 68.8, minutes: 11, motif: 'coast',
    palette: ['#ffdcb6', '#eeb98f', '#7fa39c', '#3d6b72'],
    blessings: ['{pet}看着两片海在眼前交汇，说原来不同也能好好在一起。', '{pet}被山顶的云盖住了一会儿，说像被人轻轻抱了一下。'],
    arrival: '尾巴上挂着海藻',
  },
  {
    id: 'zanzibar', name: '桑给巴尔', place: '桑给巴尔 · 石头城海滩', region: '坦桑尼亚', continent: 'africa', label: 'ZANZIBAR', x: 60.9, y: 52.8, minutes: 9, motif: 'island',
    palette: ['#d6eff5', '#a8dfe4', '#4fb0b8', '#f6e9cf'],
    blessings: ['{pet}跟着退潮去找海星，回来时裤脚全是水，笑得停不下来。', '{pet}闻到香料市集的味道，说那里像一整个会呼吸的厨房。'],
    arrival: '背带里掉出几粒丁香',
  },

  // ── 大洋洲 ──────────────────────────────────────────────
  {
    id: 'sydney', name: '悉尼', place: '悉尼 · 邦迪海滩', region: '澳大利亚', continent: 'oceania', label: 'BONDI', x: 92.0, y: 68.8, minutes: 10, motif: 'coast',
    palette: ['#d6ebff', '#b3d6f2', '#5f96c2', '#f2f0e2'],
    blessings: ['{pet}看着白色贝壳一样的屋顶发了很久的呆，说人类真有耐心。', '{pet}在海边跑了一整个下午，把鞋都跑湿了，笑得停不下来。'],
    arrival: '口袋里装满了细沙',
  },
  {
    id: 'queenstown', name: '皇后镇', place: '皇后镇 · 瓦卡蒂普湖', region: '新西兰南岛', continent: 'oceania', label: 'QUEENSTOWN', x: 96.9, y: 74.2, minutes: 12, motif: 'mountain',
    palette: ['#d9e9f5', '#c0d8e8', '#7f9fb5', '#4f7f6a'],
    blessings: ['{pet}坐着小缆车上了山，风很大，它说这里的云跑得比它快。', '{pet}在湖边坐了很久，说想给你带一瓶这里的安静回来。'],
    arrival: '带回一颗圆圆的湖边石子',
  },

  // ── 著名景点 ────────────────────────────────────────────
  {
    id: 'london', name: '伦敦', place: '伦敦 · 泰晤士河畔', region: '英国', continent: 'europe', label: 'LONDON', x: 50.0, y: 21.4, minutes: 9, motif: 'city',
    palette: ['#cfd9e6', '#e8d3c2', '#b98d6f', '#6d6f5c'],
    blessings: ['{pet}在桥上等雾散开，把整条河的灯都数了一遍，说想分你一半。', '{pet}在旧书店里待了一下午，挑了一张最旧的地图，说要照着它去见你。'],
    arrival: '伞上还留着一点伦敦的雨',
  },
  {
    id: 'barcelona', name: '巴塞罗那', place: '巴塞罗那 · 圣家堂', region: '西班牙', continent: 'europe', label: 'BARCELONA', x: 50.6, y: 27.0, minutes: 9, motif: 'city',
    palette: ['#ffe2c4', '#f5c98f', '#d99a5f', '#8f6a4a'],
    blessings: ['{pet}在彩色玻璃下坐了很久，光落在地上像一地的糖。', '{pet}爬上了屋顶看整座城，说这里的房子都像会跳舞。'],
    arrival: '口袋里有一张彩色的车票',
  },
  {
    id: 'greatwall', name: '慕田峪长城', place: '北京 · 慕田峪长城', region: '中国北京', continent: 'asia', label: 'MUTIANYU', x: 82.4, y: 27.6, minutes: 8, motif: 'mountain',
    palette: ['#e2ecf0', '#c9d8cc', '#8f9f7f', '#5f6a4f'],
    blessings: ['{pet}沿着城墙走到喘气，回头看见那条长线，说坚持原来这么好看。', '{pet}在烽火台上等到日落，把最后一线光留给了你。'],
    arrival: '爪子上还沾着一点城砖的灰',
  },
  {
    id: 'fuji', name: '富士山', place: '河口湖 · 富士山', region: '日本山梨县', continent: 'asia', label: 'FUJI', x: 88.5, y: 30.3, minutes: 8, motif: 'mountain',
    palette: ['#dceaf5', '#c9d6ea', '#8f9fb5', '#4f6f5f'],
    blessings: ['{pet}在湖边等云散开，山露出来的那一瞬间，它说你也要被别人好好看见。', '{pet}泡着温泉看山，说世界上最舒服的事就是慢慢来。'],
    arrival: '带回一枚小小的御守',
  },
  {
    id: 'taj', name: '泰姬陵', place: '阿格拉 · 泰姬陵', region: '印度', continent: 'asia', label: 'TAJ MAHAL', x: 71.7, y: 34.9, minutes: 9, motif: 'temple',
    palette: ['#ffe8d4', '#f4cfa8', '#c99a72', '#7f6a52'],
    blessings: ['{pet}在水池边看倒影，白石头在晨光里变成了粉色，它替你多看了三分钟。', '{pet}想了一句很长的祝福，最后只写下了你的名字。'],
    arrival: '围巾上有一点香料的味道',
  },
  {
    id: 'angkor', name: '吴哥窟', place: '暹粒 · 吴哥窟', region: '柬埔寨', continent: 'asia', label: 'ANGKOR', x: 78.9, y: 42.6, minutes: 9, motif: 'temple',
    palette: ['#e8e2c9', '#cfc39a', '#9f8f66', '#5f7f5f'],
    blessings: ['{pet}在石阶上等到日出，五座塔从雾里长出来，它说这值得早起。', '{pet}摸了很久石头上被雨水写下的痕迹，说时间也很有耐心。'],
    arrival: '背包里落了一层细沙',
  },
  {
    id: 'petra', name: '佩特拉', place: '佩特拉 · 玫瑰古城', region: '约旦', continent: 'asia', label: 'PETRA', x: 59.8, y: 33.2, minutes: 10, motif: 'canyon',
    palette: ['#ffdcc0', '#eeb98f', '#c47f5f', '#7d4b3f'],
    blessings: ['{pet}穿过又长又窄的峡谷，转角那一下，它说差点看哭了。', '{pet}在玫瑰色的石头上坐了很久，说有些等待是会开花的。'],
    arrival: '口袋里装着一块粉色的石头',
  },
  {
    id: 'yellowstone', name: '黄石', place: '黄石公园 · 大棱镜泉', region: '美国', continent: 'north-america', label: 'YELLOWSTONE', x: 19.3, y: 25.2, minutes: 11, motif: 'forest',
    palette: ['#dbeadf', '#bfd6b8', '#7f9f6f', '#5f5f3f'],
    blessings: ['{pet}看着热泉的雾气升上去，说大地原来一直在轻轻呼吸。', '{pet}遇到一头慢慢过马路的野牛，它就乖乖在原地等了十分钟。'],
    arrival: '毛上还带着硫磺的味道',
  },
  {
    id: 'niagara', name: '尼亚加拉', place: '尼亚加拉大瀑布', region: '加拿大 / 美国', continent: 'north-america', label: 'NIAGARA', x: 28.0, y: 26.1, minutes: 10, motif: 'lake',
    palette: ['#d8ecf5', '#b3d8e8', '#6f9fb5', '#3f6f7f'],
    blessings: ['{pet}被水雾淋了满脸，说在这么大的声音里，反而什么都不用想了。', '{pet}看见了水上的彩虹，说想把那一段颜色送给你。'],
    arrival: '带回一件潮潮的外套',
  },
  {
    id: 'reef', name: '大堡礁', place: '凯恩斯 · 大堡礁', region: '澳大利亚', continent: 'oceania', label: 'GREAT BARRIER REEF', x: 91.0, y: 60.2, minutes: 11, motif: 'island',
    palette: ['#d6f0ff', '#a8dcf0', '#4fb0c8', '#f6ecd2'],
    blessings: ['{pet}潜到水下看了很久的珊瑚，说这里像一整个会呼吸的花园。', '{pet}和一条小丑鱼做了很久的朋友，临走时互相摆了摆手。'],
    arrival: '毛巾里还藏着一点海的味道',
  },

  // ── 小众目的地 ──────────────────────────────────────────
  {
    id: 'bled', name: '布莱德湖', place: '布莱德 · 湖心小岛', region: '斯洛文尼亚', continent: 'europe', label: 'LAKE BLED', x: 53.9, y: 24.2, minutes: 8, motif: 'lake', niche: true,
    palette: ['#d7e9f2', '#bcd8e2', '#8fb7ac', '#4f6f66'],
    blessings: ['{pet}划着小船去了湖心岛，敲了三下钟，每一下都替你许了愿。', '{pet}在湖边坐到天黑，说水面安静得像替人收好了心事。'],
    arrival: '带回一小块被湖水磨圆的石头',
  },
  {
    id: 'skye', name: '天空岛', place: '天空岛 · 老人石', region: '英国苏格兰', continent: 'europe', label: 'ISLE OF SKYE', x: 48.3, y: 18.2, minutes: 11, motif: 'coast', niche: true,
    palette: ['#cfdcdf', '#a9bcc0', '#7f9a86', '#42584e'],
    blessings: ['{pet}在雾里走到悬崖边，风很大，它却觉得心里很安静。', '{pet}看见云影在草坡上跑，说那是山在慢慢呼吸。'],
    arrival: '毛上还带着一点海雾的咸味',
  },
  {
    id: 'faroe', name: '法罗群岛', place: '法罗群岛 · 海上悬崖', region: '丹麦', continent: 'europe', label: 'FAROE', x: 48.1, y: 15.6, minutes: 12, motif: 'coast', niche: true,
    palette: ['#c9d8de', '#9fb6bd', '#6f8f7f', '#3d554e'],
    blessings: ['{pet}站在悬崖边看了很久的海鸟，说它们飞得比烦恼快。', '{pet}在草屋顶的小房子里烤火，把烤热的石头塞进了口袋里。'],
    arrival: '带回一根被风吹干的草',
  },
  {
    id: 'cappadocia', name: '卡帕多奇亚', place: '卡帕多奇亚 · 热气球山谷', region: '土耳其', continent: 'europe', label: 'CAPPADOCIA', x: 59.7, y: 28.6, minutes: 10, motif: 'canyon', niche: true,
    palette: ['#ffe0bd', '#f2c193', '#c9926a', '#8a5b42'],
    blessings: ['{pet}在天上飘了很久，说从这里往下看，烦恼都小得像石头。', '{pet}在岩洞里睡了一晚，梦见了会飞的房子。'],
    arrival: '帽子里藏着一小把红土',
  },
  {
    id: 'elnido', name: '爱妮岛', place: '巴拉望 · 爱妮岛泻湖', region: '菲律宾', continent: 'asia', label: 'EL NIDO', x: 83.2, y: 43.8, minutes: 8, motif: 'island', niche: true,
    palette: ['#d2f0f7', '#9fdce0', '#4fb3c0', '#f6ecd2'],
    blessings: ['{pet}在泻湖里漂了一下午，说这里的水绿得像有人特意调过色。', '{pet}钻进小小的岩洞里探险，出来的时候笑得很得意。'],
    arrival: '耳朵里还留着海水的回音',
  },
  {
    id: 'luang', name: '琅勃拉邦', place: '琅勃拉邦 · 湄公河畔', region: '老挝', continent: 'asia', label: 'LUANG PRABANG', x: 78.4, y: 38.9, minutes: 8, motif: 'village', niche: true,
    palette: ['#e6dcc6', '#f0c089', '#c98a5e', '#4f7f74'],
    blessings: ['{pet}清晨看僧人化缘，整条街都很安静，它说原来安静也有声音。', '{pet}在河边的木楼里住了一晚，听着水声睡得很沉。'],
    arrival: '带回一小罐手作的果酱',
  },
  {
    id: 'uyuni', name: '乌尤尼', place: '乌尤尼 · 天空之镜', region: '玻利维亚', continent: 'south-america', label: 'UYUNI', x: 31.3, y: 61.2, minutes: 11, motif: 'desert', niche: true,
    palette: ['#dfeaf5', '#cfd8e8', '#b0b8cc', '#8f8f9f'],
    blessings: ['{pet}踩在薄薄的水上，天和地连成一片，它说走路像在云里。', '{pet}等到星星出现，脚下也是星星，它说像被整个世界抱着。'],
    arrival: '鞋缝里还留着一点盐',
  },
  {
    id: 'paine', name: '百内', place: '巴塔哥尼亚 · 百内国家公园', region: '智利', continent: 'south-america', label: 'TORRES DEL PAINE', x: 29.7, y: 78.3, minutes: 12, motif: 'mountain', niche: true,
    palette: ['#d5e2ea', '#a9c0cc', '#6f8f9f', '#4f6f5f'],
    blessings: ['{pet}走了很久才到湖边，风大得站不稳，它说值得。', '{pet}看着花岗岩的尖峰，说有些东西天生就是要站着。'],
    arrival: '背包里灌进了南半球的风',
  },
  {
    id: 'chefchaouen', name: '舍夫沙万', place: '舍夫沙万 · 蓝色小巷', region: '摩洛哥', continent: 'africa', label: 'CHEFCHAOUEN', x: 48.5, y: 30.4, minutes: 10, motif: 'village', niche: true,
    palette: ['#cfe0ef', '#9fbcd8', '#6f8fb0', '#4f6f66'],
    blessings: ['{pet}在蓝色的小巷里转了整整一个下午，说每一种蓝都不一样。', '{pet}被一只猫领着走了一段路，最后猫在墙头睡着了。'],
    arrival: '口袋里有一小包香料',
  },
  {
    id: 'baobab', name: '猴面包树大道', place: '穆龙达瓦 · 猴面包树大道', region: '马达加斯加', continent: 'africa', label: 'BAOBAB', x: 62.3, y: 61.3, minutes: 11, motif: 'meadow', niche: true,
    palette: ['#ffe4c0', '#f0bb8c', '#c98a5f', '#8a5a3f'],
    blessings: ['{pet}等到太阳落到树后面，那些胖胖的影子拉得很长，它说那像有人在挥手。', '{pet}抱了一下最大的那棵树，说它比自己还能守着一个地方。'],
    arrival: '带回一颗圆圆的树种',
  },
];

const SPECIES_BY_ID = new Map(PET_SPECIES.map((species) => [species.id, species]));
const DESTINATION_BY_ID = new Map(DESTINATIONS.map((destination) => [destination.id, destination]));

export const INITIAL_PET_STATE: PetState = {
  bond: 28,
  pets: [{ id: 'pet-frog-starter', speciesId: 'frog', name: '小蛙', adoptedAt: 0, trips: 0, trip: null }],
  postcards: [],
  daily: { date: '', earned: 0 },
};

export function speciesById(id: PetSpeciesId): PetSpecies {
  return SPECIES_BY_ID.get(id) || PET_SPECIES[0];
}

export function destinationById(id: string): Destination {
  return DESTINATION_BY_ID.get(id) || DESTINATIONS[0];
}

export function continentName(id: ContinentId): string {
  return CONTINENTS.find((continent) => continent.id === id)?.name || '';
}

/** 按大洲分组，供目的地图鉴列表使用 */
export function destinationsByContinent(): Array<{ id: ContinentId; name: string; items: Destination[] }> {
  return CONTINENTS.map((continent) => ({
    id: continent.id,
    name: continent.name,
    items: DESTINATIONS.filter((destination) => destination.continent === continent.id),
  })).filter((group) => group.items.length > 0);
}

export function getLocalDateKey(date = new Date()): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function clampDaily(state: PetState): PetState {
  const today = getLocalDateKey();
  if (state.daily.date === today) return state;
  return { ...state, daily: { date: today, earned: 0 } };
}

export function getInitialPetState(scope = 'default'): PetState {
  try {
    const saved = window.localStorage.getItem(`xinyu-pet-state:${scope}`);
    if (!saved) return { ...INITIAL_PET_STATE, daily: { date: getLocalDateKey(), earned: 0 } };
    const parsed = JSON.parse(saved) as Partial<PetState>;
    const pets = Array.isArray(parsed.pets)
      ? parsed.pets.filter((pet): pet is Pet => !!pet && PET_SPECIES.some((species) => species.id === pet.speciesId)).map((pet) => ({
        id: String(pet.id || `pet-${Math.random().toString(36).slice(2, 9)}`),
        speciesId: pet.speciesId,
        name: String(pet.name || speciesById(pet.speciesId).defaultName),
        adoptedAt: Number(pet.adoptedAt) || Date.now(),
        trips: Number(pet.trips) || 0,
        trip: pet.trip && DESTINATION_BY_ID.has(pet.trip.destinationId)
          ? { destinationId: pet.trip.destinationId, departedAt: Number(pet.trip.departedAt) || 0, returnsAt: Number(pet.trip.returnsAt) || 0 }
          : null,
      }))
      : [];
    // 青蛙是所有用户的免费初始旅伴。旧版本没有初始旅伴时自动补发，
    // 已有其他旅伴的用户也会保留原进度并获得青蛙。
    const hasFrog = pets.some((pet) => pet.speciesId === 'frog');
    const normalizedPets = hasFrog
      ? pets
      : [{ id: 'pet-frog-starter', speciesId: 'frog' as const, name: '小蛙', adoptedAt: 0, trips: 0, trip: null }, ...pets];
    const postcards = Array.isArray(parsed.postcards)
      ? parsed.postcards
        .filter((card): card is Postcard => !!card && DESTINATION_BY_ID.has(card.destinationId))
        .map((card) => ({
          ...card,
          petName: card.petName || speciesById(card.speciesId).defaultName,
          seed: Number(card.seed) || 1,
        }))
        .slice(0, MAX_POSTCARDS)
      : [];
    return clampDaily({
      bond: Number.isFinite(Number(parsed.bond)) ? Math.max(0, Number(parsed.bond)) : INITIAL_PET_STATE.bond,
      pets: normalizedPets,
      postcards,
      daily: {
        date: typeof parsed.daily?.date === 'string' ? parsed.daily.date : '',
        earned: Number(parsed.daily?.earned) || 0,
      },
    });
  } catch {
    return INITIAL_PET_STATE;
  }
}

export function savePetState(state: PetState, scope = 'default'): void {
  try {
    window.localStorage.setItem(`xinyu-pet-state:${scope}`, JSON.stringify(state));
  } catch {
    /* 存储不可用时只影响下次打开 */
  }
}

export type PetStatus = 'home' | 'traveling' | 'returned';

export function petStatus(pet: Pet, now: number): PetStatus {
  if (!pet.trip) return 'home';
  return now >= pet.trip.returnsAt ? 'returned' : 'traveling';
}

export function pendingReturns(state: PetState, now: number): Pet[] {
  return state.pets.filter((pet) => petStatus(pet, now) === 'returned');
}

export function travelingPets(state: PetState, now: number): Pet[] {
  return state.pets.filter((pet) => petStatus(pet, now) === 'traveling');
}

export function remainingBondToday(state: PetState): number {
  const today = getLocalDateKey();
  const earned = state.daily.date === today ? state.daily.earned : 0;
  return Math.max(0, MAX_DAILY_BOND - earned);
}

/** 每聊一轮赚好感度；好感度上升时额外奖励，并且每天有上限。 */
export function addChatBond(state: PetState, bondDelta: number): { state: PetState; gained: number } {
  const base = clampDaily(state);
  const room = Math.max(0, MAX_DAILY_BOND - base.daily.earned);
  const wanted = CHAT_BOND_BASE + (bondDelta > 0 ? CHAT_BOND_BONUS : 0);
  const gained = Math.min(room, wanted);
  if (gained <= 0) return { state: base, gained: 0 };
  return {
    state: { ...base, bond: base.bond + gained, daily: { date: getLocalDateKey(), earned: base.daily.earned + gained } },
    gained,
  };
}

export interface PetActionResult {
  state: PetState;
  ok: boolean;
  message: string;
}

export function adoptPet(state: PetState, speciesId: PetSpeciesId, nickname?: string): PetActionResult {
  const species = speciesById(speciesId);
  if (state.pets.some((pet) => pet.speciesId === speciesId)) {
    return { state, ok: false, message: `${species.name}已经在你的旅伴列表里了，可以直接切换主页面形象` };
  }
  if (state.bond < species.price) {
    return { state, ok: false, message: `好感度还差 ${species.price - state.bond} 点，陪小屿再聊几句吧` };
  }
  const pet: Pet = {
    id: `pet-${speciesId}-${Date.now().toString(36)}`,
    speciesId,
    name: (nickname || '').trim().slice(0, 12) || species.defaultName,
    adoptedAt: Date.now(),
    trips: 0,
    trip: null,
  };
  return {
    state: { ...state, bond: state.bond - species.price, pets: [...state.pets, pet] },
    ok: true,
    message: `${pet.name}住进了小屿的房间，快安排一次旅行吧`,
  };
}

export function dispatchPet(state: PetState, petId: string, destinationId: string): PetActionResult {
  const pet = state.pets.find((item) => item.id === petId);
  if (!pet) return { state, ok: false, message: '没有找到这只旅伴' };
  if (petStatus(pet, Date.now()) === 'traveling') return { state, ok: false, message: `${pet.name}还在路上，先等它回来` };
  const destination = destinationById(destinationId);
  const departedAt = Date.now();
  return {
    state: {
      ...state,
      pets: state.pets.map((item) => item.id === petId
        ? { ...item, trips: item.trips + 1, trip: { destinationId, departedAt, returnsAt: departedAt + destination.minutes * 60_000 } }
        : item),
    },
    ok: true,
    message: `${pet.name}出发去${destination.place}了，约 ${destination.minutes} 分钟后回来`,
  };
}

export interface CollectResult extends PetActionResult {
  postcard?: Postcard;
  starCoins: number;
}

/** 领回旅行中的旅伴：生成一张风景明信片，并带回一点星光币。 */
export function collectPet(state: PetState, petId: string, ownerName = '你'): CollectResult {
  const pet = state.pets.find((item) => item.id === petId);
  if (!pet || !pet.trip) return { state, ok: false, message: '这只旅伴正在家里休息', starCoins: 0 };
  const now = Date.now();
  if (now < pet.trip.returnsAt) return { state, ok: false, message: `${pet.name}还在路上`, starCoins: 0 };
  const destination = destinationById(pet.trip.destinationId);
  const seed = Math.floor(Math.random() * 100000);
  const template = destination.blessings[seed % destination.blessings.length];
  const blessing = template.replace(/\{pet\}/g, pet.name).replace(/\{owner\}/g, ownerName);
  const postcard: Postcard = {
    id: `card-${now.toString(36)}-${seed.toString(36)}`,
    petId: pet.id,
    petName: pet.name,
    speciesId: pet.speciesId,
    destinationId: destination.id,
    createdAt: now,
    blessing,
    seed,
  };
  const starCoins = 4 + (destination.minutes % 4);
  return {
    state: {
      ...state,
      bond: state.bond + 2,
      postcards: [postcard, ...state.postcards].slice(0, MAX_POSTCARDS),
      pets: state.pets.map((item) => item.id === petId ? { ...item, trip: null } : item),
    },
    ok: true,
    message: `${pet.name}从${destination.place}回来了 · ${destination.arrival}`,
    postcard,
    starCoins,
  };
}

export function formatCountdown(ms: number): string {
  const total = Math.max(0, Math.ceil(ms / 1000));
  const minutes = Math.floor(total / 60);
  const seconds = total % 60;
  return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}

export function formatPostcardDate(timestamp: number): string {
  const date = new Date(timestamp);
  return `${date.getFullYear()}.${String(date.getMonth() + 1).padStart(2, '0')}.${String(date.getDate()).padStart(2, '0')}`;
}

/** 稳定的伪随机数，保证同一张明信片的画面不会每次刷新都变 */
export function createRandom(seed: number): () => number {
  let value = seed >>> 0 || 1;
  return () => {
    value ^= value << 13;
    value ^= value >>> 17;
    value ^= value << 5;
    value >>>= 0;
    return value / 4294967296;
  };
}
