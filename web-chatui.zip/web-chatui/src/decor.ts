/**
 * 心屿 · 房间换装
 *
 * 四间主题小屋，家具按亲密度逐件解锁；解锁后从右侧列表拖进房间自由摆放，
 * 可再次拖动调整、可收回列表，点击任意家具可查看它的 3D 模型。
 */
import { DECOR_ROOMS } from './decorRooms.generated';
import type { DecorItemConf, DecorRoomConf } from './decorRooms.generated';

export type { DecorItemConf, DecorRoomConf };
export { DECOR_ROOMS };

export function decorRoomById(id: string | null | undefined): DecorRoomConf {
  return DECOR_ROOMS.find((room) => room.id === id) ?? DECOR_ROOMS[0];
}

export function decorItemByKey(room: DecorRoomConf, key: string): DecorItemConf | undefined {
  return room.items.find((item) => item.key === key);
}

export function makeDecorKey(roomId: string, key: string): string {
  return `${roomId}:${key}`;
}

/**
 * 新用户初始羁绊值是 40，这里扣掉基线，让「房间换装」从 0 亲密度开始：
 * 聊天累积羁绊 → 逐件解锁家具。
 */
export const DECOR_BASE_INTIMACY = 40;

export function decorIntimacy(peak: number): number {
  return Math.max(0, Math.round(peak - DECOR_BASE_INTIMACY));
}
