import { useEffect, useMemo, useRef, useState } from 'react';
import styles from './MemoryPanel.module.css';
import {
  addJournalEntry,
  journalSignature,
  loadJournalEntries,
  removeJournalEntry,
  subscribeJournal,
  updateJournalEntry,
} from '../journal';
import type { JournalEntry } from '../journal';
import { apiFetch } from '../auth';

export interface MemoryItem { id: number; content: string; emotion?: string; source?: string; created_at?: string; }

/** 手帐里的一条记录：可能来自后端长期记忆，也可能是用户直接写下的本地内容。 */
interface JournalItem { id: string; origin: 'memory' | 'local'; remoteId?: number; content: string; created_at?: string; }

interface MemoryPanelProps { userId: string; storageScope?: string; open: boolean; onClose: () => void; onMemoriesChange?: (memories: MemoryItem[]) => void; }

/** 本地手帐与后端记忆合并成一本；内容重复的只保留一条。 */
function mergeItems(remote: MemoryItem[], local: JournalEntry[]): JournalItem[] {
  const signatures = new Set(local.map((entry) => journalSignature(entry.content)));
  return [
    ...local.map((entry): JournalItem => ({ id: entry.id, origin: 'local', content: entry.content, created_at: entry.created_at })),
    ...remote
      .filter((item) => !signatures.has(journalSignature(item.content)))
      .map((item): JournalItem => ({ id: String(item.id), origin: 'memory', remoteId: item.id, content: item.content, created_at: item.created_at })),
  ];
}

/** 每条的金额存在本地：手帐是私人账本，不需要为它改动后端表结构。 */
const AMOUNT_KEY = 'xinyu-journal-amounts';
const WEEKDAYS = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];

interface JournalCategory {
  id: string;
  name: string;
  /** 便签纸底色 */
  tint: string;
  /** 便签虚线边框 */
  border: string;
  /** 分类字与金额的颜色 */
  ink: string;
  keywords: string[];
}

const CATEGORIES: JournalCategory[] = [
  {
    id: 'food', name: '饮食', tint: '#fdf0c4', border: '#e3cd85', ink: '#b7881f',
    keywords: ['吃', '喝', '餐', '饭', '面', '菜', '汤', '火锅', '烧烤', '早餐', '午餐', '晚餐', '夜宵', '宵夜', '奶茶', '咖啡', '茶', '酒', '蛋糕', '零食', '水果', '包子', '面包', '饺子', '外卖', '食堂', '甜点', '冰淇淋'],
  },
  {
    id: 'sport', name: '运动', tint: '#dcf0d6', border: '#aacf9f', ink: '#5c8b4c',
    keywords: ['晨跑', '跑步', '散步', '走路', '健身', '运动', '瑜伽', '游泳', '骑车', '骑行', '打球', '拉伸', '爬山', '徒步', '登山', '锻炼', '跑'],
  },
  {
    id: 'study', name: '学习', tint: '#dbe7f8', border: '#a8c1e4', ink: '#4d76ab',
    keywords: ['看书', '读书', '阅读', '学习', '复习', '考试', '上课', '笔记', '作业', '论文', '自习', '背单词', '工作', '开会', '加班', '项目', '写'],
  },
  {
    id: 'travel', name: '出行', tint: '#d8eef1', border: '#9fc9d0', ink: '#3f8794',
    keywords: ['旅行', '旅游', '出发', '飞机', '高铁', '火车', '地铁', '公交', '酒店', '民宿', '公园', '海边', '逛街', '露营', '自驾', '景点', '机场', '车站'],
  },
  {
    id: 'fun', name: '娱乐', tint: '#f8dcea', border: '#e2aecb', ink: '#b95f92',
    keywords: ['电影', '美术馆', '博物馆', '音乐', '唱歌', '游戏', '话剧', '演唱会', '画画', '摄影', '动漫', '演出', '展', '剧', '玩'],
  },
  {
    id: 'mood', name: '心情', tint: '#e6ddf8', border: '#bfaee4', ink: '#7a63b5',
    keywords: ['开心', '难过', '委屈', '焦虑', '紧张', '平静', '感动', '想你', '喜欢', '讨厌', '很累', '心情', '情绪', '幸福', '孤单', '害怕', '生气', 'emo'],
  },
];

const OTHER: JournalCategory = { id: 'other', name: '其他', tint: '#f2ecdb', border: '#d9cda9', ink: '#96865f', keywords: [] };

/** 关键词打分归类：长词权重更高，命中最多的一类胜出。 */
function classify(content: string): JournalCategory {
  let best = OTHER;
  let bestScore = 0;
  CATEGORIES.forEach((category) => {
    let score = 0;
    category.keywords.forEach((keyword) => {
      if (content.includes(keyword)) score += keyword.length > 1 ? 2 : 1;
    });
    if (score > bestScore) { bestScore = score; best = category; }
  });
  return best;
}

function parseDate(value?: string): Date | null {
  if (!value) return null;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}

function formatTime(value?: string): string {
  const date = parseDate(value);
  if (!date) return '--:--';
  return `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
}

function formatDateLabel(key: string): string {
  if (key === 'unknown') return '未标注日期';
  const [year, month, day] = key.split('-').map(Number);
  const weekday = WEEKDAYS[new Date(year, month - 1, day).getDay()];
  const prefix = year === new Date().getFullYear() ? '' : `${year}年`;
  return `${prefix}${month}月${day}日 · ${weekday}`;
}

interface JournalPage { key: string; label: string; items: JournalItem[]; }

/** 一天一页，页内按时间从早到晚排，最新的一天放最前面。 */
function buildPages(items: JournalItem[]): JournalPage[] {
  const groups = new Map<string, JournalItem[]>();
  items.forEach((item) => {
    const date = parseDate(item.created_at);
    const key = date
      ? `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`
      : 'unknown';
    const list = groups.get(key);
    if (list) list.push(item);
    else groups.set(key, [item]);
  });
  return Array.from(groups.entries())
    .map(([key, list]) => ({
      key,
      label: formatDateLabel(key),
      items: [...list].sort((a, b) => (parseDate(a.created_at)?.getTime() || 0) - (parseDate(b.created_at)?.getTime() || 0)),
    }))
    .sort((a, b) => (a.key === 'unknown' ? 1 : b.key === 'unknown' ? -1 : b.key.localeCompare(a.key)));
}

function loadAmounts(scope = 'default'): Record<string, number> {
  try {
    const parsed = JSON.parse(window.localStorage.getItem(`${AMOUNT_KEY}:${scope}`) || '{}') as Record<string, number>;
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

/** 卡片角落的小猫，和参考图里的涂鸦一样，只是装饰。 */
function CatDoodle() {
  return (
    <svg viewBox="0 0 44 44" className={styles.cat} aria-hidden="true">
      <g fill="#fffdf6" stroke="#8a7f70" strokeWidth="1.3" strokeLinejoin="round" strokeLinecap="round">
        <path d="M14 18 L11 9.5 L19.5 13 Z" />
        <path d="M30 18 L33 9.5 L24.5 13 Z" />
        <ellipse cx="22" cy="21" rx="11" ry="9" />
        <path d="M20 38 q-6.5 0 -6.5 -6.5 q0 -6 8.5 -6 q8.5 0 8.5 6 q0 6.5 -6.5 6.5 z" />
        <path d="M30 33.5 q6 -1 5 -7.5" fill="none" />
      </g>
      <g fill="#8a7f70">
        <ellipse cx="18" cy="20" rx="1.4" ry="1.9" />
        <ellipse cx="26" cy="20" rx="1.4" ry="1.9" />
        <path d="M22 23.6 l-1.7 1.5 h3.4 z" />
      </g>
    </svg>
  );
}

export function MemoryPanel({ userId, storageScope = userId, open, onClose, onMemoriesChange }: MemoryPanelProps) {
  const [remoteItems, setRemoteItems] = useState<MemoryItem[]>([]);
  const [localEntries, setLocalEntries] = useState<JournalEntry[]>(() => loadJournalEntries(storageScope));
  const [amounts, setAmounts] = useState<Record<string, number>>(() => loadAmounts(storageScope));
  const [editing, setEditing] = useState<string | null>(null);
  const [draft, setDraft] = useState('');
  const [compose, setCompose] = useState('');
  const [editingAmount, setEditingAmount] = useState<string | null>(null);
  const [amountDraft, setAmountDraft] = useState('');
  const [loading, setLoading] = useState(false);
  const [pageIndex, setPageIndex] = useState(0);
  const [flipping, setFlipping] = useState<{ dir: 1 | -1; from: number; to: number } | null>(null);
  const flipTimerRef = useRef<number | null>(null);

  const load = () => {
    setLoading(true);
    apiFetch('/api/memories?limit=100')
      .then((r) => r.ok ? r.json() : Promise.reject(new Error('memory load failed')))
      .then((data) => setRemoteItems(Array.isArray(data.memories) ? data.memories : []))
      .catch(() => undefined)
      .finally(() => setLoading(false));
  };
  useEffect(() => { if (open) { setPageIndex(0); setFlipping(null); load(); } }, [open, userId]);

  // 别处（比如聊天框的「写进手帐」）写了新内容时，打开着的手帐也要立刻看到。
  useEffect(() => subscribeJournal(setLocalEntries, storageScope), [storageScope]);

  useEffect(() => { onMemoriesChange?.(remoteItems); }, [remoteItems, onMemoriesChange]);

  useEffect(() => {
    try { window.localStorage.setItem(`${AMOUNT_KEY}:${storageScope}`, JSON.stringify(amounts)); } catch { /* 存储不可用时只影响下次打开 */ }
  }, [amounts, storageScope]);

  useEffect(() => () => { if (flipTimerRef.current) window.clearTimeout(flipTimerRef.current); }, []);

  const items = useMemo(() => mergeItems(remoteItems, localEntries), [remoteItems, localEntries]);
  const pages = useMemo(() => buildPages(items), [items]);
  useEffect(() => { setPageIndex((current) => Math.min(current, Math.max(0, pages.length - 1))); }, [pages.length]);

  const total = useMemo(() => items.reduce((sum, item) => sum + (Number(amounts[item.id]) || 0), 0), [items, amounts]);

  /** 翻页：往前翻先把新页铺在下面再把当前页翻走；往回翻则让上一页从左侧翻回来。 */
  const turn = (dir: 1 | -1) => {
    if (flipping || !pages.length) return;
    const to = pageIndex + dir;
    if (to < 0 || to >= pages.length) return;
    setFlipping({ dir, from: pageIndex, to });
    if (dir === 1) setPageIndex(to);
    flipTimerRef.current = window.setTimeout(() => {
      if (dir === -1) setPageIndex(to);
      setFlipping(null);
      flipTimerRef.current = null;
    }, 620);
  };
  const turnRef = useRef(turn);
  turnRef.current = turn;

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'ArrowRight') turnRef.current(1);
      else if (event.key === 'ArrowLeft') turnRef.current(-1);
      else if (event.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);

  const addEntry = () => {
    const content = compose.trim();
    if (!content) return;
    setLocalEntries(addJournalEntry(content, storageScope));
    setCompose('');
    setPageIndex(0);
  };
  const remove = async (item: JournalItem) => {
    if (item.origin === 'local') {
      setLocalEntries(removeJournalEntry(item.id, storageScope));
      return;
    }
    if (item.remoteId == null) return;
    await apiFetch(`/api/memories/${item.remoteId}`, { method: 'DELETE' }).catch(() => undefined);
    setRemoteItems((current) => current.filter((entry) => entry.id !== item.remoteId));
  };
  const save = async (item: JournalItem) => {
    const content = draft.trim();
    if (!content) return;
    if (item.origin === 'local') {
      setLocalEntries(updateJournalEntry(item.id, content, storageScope));
    } else if (item.remoteId != null) {
      await apiFetch(`/api/memories/${item.remoteId}`, { method: 'PATCH', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ content }) }).catch(() => undefined);
      setRemoteItems((current) => current.map((entry) => entry.id === item.remoteId ? { ...entry, content } : entry));
    }
    setEditing(null);
  };

  const startAmount = (item: JournalItem) => {
    setEditingAmount(item.id);
    setAmountDraft(amounts[item.id] ? String(amounts[item.id]) : '');
  };
  const commitAmount = (id: string) => {
    const value = Math.max(0, Number.parseFloat(amountDraft) || 0);
    setAmounts((current) => ({ ...current, [id]: Math.round(value * 100) / 100 }));
    setEditingAmount(null);
  };

  if (!open) return null;

  const page = pages[pageIndex];
  const flipPage = flipping ? pages[flipping.dir === 1 ? flipping.from : flipping.to] : undefined;
  const renderPage = (target: JournalPage) => (
    <>
      <div className={styles.pageHead}>
        <div>
          <strong>{target.label}</strong>
          <small>{target.items.length} 条记录</small>
        </div>
        <button className={styles.close} type="button" onClick={onClose} aria-label="合上手帐本">×</button>
      </div>
      <div className={styles.timeline}>
        {target.items.map((item) => {
          const category = classify(item.content);
          const amount = Number(amounts[item.id]) || 0;
          return (
            <article className={styles.entry} key={item.id}>
              <span className={styles.time}>{formatTime(item.created_at)}</span>
              <div className={styles.note} style={{ background: category.tint, borderColor: category.border }}>
                <div className={styles.noteMain}>
                  {editing === item.id ? (
                    <div className={styles.edit}>
                      <textarea value={draft} onChange={(event) => setDraft(event.target.value)} />
                      <div><button type="button" onClick={() => save(item)}>保存</button><button type="button" onClick={() => setEditing(null)}>取消</button></div>
                    </div>
                  ) : (
                    <p>{item.content}</p>
                  )}
                  <div className={styles.noteMeta}>
                    <span className={styles.chip} style={{ color: category.ink, borderColor: category.border }}>{category.name}</span>
                    {editingAmount === item.id ? (
                      <span className={styles.amountEdit}>
                        ¥
                        <input
                          value={amountDraft}
                          inputMode="decimal"
                          autoFocus
                          placeholder="0.00"
                          onChange={(event) => setAmountDraft(event.target.value)}
                          onKeyDown={(event) => { if (event.key === 'Enter') commitAmount(item.id); }}
                          onBlur={() => commitAmount(item.id)}
                        />
                      </span>
                    ) : (
                      <button className={styles.amount} type="button" style={{ color: category.ink }} onClick={() => startAmount(item)} title="点一下填写金额">
                        ¥ {amount.toFixed(2)}
                      </button>
                    )}
                  </div>
                </div>
                <CatDoodle />
              </div>
              <div className={styles.actions}>
                <button type="button" onClick={() => { setEditing(item.id); setDraft(item.content); }}>编辑</button>
                <button type="button" onClick={() => remove(item)}>删除</button>
              </div>
            </article>
          );
        })}
      </div>
    </>
  );

  return (
    <div className={styles.overlay} role="dialog" aria-modal="true" aria-label="手帐本" onClick={onClose}>
      <div className={styles.book} onClick={(event) => event.stopPropagation()}>
        <div className={styles.stage}>
          <div className={styles.tape} aria-hidden="true" />
          {!loading && !items.length && <p className={styles.hint}>手帐本还是空白的。在下面写下一件小事，或者和小屿分享，都会记在这里。</p>}
          {loading && <p className={styles.hint}>正在翻开手帐本…</p>}
          {page && (
            <div className={styles.sheet} key={`page-${page.key}`}>
              {renderPage(page)}
            </div>
          )}
          {flipping && flipPage && (
            <div
              className={`${styles.sheet} ${styles.sheetFlip} ${flipping.dir === 1 ? styles.flipForward : styles.flipBackward}`}
              aria-hidden="true"
            >
              {renderPage(flipPage)}
            </div>
          )}
        </div>
        <div className={styles.composer}>
          <textarea
            className={styles.composeInput}
            value={compose}
            placeholder="在手帐里写点什么…（回车记下）"
            onChange={(event) => setCompose(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); addEntry(); }
            }}
          />
          <button className={styles.composeButton} type="button" onClick={addEntry} disabled={!compose.trim()}>记下</button>
        </div>
        <div className={styles.footer}>
          <span className={styles.total}>共计消费 <b>¥ {total.toFixed(2)}</b></span>
          <div className={styles.pager}>
            <button type="button" onClick={() => turn(-1)} disabled={pageIndex <= 0 || !!flipping} aria-label="上一页">‹</button>
            <span>{pages.length ? `${pageIndex + 1} / ${pages.length}` : '0 / 0'}</span>
            <button type="button" onClick={() => turn(1)} disabled={pageIndex >= pages.length - 1 || !!flipping} aria-label="下一页">›</button>
          </div>
        </div>
      </div>
    </div>
  );
}
