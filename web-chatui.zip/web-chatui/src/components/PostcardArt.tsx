import type { ReactNode } from 'react';
import type { Destination, MotifId, PetSpeciesId } from '../pets';
import { createRandom, destinationById } from '../pets';
import { PetArt } from './PetSprite';
import { mixColor } from '../color';

interface PostcardArtProps {
  destinationId: string;
  species: PetSpeciesId;
  seed: number;
  className?: string;
}

type Point = [number, number];
type Range = [number, number];

const HORIZON = 120;
const GROUND = 168;

/** 日落时分抹在画布上的暖光，让每张明信片都带上油画的黄金色调。 */
const SUNSET = '#ff9d4d';
const SUNSET_SOFT = '#ffcd85';
const VIOLET = '#7b5aa6';
const ROSE = '#ff8ab4';

/** 用 Catmull-Rom 把折线变成柔和的曲线，丘陵的轮廓靠它撑起来。 */
function smoothThrough(points: Point[]): string {
  const fix = (value: number) => value.toFixed(1);
  let path = `M${fix(points[0][0])} ${fix(points[0][1])}`;
  for (let index = 0; index < points.length - 1; index += 1) {
    const previous = points[Math.max(0, index - 1)];
    const current = points[index];
    const next = points[index + 1];
    const after = points[Math.min(points.length - 1, index + 2)];
    const c1x = current[0] + (next[0] - previous[0]) / 6;
    const c1y = current[1] + (next[1] - previous[1]) / 6;
    const c2x = next[0] - (after[0] - current[0]) / 6;
    const c2y = next[1] - (after[1] - current[1]) / 6;
    path += ` C${fix(c1x)} ${fix(c1y)} ${fix(c2x)} ${fix(c2y)} ${fix(next[0])} ${fix(next[1])}`;
  }
  return path;
}

/** 一条起伏的山丘 / 沙丘 / 岩层轮廓，自动收口到底部。 */
function ridge(baseY: number, amplitude: number, steps: number, rng: () => number, phase = 0): string {
  const points: Point[] = [];
  for (let index = 0; index <= steps; index += 1) {
    const x = -24 + (index / steps) * 408;
    const y = baseY + Math.sin(index * 1.15 + phase) * amplitude * 0.45 + (rng() - 0.5) * amplitude;
    points.push([x, y]);
  }
  return `${smoothThrough(points)} L384 216 L-24 216 Z`;
}

/* ── 笔触 ───────────────────────────────────────────────── */

interface BrushOptions {
  count: number;
  x: Range;
  y: Range;
  length: Range;
  width: Range;
  opacity: Range;
  colors: string[];
  /** 笔触基础角度（度），0 为横向 */
  angle: number;
  /** 每笔的角度抖动幅度 */
  jitter?: number;
}

/**
 * 一笔油画颜料：圆头短笔触，方向、长短和浓淡都随手感抖动。
 * 整片天空、水面和草地都由这样的一笔笔叠出来，才有厚涂的颜料感。
 */
function brushStrokes(rng: () => number, options: BrushOptions): ReactNode {
  const { count, x, y, length, width, opacity, colors, angle, jitter = 8 } = options;
  const pick = (range: Range) => range[0] + rng() * (range[1] - range[0]);
  return Array.from({ length: count }, (_, index) => {
    const cx = pick(x);
    const cy = pick(y);
    const size = pick(length);
    const strokeWidth = pick(width);
    const theta = ((angle + (rng() - 0.5) * jitter) * Math.PI) / 180;
    const dx = Math.cos(theta) * size;
    const dy = Math.sin(theta) * size;
    const color = colors[Math.min(colors.length - 1, Math.floor(rng() * colors.length))];
    return (
      <path
        key={`brush-${index}`}
        d={`M${(cx - dx / 2).toFixed(1)} ${(cy - dy / 2).toFixed(1)} q${(dx * 0.12).toFixed(1)} ${(dy * 0.2 + (rng() - 0.5) * 2.6).toFixed(1)} ${dx.toFixed(1)} ${dy.toFixed(1)}`}
        stroke={color}
        strokeWidth={strokeWidth.toFixed(1)}
        strokeLinecap="round"
        fill="none"
        opacity={Number(pick(opacity).toFixed(2))}
      />
    );
  });
}

/** 油画的云：用一叠横向的厚涂笔触堆出来，上缘提亮、下缘带暖灰。 */
function paintedCloud(cx: number, cy: number, scale: number, rng: () => number, light: string, shade: string) {
  const strokes = Array.from({ length: 6 }, (_, index) => ({
    dx: (index - 2.5) * 13 * scale + (rng() - 0.5) * 7 * scale,
    dy: (rng() - 0.5) * 7 * scale,
    rx: (15 + rng() * 15) * scale,
    ry: (5 + rng() * 4) * scale,
  }));
  const highlight = mixColor(light, '#fff6e2', 0.55);
  return (
    <g>
      {strokes.map((s, index) => (
        <ellipse key={`c${index}`} cx={cx + s.dx} cy={cy + s.dy + 3.5 * scale} rx={s.rx} ry={s.ry} fill={shade} opacity=".9" />
      ))}
      {strokes.map((s, index) => (
        <ellipse key={`l${index}`} cx={cx + s.dx} cy={cy + s.dy - 1.5 * scale} rx={s.rx * 0.94} ry={s.ry * 0.86} fill={light} />
      ))}
      {strokes.map((s, index) => (
        <ellipse key={`h${index}`} cx={cx + s.dx - s.rx * 0.22} cy={cy + s.dy - s.ry} rx={s.rx * 0.46} ry={s.ry * 0.52} fill={highlight} opacity=".72" />
      ))}
    </g>
  );
}

function tree(x: number, y: number, size: number, trunk: string, leafLight: string, leafDark: string, lean = 0) {
  return (
    <g transform={`translate(${x} ${y}) rotate(${lean})`}>
      <rect x={-size * 0.07} y={-size * 0.62} width={size * 0.14} height={size * 0.64} rx={size * 0.05} fill={trunk} />
      <ellipse cx={0} cy={-size * 0.82} rx={size * 0.6} ry={size * 0.5} fill={leafDark} />
      <ellipse cx={-size * 0.1} cy={-size * 0.95} rx={size * 0.5} ry={size * 0.42} fill={leafLight} />
      <ellipse cx={size * 0.22} cy={-size * 0.7} rx={size * 0.34} ry={size * 0.3} fill={leafLight} opacity=".7" />
    </g>
  );
}

function house(x: number, y: number, width: number, height: number, wall: string, roof: string, roofDark: string, window = '#fdf3d0') {
  return (
    <g>
      <rect x={x} y={y - height} width={width} height={height} fill={wall} />
      <rect x={x} y={y - height} width={width * 0.42} height={height} fill={mixColor(wall, '#ffffff', 0.35)} />
      <path d={`M${x - width * 0.14} ${y - height} L${x + width / 2} ${y - height - width * 0.46} L${x + width * 1.14} ${y - height} Z`} fill={roof} />
      <path d={`M${x - width * 0.14} ${y - height} L${x + width / 2} ${y - height - width * 0.46} L${x + width / 2} ${y - height} Z`} fill={roofDark} opacity=".55" />
      <rect x={x + width * 0.22} y={y - height * 0.66} width={width * 0.18} height={height * 0.22} fill={window} />
      <rect x={x + width * 0.6} y={y - height * 0.66} width={width * 0.18} height={height * 0.22} fill={window} />
    </g>
  );
}

function boat(x: number, y: number, size: number, hull: string, sail: string) {
  return (
    <g transform={`translate(${x} ${y})`}>
      <path d={`M${-size * 0.6} 0 q${size * 0.6} ${size * 0.28} ${size * 1.2} 0 z`} fill={hull} />
      <path d={`M${-size * 0.06} -1 v${-size * 0.62} l${size * 0.46} ${size * 0.4} z`} fill={sail} />
    </g>
  );
}

/** 每个地点的风景构图：天空、云、远山、丘陵，再加上当地最有辨识度的东西。 */
function paintScene(motif: MotifId, destination: Destination, rng: () => number, sunX: number): ReactNode {
  // 先把原始配色往日落方向调，整组明信片才有统一的金色调。
  const [skyRaw, farRaw, midRaw, groundRaw] = destination.palette;
  const sky = mixColor(skyRaw, SUNSET, 0.12);
  const far = mixColor(farRaw, SUNSET_SOFT, 0.2);
  const mid = mixColor(midRaw, SUNSET, 0.12);
  const ground = mixColor(groundRaw, SUNSET, 0.1);
  const skyTop = mixColor(sky, '#ffffff', 0.06);
  const haze = mixColor(far, '#ffffff', 0.5);
  const farHill = mixColor(mid, haze, 0.62);
  const midHill = mixColor(mid, '#ffffff', 0.24);
  const nearHill = mixColor(mid, '#2f4a33', 0.28);
  const deepGround = mixColor(ground, '#2b3a2c', 0.34);
  const leafLight = mixColor(mid, '#f2f7d8', 0.42);
  const leafDark = mixColor(mid, '#2f5238', 0.36);
  const trunk = mixColor(ground, '#5b4633', 0.45);
  const roof = mixColor('#b9583f', ground, 0.18);
  const roofDark = mixColor(roof, '#5a2d22', 0.4);

  switch (motif) {
    case 'meadow':
      return (
        <g>
          <path d={ridge(HORIZON + 4, 9, 6, rng, 0.4)} fill={farHill} />
          <path d={ridge(HORIZON + 20, 11, 6, rng, 1.7)} fill={midHill} />
          <path d={ridge(GROUND - 12, 9, 6, rng, 3.1)} fill={mixColor(mid, '#ffffff', 0.06)} />
          <path d={ridge(196, 11, 6, rng, 4.4)} fill={nearHill} />
          <path d="M96 210 q14 -30 44 -46 q30 -16 52 -10" stroke={mixColor(ground, '#ffffff', 0.5)} strokeWidth="5" fill="none" opacity=".5" strokeLinecap="round" />
          {[0, 1, 2].map((index) => <g key={`tl${index}`}>{tree(46 + index * 26 + rng() * 18, 168 - index * 3, 26 + rng() * 12, trunk, leafLight, leafDark, (rng() - 0.5) * 4)}</g>)}
          {[0, 1, 2].map((index) => <g key={`tr${index}`}>{tree(268 + index * 30 + rng() * 16, 150 - index * 2, 22 + rng() * 10, trunk, leafLight, leafDark, (rng() - 0.5) * 4)}</g>)}
          {Array.from({ length: 8 }, (_, index) => (
            <g key={index}>
              <ellipse cx={70 + rng() * 220} cy={178 + rng() * 22} rx={4.6} ry={3.6} fill="#fdfaf1" opacity=".92" />
              <ellipse cx={70 + rng() * 220} cy={182 + rng() * 20} rx={2.2} ry={2} fill={deepGround} opacity=".4" />
            </g>
          ))}
        </g>
      );
    case 'village':
      return (
        <g>
          <path d={ridge(HORIZON + 2, 10, 6, rng, 0.8)} fill={farHill} />
          <path d={ridge(HORIZON + 22, 12, 6, rng, 2.2)} fill={midHill} />
          <path d={ridge(180, 10, 6, rng, 3.6)} fill={nearHill} />
          {[0, 1, 2, 3, 4].map((index) => {
            const x = 92 + index * 40 + (rng() - 0.5) * 10;
            const height = 22 + rng() * 14;
            return <g key={index}>{house(x, 166 + (index % 2) * 6, 26 + rng() * 8, height, mixColor('#f6ead6', ground, rng() * 0.2), roof, roofDark)}</g>;
          })}
          <g>
            <rect x={196} y={118} width={9} height={30} fill={mixColor('#f4ecdc', ground, 0.1)} />
            <path d="M190 118 L200.5 96 L211 118 Z" fill={roofDark} />
          </g>
          {[0, 1, 2, 3].map((index) => <g key={`vt${index}`}>{tree(40 + index * 34 + rng() * 12, 172 - index * 2, 24 + rng() * 12, trunk, leafLight, leafDark, (rng() - 0.5) * 5)}</g>)}
          <path d="M20 214 q60 -26 120 -30 q70 -4 120 -22" stroke={mixColor(ground, '#ffffff', 0.42)} strokeWidth="6" fill="none" opacity=".45" strokeLinecap="round" />
        </g>
      );
    case 'coast':
      return (
        <g>
          <path d={ridge(HORIZON + 6, 8, 5, rng, 0.9)} fill={farHill} />
          <rect x="0" y={HORIZON + 12} width="360" height={210 - HORIZON - 12} fill={mixColor(mid, '#2f6f8f', 0.5)} />
          <rect x="0" y={HORIZON + 12} width="360" height="6" fill={mixColor(mid, '#eaf6ff', 0.62)} opacity=".75" />
          <path d={`M0 ${HORIZON + 30} q60 -8 110 0 q70 10 130 -4 q60 -10 120 4 V210 H0 Z`} fill={mixColor(mid, '#1f5a7a', 0.6)} />
          <path d={`M${sunX - 26} ${HORIZON + 18} l52 0 l-26 ${120} z`} fill="#fff3cd" opacity=".3" />
          {[0, 1, 2, 3].map((index) => (
            <path key={index} d={`M${20 + index * 92} ${HORIZON + 34 + index * 8} q28 -6 56 0 q10 3 20 0`} stroke="#fdfaf1" strokeWidth="2.4" fill="none" opacity=".7" strokeLinecap="round" />
          ))}
          <path d="M0 148 q36 -40 82 -38 q34 2 38 38 z" fill={mixColor(mid, '#b9a98d', 0.55)} />
          <path d="M0 148 q36 -40 82 -38 q34 2 38 38 z" fill={midHill} opacity=".5" />
          <path d="M0 148 q30 -22 58 -24 q16 -1 22 6 q-40 -4 -80 18 z" fill={mixColor(leafDark, '#4f7f4f', 0.35)} opacity=".85" />
          {[0, 1, 2, 3].map((index) => <g key={`h${index}`}>{house(16 + index * 20, 146 - index * 2, 15, 13 + rng() * 6, mixColor('#fbf3e4', mid, 0.1), mixColor('#d97757', ground, rng() * 0.3), roofDark)}</g>)}
          <g>
            <rect x={296} y={110} width={9} height={42} fill="#f8f3e8" />
            <rect x={294} y={104} width={13} height={7} fill={roofDark} />
            <path d="M292 104 h18 l-9 -9 z" fill={mixColor('#d97757', ground, 0.2)} />
            <circle cx={300.5} cy={102} r={2.6} fill="#fff3c4" />
          </g>
          {[0, 1].map((index) => <g key={`b${index}`}>{boat(120 + index * 74 + rng() * 30, 132 + rng() * 12, 13, mixColor(ground, '#4a3a2a', 0.3), '#fdfaf1')}</g>)}
          {[0, 1, 2].map((index) => (
            <path key={index} d={`M${40 + rng() * 260} ${HORIZON - 12 - rng() * 14} q3 -4 6 0 q3 -4 6 0`} stroke={mixColor(far, '#7a8a90', 0.5)} strokeWidth="1.2" fill="none" />
          ))}
          <path d={ridge(GROUND - 6, 7, 5, rng, 2.6)} fill={mixColor(ground, '#8fbf8a', 0.4)} />
          <path d={ridge(GROUND + 24, 6, 5, rng, 4.1)} fill={mixColor(ground, '#f0e0bb', 0.55)} />
        </g>
      );
    case 'mountain':
      return (
        <g>
          <path d="M-20 150 L60 84 L132 150 Z" fill={mixColor(far, '#ffffff', 0.42)} />
          <path d="M96 150 L188 60 L286 150 Z" fill={mixColor(far, '#5f7f9a', 0.3)} />
          <path d="M186 86 L188 60 L216 88 L200 100 L190 92 Z" fill="#fbfdff" opacity=".95" />
          <path d="M52 92 L60 84 L74 96 L64 104 L58 98 Z" fill="#fbfdff" opacity=".9" />
          <path d="M300 150 L332 108 L360 150 Z" fill={mixColor(far, '#ffffff', 0.5)} />
          <path d={ridge(HORIZON + 26, 9, 6, rng, 1.2)} fill={mixColor(mid, '#4f6f5f', 0.32)} />
          <rect x="0" y={GROUND + 6} width="360" height={210 - GROUND - 6} fill={mixColor(mid, '#3f7f8f', 0.55)} />
          <path d={`M0 ${GROUND + 16} q80 -6 150 0 q90 8 210 -4 V210 H0 Z`} fill={mixColor(mid, '#2f6470', 0.5)} opacity=".8" />
          {Array.from({ length: 9 }, (_, index) => tree(14 + index * 20 + rng() * 8, GROUND + 18, 16 + rng() * 8, trunk, mixColor(leafLight, '#3f6f4f', 0.3), mixColor(leafDark, '#2f4f38', 0.2), (rng() - 0.5) * 3)).map((item, index) => <g key={index}>{item}</g>)}
          <path d={ridge(GROUND + 26, 6, 5, rng, 3.4)} fill={deepGround} opacity=".55" />
        </g>
      );
    case 'aurora':
      return (
        <g>
          <rect x="0" y="0" width="360" height={HORIZON + 46} fill={mixColor(sky, '#07121f', 0.62)} opacity=".82" />
          {Array.from({ length: 30 }, (_, index) => (
            <circle key={`s${index}`} cx={rng() * 360} cy={rng() * 112} r={0.7 + rng() * 1.6} fill="#fdfaf1" opacity={0.45 + rng() * 0.55} />
          ))}
          {[0, 1, 2, 3].map((index) => (
            <path
              key={index}
              d={`M${-30 + index * 34} ${30 + index * 9} q120 ${28 + index * 8} 220 6 q80 -40 200 -10 v62 q-120 -30 -200 14 q-100 -46 -220 -6 z`}
              fill={index % 2 ? mixColor(mid, '#d8fbee', 0.45) : mixColor(mid, '#4fd0e8', 0.35)}
              opacity={0.36 - index * 0.05}
            />
          ))}
          <path d={ridge(HORIZON + 16, 8, 5, rng, 1.5)} fill={mixColor(mid, '#dff0f6', 0.5)} />
          <path d={ridge(HORIZON + 40, 9, 5, rng, 3)} fill={mixColor(sky, '#eef7fb', 0.62)} />
          <rect x="150" y={150} width="34" height="22" fill={mixColor(ground, '#4a3a2c', 0.35)} />
          <path d="M146 150 L167 132 L188 150 Z" fill={mixColor(ground, '#3a2f26', 0.3)} />
          <rect x="162" y="158" width="9" height="8" fill="#ffd88a" />
          <circle cx="166" cy="162" r="13" fill="#ffd88a" opacity=".34" />
        </g>
      );
    case 'desert':
      return (
        <g>
          <path d={ridge(HORIZON + 14, 12, 5, rng, 0.6)} fill={mixColor(far, '#ffffff', 0.38)} />
          <path d={ridge(HORIZON + 34, 16, 5, rng, 2)} fill={mixColor(mid, '#ffffff', 0.24)} />
          <path d={ridge(GROUND + 2, 18, 5, rng, 3.4)} fill={mid} />
          <path d={ridge(198, 16, 5, rng, 4.8)} fill={mixColor(ground, mid, 0.28)} />
          {[0, 1].map((index) => <g key={`dt${index}`}>{tree(276 + index * 26 + rng() * 10, 178 - index * 4, 22 + rng() * 8, mixColor(ground, '#6a4a2c', 0.4), mixColor(mid, '#8fbf6f', 0.4), mixColor(mid, '#5f8f4f', 0.4), (rng() - 0.5) * 6)}</g>)}
        </g>
      );
    case 'city':
      return (
        <g>
          <path d={ridge(HORIZON + 8, 6, 5, rng, 1)} fill={farHill} />
          {Array.from({ length: 11 }, (_, index) => {
            const width = 18 + rng() * 16;
            const height = 26 + rng() * 52;
            const x = -8 + index * 33 + (rng() - 0.5) * 6;
            return (
              <g key={index}>
                <rect x={x} y={HORIZON + 24 - height} width={width} height={height} fill={mixColor(mixColor(far, mid, 0.5), '#5a6480', index % 3 === 0 ? 0.1 : 0.28)} />
                <rect x={x} y={HORIZON + 24 - height} width={width * 0.4} height={height} fill="#ffffff" opacity=".1" />
                {Array.from({ length: 4 }, (_, row) => (
                  <rect key={row} x={x + width * 0.26} y={HORIZON + 30 - height + row * 11} width={width * 0.16} height="4" fill="#ffe9b0" opacity={0.55 + rng() * 0.4} />
                ))}
              </g>
            );
          })}
          <path d={`M${150 + rng() * 30} 144 L${176 + rng() * 20} 60 L${206 + rng() * 24} 144 Z`} fill={mixColor(mid, '#4f5a72', 0.35)} />
          <path d="M170 90 h10 M168 106 h14 M166 122 h18" stroke="#ffe9b0" strokeWidth="1.6" opacity=".7" />
          <rect x="0" y={144} width="360" height="12" fill={mixColor(mid, '#3f5f7f', 0.45)} />
          <rect x="0" y="156" width="360" height={210 - 156} fill={mixColor(mid, '#35566f', 0.4)} />
          {[0, 1, 2, 3].map((index) => (
            <rect key={index} x={20 + index * 92} y={160 + index * 3} width={16 + rng() * 20} height="4" fill="#ffe9b0" opacity=".4" />
          ))}
          <path d={ridge(HORIZON + 30, 5, 5, rng, 1.6)} fill={mixColor(far, mid, 0.55)} opacity=".9" />
          <path d={ridge(196, 8, 5, rng, 3.2)} fill={mixColor(ground, '#3f4f5f', 0.35)} />
        </g>
      );
    case 'forest':
      return (
        <g>
          <path d={ridge(HORIZON + 6, 7, 5, rng, 0.7)} fill={farHill} />
          {Array.from({ length: 7 }, (_, index) => (
            <ellipse key={`b${index}`} cx={-14 + index * 60} cy={HORIZON + 34 + rng() * 10} rx={(46 + rng() * 22) * 0.8} ry={(34 + rng() * 12) * 0.8} fill={mixColor(mid, '#3f6f5f', 0.24 + rng() * 0.2)} opacity=".92" />
          ))}
          <rect x="0" y={HORIZON + 40} width="360" height="14" fill="#f2f7e8" opacity=".22" />
          {Array.from({ length: 4 }, (_, index) => (
            <path key={`ray${index}`} d={`M${40 + index * 84} 22 L${70 + index * 84} 22 L${120 + index * 84} 150 L${96 + index * 84} 150 Z`} fill="#fff6cf" opacity=".14" />
          ))}
          {Array.from({ length: 7 }, (_, index) => tree(10 + index * 52 + rng() * 18, 196 - rng() * 12, 34 + rng() * 16, trunk, leafLight, leafDark, (rng() - 0.5) * 6)).map((item, index) => <g key={index}>{item}</g>)}
          <path d={`M0 ${198} q70 -14 120 -4 q70 12 130 -8 V210 H0 Z`} fill={deepGround} />
          <path d={`M120 152 q-16 26 6 54 q16 -24 8 -54 z`} fill={mixColor('#cfe9dd', mid, 0.28)} opacity=".75" />
          {Array.from({ length: 6 }, (_, index) => (
            <circle key={index} cx={60 + rng() * 240} cy={160 + rng() * 40} r={1.8} fill="#ffe9a0" opacity={0.5 + rng() * 0.5} />
          ))}
        </g>
      );
    case 'terrace':
      return (
        <g>
          <path d={ridge(HORIZON + 10, 9, 5, rng, 1.1)} fill={farHill} />
          {Array.from({ length: 7 }, (_, index) => {
            const y = HORIZON + 26 + index * 12;
            return (
              <g key={index}>
                <path d={`M-20 ${y} q90 -10 180 0 q90 10 200 -6 V${y + 12} q-110 16 -200 6 q-90 -10 -180 0 Z`} fill={index % 2 ? mixColor(mid, '#ffffff', 0.3) : midHill} />
                <path d={`M-20 ${y + 3} q90 -10 180 0 q90 10 200 -6`} stroke="#fdfaf1" strokeWidth="1.6" fill="none" opacity=".55" />
              </g>
            );
          })}
          {[0, 1].map((index) => <g key={`th${index}`}>{house(258 + index * 30, 152 - index * 6, 18, 15 + rng() * 6, mixColor('#f7ead2', mid, 0.2), roof, roofDark)}</g>)}
          {[0, 1, 2].map((index) => <g key={`tt${index}`}>{tree(30 + index * 30 + rng() * 10, 160 - index * 4, 20 + rng() * 8, trunk, leafLight, leafDark, (rng() - 0.5) * 4)}</g>)}
          <path d={ridge(202, 8, 5, rng, 4)} fill={mixColor(ground, '#6f9a6a', 0.4)} />
        </g>
      );
    case 'lake':
      return (
        <g>
          <path d="M40 132 L96 84 L152 132 Z" fill={mixColor(far, '#ffffff', 0.34)} />
          <path d="M120 132 L196 70 L276 132 Z" fill={mixColor(far, '#5f7f9a', 0.26)} />
          <path d="M190 90 L196 70 L216 92 L204 100 Z" fill="#fbfdff" opacity=".92" />
          <path d={ridge(HORIZON + 12, 7, 5, rng, 1.4)} fill={midHill} />
          <rect x="0" y={132} width="360" height={210 - 132} fill={mixColor(mid, '#4f8fa8', 0.5)} />
          <path d="M40 134 L96 102 L152 134 Z" fill={mixColor(far, '#8fb0c0', 0.5)} opacity=".55" />
          <path d="M120 134 L196 96 L276 134 Z" fill={mixColor(far, '#8fb0c0', 0.5)} opacity=".45" />
          {[0, 1, 2, 3].map((index) => (
            <rect key={index} x={40 + index * 78} y={144 + index * 7} width={40 + rng() * 40} height="2.4" rx="1.2" fill="#fdfaf1" opacity=".45" />
          ))}
          {boat(232, 162, 15, mixColor(ground, '#5a4633', 0.3), '#fdfaf1')}
          {[0, 1, 2, 3, 4].map((index) => (
            <path key={index} d={`M${18 + index * 14} 196 q3 -18 6 -22 q3 4 6 22 z`} fill={mixColor(leafDark, '#6f8f4f', 0.3)} opacity=".85" />
          ))}
          <path d={ridge(200, 6, 5, rng, 3.8)} fill={deepGround} opacity=".5" />
        </g>
      );
    case 'flower':
      return (
        <g>
          <path d={ridge(HORIZON + 8, 9, 5, rng, 1.3)} fill={farHill} />
          <path d={ridge(HORIZON + 30, 11, 5, rng, 2.7)} fill={mixColor(mid, '#ffffff', 0.42)} />
          {[0, 1, 2].map((index) => (
            <g key={index}>
              <path d={ridge(154 + index * 18, 7, 5, rng, 3.4 + index)} fill={mixColor(mid, '#ffffff', 0.3 - index * 0.1)} />
            </g>
          ))}
          {Array.from({ length: 54 }, (_, index) => {
            const row = index % 3;
            return <circle key={index} cx={8 + ((index * 37) % 348)} cy={156 + row * 17 + rng() * 8} r={1.6 + rng() * 1.6} fill={mixColor(mid, row === 0 ? '#ffffff' : '#f0d0ff', 0.35)} opacity={0.7 + rng() * 0.3} />;
          })}
          <g transform="translate(292 148)">
            <rect x="-3" y="-26" width="6" height="28" fill={mixColor(ground, '#6a5a44', 0.4)} />
            <path d="M0 -26 L26 -18 L0 -10 Z" fill="#fdfaf1" />
            <path d="M0 -26 L-22 -30 L0 -34 Z" fill="#f6efdc" />
            <g transform="rotate(12)">
              <path d="M0 -26 L26 -18 L0 -10 Z" fill="#f6efdc" opacity=".8" />
            </g>
          </g>
          <path d={ridge(196, 9, 5, rng, 4.6)} fill={mixColor(ground, '#7f9a5f', 0.4)} />
        </g>
      );
    case 'temple':
      return (
        <g>
          <path d={ridge(HORIZON + 6, 8, 5, rng, 0.9)} fill={farHill} />
          <path d={ridge(HORIZON + 28, 10, 5, rng, 2.4)} fill={mixColor(mid, '#5f8f5f', 0.3)} />
          {[0, 1].map((index) => (
            <g key={index} transform={`translate(${index === 0 ? 108 : 214} 152) scale(${index === 0 ? 1 : 0.82})`}>
              <rect x="-4" y="-40" width="8" height="42" fill={mixColor(roofDark, '#7f3a2a', 0.3)} />
              <rect x="-30" y="-42" width="60" height="7" fill={mixColor(roof, '#a5483a', 0.2)} />
              {[0, 1, 2].map((tier) => (
                <g key={tier}>
                  <path d={`M${-26 + tier * 3} ${-30 + tier * 14} q26 -12 52 0 q-8 6 -26 6 q-18 0 -26 -6 z`} fill={tier % 2 ? roof : mixColor(roof, '#7f2f22', 0.3)} />
                  <rect x={-13 + tier * 2} y={-24 + tier * 14} width={26 - tier * 4} height="12" fill="#f4e2c4" />
                </g>
              ))}
            </g>
          ))}
          {[0, 1, 2, 3, 4, 5].map((index) => <g key={`tt${index}`}>{tree(20 + index * 62 + rng() * 16, 186 - rng() * 10, 26 + rng() * 12, trunk, leafLight, leafDark, (rng() - 0.5) * 5)}</g>)}
          <path d="M150 210 q6 -34 26 -50 q16 -12 30 -14" stroke={mixColor(ground, '#ffffff', 0.5)} strokeWidth="7" fill="none" opacity=".45" strokeLinecap="round" />
          <path d={ridge(196, 8, 5, rng, 3.4)} fill={mixColor(ground, '#5f7f5f', 0.32)} />
        </g>
      );
    case 'island':
      return (
        <g>
          <rect x="0" y={HORIZON + 4} width="360" height={210 - HORIZON - 4} fill={mixColor(mid, '#3f9fbf', 0.35)} />
          <path d={`M0 ${HORIZON + 22} q70 -8 130 0 q80 10 150 -6 q50 -10 80 2 V210 H0 Z`} fill={mixColor(mid, '#2f8faf', 0.42)} />
          {[0, 1, 2, 3, 4].map((index) => (
            <path key={index} d={`M${10 + index * 74} ${HORIZON + 30 + index * 6} q30 -7 60 0 q10 3 22 0`} stroke="#fdfaf1" strokeWidth="2.2" fill="none" opacity=".6" strokeLinecap="round" />
          ))}
          <ellipse cx="150" cy="150" rx="62" ry="16" fill={mixColor(mid, '#f0e2b8', 0.45)} />
          <path d="M104 146 q46 -22 92 0 z" fill={mixColor(ground, '#e8d8a8', 0.4)} />
          {[0, 1, 3].map((index) => {
            const x = 122 + index * 26;
            return (
              <g key={index} transform={`translate(${x} 146) rotate(${(index - 1) * 9})`}>
                <path d="M0 0 q-3 -22 2 -30" stroke={mixColor(ground, '#6a5a3a', 0.5)} strokeWidth="3" fill="none" />
                {[0, 1, 2].map((leaf) => (
                  <path key={leaf} d={`M2 -30 q${18 - leaf * 6} ${-2 + leaf * 5} ${26 - leaf * 8} ${8 + leaf * 4} q-${16 - leaf * 4} ${2 - leaf * 2} -${24 - leaf * 6} -${-6 + leaf * 2} z`} fill={mixColor(mid, '#4f9f6f', 0.35 + leaf * 0.1)} />
                ))}
              </g>
            );
          })}
          <g>
            <rect x="216" y="132" width="46" height="18" fill="#f6e8cf" />
            <path d="M210 132 L239 118 L268 132 Z" fill={mixColor(roof, '#a5483a', 0.3)} />
            {[0, 1, 2].map((index) => <rect key={index} x={222 + index * 14} y="150" width="4" height="12" fill={mixColor(ground, '#6a5a3a', 0.45)} />)}
          </g>
          <path d={ridge(198, 6, 5, rng, 2.2)} fill={mixColor(ground, '#e8d8a8', 0.5)} opacity=".7" />
        </g>
      );
    case 'canyon':
      return (
        <g>
          <path d={ridge(HORIZON - 4, 8, 5, rng, 0.5)} fill={mixColor(far, '#ffffff', 0.3)} />
          {[0, 1, 2, 3, 4].map((index) => (
            <path
              key={index}
              d={`M-24 ${HORIZON + 8 + index * 13} q70 ${(rng() - 0.5) * 16} 140 ${(rng() - 0.5) * 12} q80 ${(rng() - 0.5) * 14} 150 ${(rng() - 0.5) * 10} q60 ${(rng() - 0.5) * 10} 118 ${(rng() - 0.5) * 8} V${HORIZON + 21 + index * 13} q-58 10 -118 6 q-70 -6 -150 4 q-70 8 -140 -2 Z`}
              fill={index % 2 ? mixColor(mid, '#ffffff', 0.12) : mixColor(mid, ground, index * 0.14)}
            />
          ))}
          <path d={`M0 186 q80 -10 150 0 q90 12 210 -6 V210 H0 Z`} fill={mixColor(mid, '#5f8f9f', 0.45)} />
          {[0, 1, 2].map((index) => {
            const x = 60 + index * 84 + rng() * 40;
            return <path key={index} d={`M${x} 132 q4 -14 8 -18 q4 4 8 18 z`} fill={mixColor(mid, '#7f4f3f', 0.4)} opacity=".8" />;
          })}
          <path d="M286 84 q10 -6 20 0 q-10 4 -20 0 z" fill={mixColor(ground, '#6a4a3a', 0.4)} />
        </g>
      );
    default:
      return <path d={ridge(HORIZON + 20, 10, 5, rng, 1)} fill={midHill} />;
  }
}

/**
 * 油画风景明信片。
 * 天空、云、丘陵和水面都是 SVG 画出来的：先用调过暖调的底色铺一层，
 * 再叠上一层层的短笔触（像是用画笔一点点堆颜料），
 * 最后压一层厚涂的颜料肌理和暖光，让整张画更接近布面油画的质感。
 */
export function PostcardArt({ destinationId, species, seed, className }: PostcardArtProps) {
  const destination = destinationById(destinationId);
  const random = createRandom(seed);
  const [skyRaw, farRaw, midRaw, groundRaw] = destination.palette;
  const uid = `pc-${destinationId}-${seed}`;
  const night = destination.motif === 'aurora';

  // 日落调色：天顶偏紫、中层偏玫瑰、地平线压成一抹橘金。
  const skyTop = night ? mixColor(skyRaw, '#231a4a', 0.5) : mixColor(skyRaw, VIOLET, 0.44);
  const skyMid = night ? mixColor(skyRaw, VIOLET, 0.28) : mixColor(skyRaw, ROSE, 0.48);
  const horizon = night ? mixColor(farRaw, SUNSET_SOFT, 0.55) : mixColor(farRaw, SUNSET_SOFT, 0.5);
  const cloudLight = mixColor(horizon, '#fff4e0', 0.6);
  const cloudShade = mixColor(farRaw, ROSE, 0.35);
  const sunX = 62 + random() * 226;
  const sunY = night ? 112 : 38 + random() * 26;
  const sunColor = mixColor(farRaw, '#fff2c0', 0.72);
  const petX = 196 + random() * 72;
  const placeFontSize = destination.place.length > 12 ? 9.5 : 10.5;

  // 笔触用的颜料：都从这张明信片自己的配色里调出来，保证和画面是一套颜色。
  const skyInk = [mixColor(skyMid, '#ffffff', 0.42), skyMid, mixColor(skyMid, ROSE, 0.45), mixColor(skyMid, VIOLET, 0.4), mixColor(horizon, '#ffffff', 0.3)];
  const midInk = [mixColor(midRaw, '#ffffff', 0.34), mixColor(midRaw, SUNSET, 0.2), mixColor(midRaw, ROSE, 0.22), midRaw, mixColor(midRaw, VIOLET, 0.2)];
  const groundInk = [mixColor(groundRaw, '#ffffff', 0.24), mixColor(groundRaw, SUNSET_SOFT, 0.3), groundRaw, mixColor(groundRaw, '#2f5238', 0.28)];

  return (
    <svg viewBox="0 0 360 210" className={className} role="img" aria-label={`${destination.place}的风景明信片`} preserveAspectRatio="xMidYMid slice">
      <defs>
        <linearGradient id={`${uid}-sky`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={skyTop} />
          <stop offset="42%" stopColor={skyMid} />
          <stop offset="78%" stopColor={mixColor(skyMid, horizon, 0.62)} />
          <stop offset="100%" stopColor={horizon} />
        </linearGradient>
        <radialGradient id={`${uid}-sun`}>
          <stop offset="0%" stopColor={sunColor} stopOpacity="1" />
          <stop offset="40%" stopColor={sunColor} stopOpacity=".45" />
          <stop offset="100%" stopColor={sunColor} stopOpacity="0" />
        </radialGradient>
        <radialGradient id={`${uid}-glow`}>
          <stop offset="0%" stopColor={SUNSET_SOFT} stopOpacity=".85" />
          <stop offset="55%" stopColor={mixColor(SUNSET, ROSE, 0.4)} stopOpacity=".28" />
          <stop offset="100%" stopColor={VIOLET} stopOpacity="0" />
        </radialGradient>
        <radialGradient id={`${uid}-vignette`}>
          <stop offset="62%" stopColor="#3a2f22" stopOpacity="0" />
          <stop offset="100%" stopColor="#3a2f22" stopOpacity=".22" />
        </radialGradient>
        {/* 手绘感：给整片风景加一点轻微的错位，边缘就不再是尺子画出来的直线 */}
        <filter id={`${uid}-hand`} x="-6%" y="-6%" width="112%" height="112%">
          <feTurbulence type="fractalNoise" baseFrequency="0.035" numOctaves="2" seed={(seed % 53) + 3} result="warp" />
          <feDisplacementMap in="SourceGraphic" in2="warp" scale="3.2" xChannelSelector="R" yChannelSelector="G" />
        </filter>
        {/* 厚涂肌理：用噪声做出颜料堆叠的凹凸，叠加在画面上就像布面的油彩 */}
        <filter id={`${uid}-impasto`}>
          <feTurbulence type="fractalNoise" baseFrequency="0.6 0.42" numOctaves="2" seed={(seed % 71) + 11} result="bump" />
          <feColorMatrix in="bump" type="saturate" values="0" result="gray" />
        </filter>
      </defs>

      <g filter={`url(#${uid}-hand)`}>
        <rect width="360" height="210" fill={`url(#${uid}-sky)`} />
        <ellipse cx={sunX} cy={HORIZON + 10} rx="220" ry="52" fill={sunColor} opacity=".22" />
        <circle cx={sunX} cy={sunY} r="66" fill={`url(#${uid}-sun)`} />
        <circle cx={sunX} cy={sunY} r="13" fill={mixColor(sunColor, '#ffffff', 0.55)} opacity=".95" />

        {/* 天空的笔触：横向铺开，越靠近地平线越暖 */}
        <g opacity=".92">
          {brushStrokes(random, { count: 46, x: [-10, 370], y: [-8, 58], length: [26, 74], width: [7, 16], opacity: [0.12, 0.3], colors: skyInk, angle: 0, jitter: 10 })}
          {brushStrokes(random, { count: 40, x: [-10, 370], y: [44, 104], length: [22, 62], width: [6, 14], opacity: [0.14, 0.32], colors: [mixColor(ROSE, '#ffffff', 0.3), mixColor(horizon, '#ffffff', 0.24), mixColor(skyMid, ROSE, 0.5)], angle: 0, jitter: 8 })}
          {brushStrokes(random, { count: 26, x: [-10, 370], y: [92, 126], length: [18, 46], width: [4, 10], opacity: [0.16, 0.4], colors: [mixColor(horizon, '#ffffff', 0.5), mixColor(horizon, SUNSET_SOFT, 0.5), mixColor(ROSE, horizon, 0.5)], angle: 0, jitter: 6 })}
        </g>

        {/* 云：厚涂的横向色块 */}
        {paintedCloud(74 + random() * 56, 40 + random() * 14, 1.05, random, cloudLight, cloudShade)}
        {paintedCloud(238 + random() * 66, 32 + random() * 18, 0.88, random, cloudLight, cloudShade)}
        {paintedCloud(150 + random() * 88, 72 + random() * 12, 0.62, random, mixColor(cloudLight, horizon, 0.34), mixColor(cloudShade, horizon, 0.4))}

        {paintScene(destination.motif, destination, random, sunX)}

        {/* 中景与近景的笔触，把山、水、草地都揉成颜料堆出来的色块 */}
        <g opacity=".82">
          {brushStrokes(random, { count: 34, x: [-10, 370], y: [HORIZON - 6, GROUND + 6], length: [20, 54], width: [5, 12], opacity: [0.08, 0.2], colors: midInk, angle: 2, jitter: 14 })}
          {brushStrokes(random, { count: 44, x: [-10, 370], y: [GROUND - 4, 210], length: [16, 48], width: [5, 13], opacity: [0.08, 0.22], colors: groundInk, angle: 0, jitter: 16 })}
        </g>

        {/* 落日的暖光洒在整幅画上 */}
        <ellipse cx={sunX} cy={sunY + 46} rx="250" ry="150" fill={`url(#${uid}-glow)`} opacity={night ? 0.4 : 0.5} style={{ mixBlendMode: 'soft-light' }} />
      </g>

      {/* 旅伴站在画面右侧的前景，脚踩在近景地面上 */}
      <g transform={`translate(${petX} 116) scale(0.78)`}>
        <ellipse cx="50" cy="94" rx="27" ry="5.4" fill="rgba(50,40,30,.18)" />
        <PetArt species={species} />
      </g>
      {/* 地名标注：明信片上写清楚这是哪个小镇 / 哪座城市 */}
      <g>
        <rect x="12" y="176" width={destination.place.length * (placeFontSize * 0.98) + 20} height="22" rx="11" fill="rgba(255,255,255,.78)" />
        <text x="22" y="191" fill="#43503f" fontSize={placeFontSize} fontWeight="600" fontFamily='"Yuanti SC", "YouYuan", "PingFang SC", "Microsoft YaHei", sans-serif'>
          {destination.place}
        </text>
        <text x="350" y="191" textAnchor="end" fill="rgba(255,255,255,.92)" fontSize="8.5" letterSpacing="1.6" fontFamily='"Segoe UI", system-ui, sans-serif' stroke="rgba(60,70,60,.35)" strokeWidth="0.5">
          {destination.label}
        </text>
      </g>
      <rect width="360" height="210" filter={`url(#${uid}-impasto)`} opacity=".2" style={{ mixBlendMode: 'overlay' }} />
      <rect width="360" height="210" fill={`url(#${uid}-vignette)`} />
    </svg>
  );
}
