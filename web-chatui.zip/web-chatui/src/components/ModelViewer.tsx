/**
 * 家具 3D 预览：加载 GLB 低模，支持 360° 旋转与缩放。
 */
import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import styles from './ModelViewer.module.css';

interface ModelViewerProps {
  src: string;
  /** 自动旋转，默认开启 */
  autoRotate?: boolean;
}

export function ModelViewer({ src, autoRotate = true }: ModelViewerProps) {
  const hostRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return undefined;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(host.clientWidth, host.clientHeight);
    host.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(38, host.clientWidth / host.clientHeight, 0.1, 500);
    camera.position.set(9, 7, 12);

    scene.add(new THREE.HemisphereLight(0xffffff, 0xbfd0e6, 1.15));
    const key = new THREE.DirectionalLight(0xffffff, 1.5);
    key.position.set(8, 14, 10);
    scene.add(key);
    const rim = new THREE.DirectionalLight(0xa8c8ff, 0.7);
    rim.position.set(-9, 6, -8);
    scene.add(rim);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.autoRotate = autoRotate;
    controls.autoRotateSpeed = 1.6;
    controls.minDistance = 3;
    controls.maxDistance = 90;
    controls.enablePan = false;

    let disposed = false;
    const loader = new GLTFLoader();
    let root: THREE.Object3D | null = null;

    loader.load(src, (gltf) => {
      if (disposed) return;
      root = gltf.scene;
      const box = new THREE.Box3().setFromObject(root);
      const size = box.getSize(new THREE.Vector3());
      const center = box.getCenter(new THREE.Vector3());
      root.position.sub(center);
      scene.add(root);

      const radius = Math.max(size.x, size.y, size.z) * 0.5;
      const distance = radius / Math.tan((camera.fov * Math.PI) / 360) * 1.5;
      camera.position.set(distance * 0.62, radius * 1.25, distance * 0.82);
      controls.target.set(0, 0, 0);
      camera.near = Math.max(0.01, distance / 100);
      camera.far = distance * 40;
      camera.updateProjectionMatrix();
      controls.update();
    });

    const resize = () => {
      if (!host.clientWidth || !host.clientHeight) return;
      camera.aspect = host.clientWidth / host.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(host.clientWidth, host.clientHeight);
    };
    const observer = new ResizeObserver(resize);
    observer.observe(host);

    let raf = 0;
    const tick = () => {
      controls.update();
      renderer.render(scene, camera);
      raf = requestAnimationFrame(tick);
    };
    tick();

    return () => {
      disposed = true;
      cancelAnimationFrame(raf);
      observer.disconnect();
      controls.dispose();
      if (root) {
        root.traverse((child) => {
          const mesh = child as THREE.Mesh;
          if (mesh.geometry) mesh.geometry.dispose();
        });
      }
      renderer.dispose();
      if (renderer.domElement.parentNode === host) host.removeChild(renderer.domElement);
    };
  }, [src, autoRotate]);

  return <div className={styles.viewer} ref={hostRef} />;
}
