import { useEffect, useMemo, useState } from 'react';
import { PetSprite } from './PetSprite';
import { PostcardArt } from './PostcardArt';
import { WorldMap } from './WorldMap';
import type { Destination, Pet, PetSpeciesId, PetState, Postcard } from '../pets';
import {
  DESTINATIONS, PET_SPECIES, continentName, destinationById, destinationsByContinent, formatCountdown,
  formatPostcardDate, petStatus, remainingBondToday, speciesById,
} from '../pets';
import styles from './PetTravelPanel.module.css';

interface PetTravelPanelProps {
  state: PetState;
  activePetId: string | null;
  onSelectActive: (petId: string) => void;
  onAdopt: (speciesId: PetSpeciesId) => void;
  onDispatch: (petId: string, destinationId: string) => void;
  onCollect: (petId: string) => void;
}

const STATUS_TEXT: Record<string, string> = { home: '在家', traveling: '旅行中', returned: '已归来' };

export function PetTravelPanel({ state, activePetId, onSelectActive, onAdopt, onDispatch, onCollect }: PetTravelPanelProps) {
  const [now, setNow] = useState(() => Date.now());
  const [selectedPetId, setSelectedPetId] = useState<string | null>(null);
  const [selectedDestinationId, setSelectedDestinationId] = useState<string | null>(null);
  const [viewing, setViewing] = useState<Postcard | null>(null);

  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  const travelingIds = useMemo(() => state.pets
    .filter((pet) => petStatus(pet, now) === 'traveling' && pet.trip)
    .map((pet) => pet.trip!.destinationId), [state.pets, now]);

  const visitedIds = useMemo(() => Array.from(new Set(state.postcards.map((card) => card.destinationId))), [state.postcards]);
  const selectedDestination = selectedDestinationId ? DESTINATIONS.find((item) => item.id === selectedDestinationId) || null : null;
  const selectedPet = selectedPetId ? state.pets.find((item) => item.id === selectedPetId) || null : null;
  const returnedPets = state.pets.filter((pet) => petStatus(pet, now) === 'returned');
  const bondRoom = remainingBondToday(state);

  const pickDestination = (destination: Destination) => {
    setSelectedDestinationId(destination.id);
    if (selectedPet && petStatus(selectedPet, now) === 'home') onDispatch(selectedPet.id, destination.id);
  };

  const sendPet = (pet: Pet) => {
    if (petStatus(pet, now) !== 'home') return;
    if (selectedDestination) onDispatch(pet.id, selectedDestination.id);
    else setSelectedPetId(pet.id);
  };

  const companions = (
    <div className={styles.block} key="companions">
      <div className={styles.sectionHeading}>
        <div><span>COMPANIONS</span><h3>我的旅伴</h3></div>
        <small>{state.pets.length} 只 · 明信片 {state.postcards.length} 张 · 主页面形象跟随当前旅伴</small>
      </div>
      {state.pets.length ? (
        <div className={styles.petList}>
          {state.pets.map((pet) => {
            const status = petStatus(pet, now);
            const destination = pet.trip ? destinationById(pet.trip.destinationId) : null;
            return (
              <article key={pet.id} className={`${styles.petRow} ${selectedPetId === pet.id ? styles.petRowActive : ''}`}>
                <PetSprite species={pet.speciesId} className={styles.petAvatar} />
                <div className={styles.petInfo}>
                  <strong>{pet.name}<em>{speciesById(pet.speciesId).name}</em></strong>
                  <small>
                    {status === 'traveling' && destination && pet.trip
                      ? `正在${destination.name} · 还有 ${formatCountdown(pet.trip.returnsAt - now)}`
                      : status === 'returned' && destination
                        ? `刚从${destination.place}回来，带着一张明信片`
                        : `已旅行 ${pet.trips} 次 · ${speciesById(pet.speciesId).intro}`}
                  </small>
                </div>
                <div className={styles.petAction}>
                  <button className={`${styles.selectActiveButton} ${activePetId === pet.id ? styles.selectActiveButtonOn : ''}`} type="button" onClick={() => onSelectActive(pet.id)}>
                    {activePetId === pet.id ? '主页面形象' : '设为主角'}
                  </button>
                  <span className={`${styles.statusChip} ${status === 'traveling' ? styles.statusTraveling : status === 'returned' ? styles.statusReturned : styles.statusHome}`}>
                    {STATUS_TEXT[status]}
                  </span>
                  {status === 'returned' ? (
                    <button className={styles.collectButton} type="button" onClick={() => onCollect(pet.id)}>领取明信片</button>
                  ) : (
                    <button className={styles.sendButton} type="button" disabled={status === 'traveling'} onClick={() => sendPet(pet)}>
                      {selectedDestination && status === 'home' ? `去${selectedDestination.name}` : '去旅行'}
                    </button>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      ) : (
        <p className={styles.empty}>还没有旅伴。先用聊天攒下的好感度领养一只，再送它出门看看世界。</p>
      )}
      {returnedPets.length > 0 && <p className={styles.returnHint}>有 {returnedPets.length} 位旅伴已经回家，记得领取明信片。</p>}
    </div>
  );

  const adopt = (
    <div className={styles.block} key="adopt">
      <div className={styles.sectionHeading}>
        <div><span>COMPANION COLLECTION</span><h3>解锁 / 更换旅伴</h3></div>
        <small>好感度 {state.bond} · 青蛙免费</small>
      </div>
      <div className={styles.adoptGrid}>
        {PET_SPECIES.map((species) => {
          const owned = state.pets.some((pet) => pet.speciesId === species.id);
          const affordable = state.bond >= species.price;
          const canUnlock = !owned && affordable;
          return (
            <button
              key={species.id}
              type="button"
              className={`${styles.adoptCard} ${owned ? styles.adoptOwned : canUnlock ? '' : styles.adoptLocked}`}
              onClick={() => owned ? onSelectActive(state.pets.find((pet) => pet.speciesId === species.id)!.id) : onAdopt(species.id)}
              disabled={!owned && !canUnlock}
              title={owned ? `切换到${species.name}` : canUnlock ? (species.price ? `用 ${species.price} 点好感度解锁${species.name}` : `免费解锁${species.name}`) : `还差 ${species.price - state.bond} 点好感度`}
            >
              <PetSprite species={species.id} className={styles.adoptSprite} />
              <span className={styles.adoptName}>{species.name}</span>
              <small>{species.intro}</small>
              <b>{owned ? '已拥有 · 点击切换' : species.price === 0 ? '免费解锁' : `${species.price} 好感度解锁`}</b>
            </button>
          );
        })}
      </div>
    </div>
  );

  const postcards = (
    <div className={styles.block} key="postcards">
      <div className={styles.sectionHeading}>
        <div><span>POSTCARDS</span><h3>油画明信片册</h3></div>
        <small>{state.postcards.length} / 60</small>
      </div>
      {state.postcards.length ? (
        <div className={styles.postcardGrid}>
          {state.postcards.map((card) => {
            const destination = destinationById(card.destinationId);
            return (
              <button key={card.id} type="button" className={styles.postcardCard} onClick={() => setViewing(card)} title={destination.place}>
                <span className={styles.postcardArt}><PostcardArt destinationId={card.destinationId} species={card.speciesId} seed={card.seed} className={styles.artSvg} /></span>
                <span className={styles.postcardMeta}>
                  <strong>{destination.place}</strong>
                  <small>{formatPostcardDate(card.createdAt)}</small>
                </span>
              </button>
            );
          })}
        </div>
      ) : (
        <p className={styles.empty}>旅伴旅行回来时，会带回一张当地风景的油画明信片，上面写着给你的一句话。</p>
      )}
    </div>
  );

  return (
    <div className={styles.layout}>
      <div className={styles.mapColumn}>
        <div className={styles.bondCard}>
          <div className={styles.bondValue}><strong>{state.bond}</strong><small>好感度</small></div>
          <div className={styles.bondText}>
            <b>聊天就能攒好感度</b>
            <p>每和小屿聊一轮 +2，好感度上涨时再多 +2；今天还能获得 {bondRoom} 点。</p>
          </div>
        </div>

        <div className={styles.sectionHeading}>
          <div><span>WORLD MAP</span><h3>去哪里旅行</h3></div>
          <small>共 {DESTINATIONS.length} 个目的地 · 六大洲</small>
        </div>

        <WorldMap
          destinations={DESTINATIONS}
          selectedId={selectedDestinationId}
          travelingIds={travelingIds}
          visitedIds={visitedIds}
          onPick={pickDestination}
        />

        <div className={styles.destinationBar}>
          <div className={styles.destinationInfo}>
            <span>{selectedDestination ? `${selectedDestination.label} · ${selectedDestination.region}` : 'DESTINATION'}</span>
            <strong>
              {selectedDestination
                ? `${selectedDestination.place} · 约 ${selectedDestination.minutes} 分钟`
                : selectedPet ? `先在地图上挑个地方，送 ${selectedPet.name} 出发` : '点一个地点，再选一位旅伴'}
            </strong>
          </div>
          {state.pets.length > 0 && selectedDestination ? (
            <div className={styles.petChips}>
              {state.pets.map((pet) => {
                const status = petStatus(pet, now);
                return (
                  <button
                    key={pet.id}
                    type="button"
                    className={`${styles.petChip} ${selectedPetId === pet.id ? styles.petChipActive : ''}`}
                    disabled={status !== 'home'}
                    onClick={() => sendPet(pet)}
                    title={status === 'home' ? `让${pet.name}去${selectedDestination.name}` : `${pet.name}${STATUS_TEXT[status]}`}
                  >
                    <PetSprite species={pet.speciesId} className={styles.chipSprite} withShadow={false} />
                    {pet.name}
                  </button>
                );
              })}
            </div>
          ) : (
            selectedPet && <span className={styles.dispatchHint}>在地图上挑一个地点，{selectedPet.name} 就会出发</span>
          )}
        </div>

        <div className={styles.registry}>
          {destinationsByContinent().map((group) => (
            <div className={styles.registryRow} key={group.id}>
              <span className={styles.registryName}>{group.name}</span>
              <div className={styles.registryItems}>
                {group.items.map((destination) => (
                  <button
                    key={destination.id}
                    type="button"
                    className={`${styles.registryItem} ${selectedDestinationId === destination.id ? styles.registryItemActive : ''}`}
                    onClick={() => pickDestination(destination)}
                    title={`${destination.place} · ${destination.region} · 约 ${destination.minutes} 分钟`}
                  >
                    {destination.name}
                    {visitedIds.includes(destination.id) && <em aria-hidden="true">✉</em>}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className={styles.sideColumn}>
        {state.pets.length ? [companions, postcards, adopt] : [companions, adopt, postcards]}
      </div>

      {viewing && (
        <div className={styles.viewer} role="dialog" aria-modal="true" aria-label="明信片">
          <div className={styles.viewerCard}>
            <button className={styles.viewerClose} type="button" onClick={() => setViewing(null)} aria-label="收起明信片">×</button>
            <div className={styles.viewerArt}>
              <PostcardArt destinationId={viewing.destinationId} species={viewing.speciesId} seed={viewing.seed} className={styles.artSvg} />
              <span className={styles.stamp}>
                <b>{destinationById(viewing.destinationId).label}</b>
                <small>{formatPostcardDate(viewing.createdAt)}</small>
              </span>
            </div>
            <div className={styles.viewerNote}>
              <span className={styles.handwriting}>TO 主人</span>
              <p>{viewing.blessing}</p>
              <div className={styles.viewerMeta}>
                <span><PetSprite species={viewing.speciesId} className={styles.metaSprite} withShadow={false} />{viewing.petName}</span>
                <span>{destinationById(viewing.destinationId).place}</span>
                <span>{destinationById(viewing.destinationId).region} · {continentName(destinationById(viewing.destinationId).continent)}</span>
                <span>{destinationById(viewing.destinationId).arrival}</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
