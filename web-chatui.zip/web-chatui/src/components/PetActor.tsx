/**
 * 会说话的小动物（会说话的汤姆猫式互动）。
 *
 * 点击旅伴形象时，它会：
 * - 切换一个表情：配色滤镜 + 腮红 + 表情符号（爱心 / 星星 / 睡意…）一起变化；
 * - 做一个随机小动作：蹦跳、扭一扭、点头、转圈、歪头、欢呼、伸懒腰、害羞；
 * - 在头顶弹出对话框，对主人说一句撒娇的话。
 *
 * 每个物种只有一张静态插画，所以「表情」由滤镜 + 腮红 + 符号 + 动作动画共同表达，
 * 这样以后换素材时不必为每个物种单独准备多张表情图。
 */

import { useCallback, useEffect, useRef, useState } from 'react';
import type { CSSProperties } from 'react';
import type { PetSpeciesId } from '../pets';
import { speciesById } from '../pets';
import { playSfx } from '../audio';
import { petImageSrc } from './PetSprite';
import styles from './PetActor.module.css';

type PetActionId = 'hop' | 'wiggle' | 'nod' | 'spin' | 'tilt' | 'cheer' | 'stretch' | 'shy';
type PetMoodId = 'happy' | 'love' | 'shy' | 'excited' | 'sleepy' | 'proud';

interface Spark {
  glyph: string;
  /** 相对于形象框的百分比位置 */
  x: number;
  y: number;
  delay: number;
  size: number;
}

interface MoodSpec {
  label: string;
  /** 头顶弹出的表情符号 */
  emote: string;
  /** 叠加在图片上的配色滤镜 */
  filter: string;
  /** 身后的柔光颜色 */
  glow: string;
  blush: 'none' | 'soft' | 'strong';
  sparks: Spark[];
}

const MOODS: Record<PetMoodId, MoodSpec> = {
  happy: {
    label: '开心',
    emote: '😊',
    filter: 'brightness(1.04) saturate(1.06)',
    glow: 'rgba(255, 199, 122, .55)',
    blush: 'soft',
    sparks: [
      { glyph: '✨', x: 16, y: 24, delay: 0, size: 15 },
      { glyph: '✧', x: 80, y: 32, delay: .5, size: 12 },
    ],
  },
  love: {
    label: '心动',
    emote: '💗',
    filter: 'brightness(1.05) saturate(1.14) hue-rotate(-6deg)',
    glow: 'rgba(255, 138, 170, .58)',
    blush: 'strong',
    sparks: [
      { glyph: '💗', x: 13, y: 20, delay: 0, size: 17 },
      { glyph: '💕', x: 80, y: 16, delay: .45, size: 14 },
      { glyph: '💖', x: 72, y: 40, delay: .9, size: 12 },
    ],
  },
  shy: {
    label: '害羞',
    emote: '💞',
    filter: 'brightness(1.03) saturate(1.1)',
    glow: 'rgba(255, 168, 186, .55)',
    blush: 'strong',
    sparks: [
      { glyph: '💞', x: 15, y: 30, delay: .1, size: 14 },
      { glyph: '﹏', x: 82, y: 24, delay: .6, size: 15 },
    ],
  },
  excited: {
    label: '兴奋',
    emote: '🌟',
    filter: 'brightness(1.07) saturate(1.2)',
    glow: 'rgba(255, 214, 110, .6)',
    blush: 'soft',
    sparks: [
      { glyph: '🌟', x: 18, y: 14, delay: 0, size: 16 },
      { glyph: '✦', x: 78, y: 26, delay: .4, size: 14 },
      { glyph: '✨', x: 62, y: 8, delay: .8, size: 12 },
    ],
  },
  sleepy: {
    label: '困倦',
    emote: '💤',
    filter: 'brightness(.97) saturate(.88)',
    glow: 'rgba(150, 170, 210, .5)',
    blush: 'none',
    sparks: [
      { glyph: '💤', x: 78, y: 16, delay: 0, size: 16 },
      { glyph: 'z', x: 88, y: 30, delay: .6, size: 13 },
    ],
  },
  proud: {
    label: '得意',
    emote: '⭐',
    filter: 'brightness(1.04) saturate(1.08) hue-rotate(6deg)',
    glow: 'rgba(255, 200, 90, .55)',
    blush: 'soft',
    sparks: [
      { glyph: '⭐', x: 20, y: 12, delay: 0, size: 15 },
      { glyph: '✧', x: 82, y: 22, delay: .5, size: 13 },
    ],
  },
};

/** 按顺序轮换，保证每次都换一个表情 / 动作，不会连着重复 */
const MOOD_ORDER: PetMoodId[] = ['happy', 'love', 'shy', 'excited', 'proud', 'sleepy'];
const ACTION_ORDER: PetActionId[] = ['hop', 'wiggle', 'nod', 'spin', 'tilt', 'cheer', 'stretch', 'shy'];

const BURST_COUNT = 6;

/** 点击时撒出来的小爱心 / 小星星 */
const COMMON_LINES = [
  '{owner}，我最喜欢你啦！',
  '抱抱～今天也要开开心心的哦',
  '有你在，我什么都不怕',
  '再摸一下嘛，刚刚那下不算',
  '我一直在等你回来呀',
  '{owner}辛苦啦，靠着我歇一会儿吧',
  '你笑起来的时候最好看了',
  '我偷偷把你的名字写进心里了',
  '今天也超级超级想你哦',
  '陪着你，我就很安心',
];

const SPECIES_LINES: Record<PetSpeciesId, string[]> = {
  frog: ['呱呱，{owner}今天也辛苦啦', '下雨天也想紧紧贴着你呀', '呱～给你一个圆滚滚的抱抱'],
  cat: ['喵～让我蹭蹭{owner}', '呼噜呼噜…最喜欢你摸我下巴了', '喵，今天也要好好吃饭哦'],
  dog: ['汪！{owner}回来啦，我等你好久了', '尾巴摇得停不下来啦～', '汪呜，要一直一直在一起哦'],
  penguin: ['咕噜咕噜，冷的时候我抱着你取暖', '最暖和的地方我留给你啦', '团团会一直陪着{owner}看极光'],
  parrot: ['啾～{owner}是世界上最好听的名字', '我学会说：我、喜、欢、你！', '啾啾啾，把好心情全分给你'],
  alpaca: ['呼～我的毛毛可以给你当枕头哦', '慢慢来也没关系，我在这儿等你', '咩～我最喜欢你身上的味道了'],
  deer: ['我胆子小小的，但有你就不怕啦', '点点想把最好看的那片草地留给你', '可以让我轻轻靠一下吗？'],
  fox: ['本狐狸决定，今天只喜欢你一个', '闻一闻…是{owner}的味道，好安心', '嘿嘿，这回真的被我圈住啦'],
};

interface PetActorProps {
  species: PetSpeciesId;
  /** 旅伴的名字，会显示在对话框上 */
  name: string;
  /** 主人称呼，用在对话里 */
  owner?: string;
  /** stage：主页面大形象；compact：房间里的小形象 */
  variant?: 'stage' | 'compact';
}

export function PetActor({ species, name, owner = '主人', variant = 'stage' }: PetActorProps) {
  const [mood, setMood] = useState<PetMoodId>('happy');
  const [action, setAction] = useState<PetActionId | null>(null);
  const [tick, setTick] = useState(0);
  const [line, setLine] = useState<string | null>(null);
  const [burst, setBurst] = useState<number | null>(null);
  const [poked, setPoked] = useState(false);

  const actionTimer = useRef<number | null>(null);
  const lineTimer = useRef<number | null>(null);
  const burstTimer = useRef<number | null>(null);
  const moodIndex = useRef(0);
  const actionIndex = useRef(0);
  const lastLine = useRef('');

  useEffect(() => () => {
    if (actionTimer.current) window.clearTimeout(actionTimer.current);
    if (lineTimer.current) window.clearTimeout(lineTimer.current);
    if (burstTimer.current) window.clearTimeout(burstTimer.current);
  }, []);

  const poke = useCallback(() => {
    setMood(MOOD_ORDER[moodIndex.current++ % MOOD_ORDER.length]);
    setAction(ACTION_ORDER[actionIndex.current++ % ACTION_ORDER.length]);
    setTick((value) => value + 1);
    setPoked(true);

    const pool = [...(SPECIES_LINES[species] ?? []), ...COMMON_LINES];
    let picked = pool[Math.floor(Math.random() * pool.length)];
    if (pool.length > 1 && picked === lastLine.current) {
      picked = pool[(pool.indexOf(picked) + 1) % pool.length];
    }
    lastLine.current = picked;
    setLine(picked.replace(/\{owner\}/g, owner));
    setBurst(Date.now());
    playSfx('pet');

    if (actionTimer.current) window.clearTimeout(actionTimer.current);
    actionTimer.current = window.setTimeout(() => setAction(null), 1200);
    if (lineTimer.current) window.clearTimeout(lineTimer.current);
    lineTimer.current = window.setTimeout(() => setLine(null), 3400);
    if (burstTimer.current) window.clearTimeout(burstTimer.current);
    burstTimer.current = window.setTimeout(() => setBurst(null), 1100);
  }, [owner, species]);

  const spec = MOODS[mood];
  const info = speciesById(species);
  const rootStyle = { '--pet-glow': spec.glow, '--pet-filter': spec.filter } as CSSProperties;
  const actionClass = action ? styles[`action_${action}`] : '';

  return (
    <div className={`${styles.actor} ${variant === 'compact' ? styles.compact : ''}`} style={rootStyle}>
      <span className={styles.glow} aria-hidden="true" />

      {spec.sparks.map((spark, index) => (
        <span
          key={`${mood}-${index}-${tick}`}
          className={styles.spark}
          aria-hidden="true"
          style={{ left: `${spark.x}%`, top: `${spark.y}%`, fontSize: `${spark.size}px`, animationDelay: `${spark.delay}s` }}
        >
          {spark.glyph}
        </span>
      ))}

      <button
        type="button"
        className={`${styles.hit} ${actionClass}`}
        onClick={poke}
        data-sfx="off"
        title={`点一下 ${name}`}
        aria-label={`${name}，一只${info.name}，点一下逗逗它，它会跟你说话`}
      >
        <img className={styles.image} src={petImageSrc(species)} alt={`${name}（${info.name}）`} draggable={false} />
        <span className={`${styles.blush} ${styles[`blush_${spec.blush}`]}`} aria-hidden="true" />
        <span key={`emote-${tick}`} className={styles.emote} aria-hidden="true">{spec.emote}</span>
      </button>

      {burst !== null && (
        <span className={styles.burst} key={burst} aria-hidden="true">
          {Array.from({ length: BURST_COUNT }, (_, index) => {
            const angle = (index / BURST_COUNT) * Math.PI * 2 - Math.PI / 2;
            const distance = 32 + (index % 3) * 9;
            return (
              <i
                key={index}
                style={{
                  '--bx': `${Math.round(Math.cos(angle) * distance)}px`,
                  '--by': `${Math.round(Math.sin(angle) * distance)}px`,
                  animationDelay: `${index * 0.03}s`,
                } as CSSProperties}
              >
                {index % 2 === 0 ? '💗' : '✨'}
              </i>
            );
          })}
        </span>
      )}

      {line && (
        <div className={styles.bubble} role="status" key={`bubble-${tick}`}>
          <b>{name}</b>
          <p>{line}</p>
        </div>
      )}

      {!poked && <span className={styles.hint}>点我呀～</span>}
    </div>
  );
}
