import { Fragment, useEffect, useMemo, useState } from 'react';
import type { RoomFurnitureId, RoomState, AccessoryId, PlacedDecor } from '../room';
import type { Pet, PetSpeciesId, PetState } from '../pets';
import { PET_SPECIES, speciesById } from '../pets';
import { ACCESSORIES, DAILY_STARLIGHT_REWARD, getLocalDateKey, ROOM_FURNITURE } from '../room';
import { petStatus, remainingBondToday } from '../pets';
import {
  countUnlocked,
  generateRoomIntro,
  grantPeakIntimacy,
  isRoomUnlocked,
  loadLitItems,
  loadPeakIntimacy,
  saveLitItems,
  THEMED_ROOMS,
} from '../themedRooms';
import { playSfx } from '../audio';
import { petImageSrc, PetSprite } from './PetSprite';
import { PetActor } from './PetActor';
import { AccessoryIcon, PetAccessoryLayer } from './PetAccessory';
import { PetTravelPanel } from './PetTravelPanel';
import { RoomDecorGame } from './RoomDecorGame';
import { decorIntimacy } from '../decor';
import styles from '../pages/ChatPage.module.css';

export type RoomTab = 'room' | 'decor' | 'wardrobe' | 'travel';

/** 家具布置页的第一项：小屿自己的房间，仍是原来那 8 件家具 */
const HOME_ROOM = 'home';

interface RoomPanelProps {
  storageScope?: string;
  open: boolean;
  tab: RoomTab;
  alias: string;
  room: RoomState;
  petState: PetState;
  activePet: Pet | null;
  activePetId: string | null;
  onSelectActive: (petId: string) => void;
  onClose: () => void;
  onTabChange: (tab: RoomTab) => void;
  onClaimDaily: () => void;
  onBuy: (id: RoomFurnitureId) => void;
  onSelectFurniture: (id: RoomFurnitureId) => void;
  onToggleAccessory: (id: AccessoryId) => void;
  onDecorChange: (next: PlacedDecor[]) => void;
  onMoveAccessory: (speciesId: PetSpeciesId, id: AccessoryId, dx: number, dy: number) => void;
  onResizeAccessory: (speciesId: PetSpeciesId, id: AccessoryId, scale: number) => void;
  onResetAccessories: (speciesId: PetSpeciesId) => void;
  onAdoptPet: (speciesId: PetSpeciesId) => void;
  onDispatchPet: (petId: string, destinationId: string) => void;
  onCollectPet: (petId: string) => void;
}

export function RoomPanel({
  storageScope = 'default', open, tab, alias, room, petState, activePet, activePetId, onSelectActive, onClose, onTabChange, onClaimDaily, onBuy,
  onSelectFurniture, onToggleAccessory, onDecorChange, onMoveAccessory, onResizeAccessory, onResetAccessories, onAdoptPet, onDispatchPet, onCollectPet,
}: RoomPanelProps) {
  const [themeId, setThemeId] = useState<string>(HOME_ROOM);
  const [litItems, setLitItems] = useState(() => loadLitItems(storageScope));

  useEffect(() => { saveLitItems(litItems, storageScope); }, [litItems, storageScope]);

  const [peakVersion, setPeakVersion] = useState(0);
  const intimacy = useMemo(() => loadPeakIntimacy(petState.bond, storageScope), [petState.bond, storageScope, peakVersion]);
  /** 测试用：一次性加亲密度，用来解锁全部家具 */
  const grantIntimacy = (delta: number) => {
    grantPeakIntimacy(delta, storageScope);
    setPeakVersion((value) => value + 1);
  };

  if (!open) return null;

  const activeFurniture = ROOM_FURNITURE.find((item) => item.id === room.activeFurniture) || ROOM_FURNITURE[0];
  const theme = THEMED_ROOMS.find((entry) => entry.id === themeId) ?? null;
  const litKeys = litItems[themeId] ?? [];
  const unlockedCount = theme ? countUnlocked(theme, intimacy) : 0;
  const roomUnlocked = theme ? isRoomUnlocked(theme, intimacy) : false;
  const dailyClaimed = room.lastDailyClaim === getLocalDateKey();
  const now = Date.now();
  const homePet = petState.pets.find((pet) => petStatus(pet, now) !== 'traveling');
  const waiting = petState.pets.filter((pet) => petStatus(pet, now) === 'returned').length;
  const activeAccessories = ACCESSORIES.filter((item) => room.accessories.includes(item.id));
  const activeSpecies: PetSpeciesId = activePet?.speciesId || 'frog';
  const hasCustomOffsets = activeAccessories.some((item) => room.accessoryOffsets[`${activeSpecies}:${item.id}`]);

  const toggleLit = (key: string) => {
    if (!theme) return;
    playSfx('toggle');
    setLitItems((current) => {
      const keys = current[themeId] ?? [];
      return { ...current, [themeId]: keys.includes(key) ? keys.filter((entry) => entry !== key) : [...keys, key] };
    });
  };

  const lightAll = () => {
    if (!theme) return;
    playSfx('click');
    setLitItems((current) => ({ ...current, [themeId]: theme.items.filter((item) => intimacy >= item.intimacy).map((item) => item.key) }));
  };

  const clearLit = () => {
    if (!theme) return;
    playSfx('click');
    setLitItems((current) => ({ ...current, [themeId]: [] }));
  };

  return (
    <div className={styles.backdrop} role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <section className={`${styles.panel} ${styles.morning}`} role="dialog" aria-modal="true" aria-labelledby="room-title">
        <header className={styles.roomHeader}>
          <div>
            <span className={styles.eyebrow}>PERSONAL SPACE / 01</span>
            <h2 id="room-title">小屿的房间</h2>
            <p>给 {alias} 留一盏灯，也给今天留一个落脚处</p>
          </div>
          <div className={styles.headerRight}>
            <div className={styles.coinBalance}><span>♥</span><strong>{petState.bond}</strong><small>亲密度 · 今日还可 {remainingBondToday(petState)}</small></div>
            <div className={styles.coinBalance}><span>✦</span><strong>{room.starCoins}</strong><small>星光币</small></div>
            <button className={styles.closeButton} type="button" onClick={onClose} aria-label="关闭小屿的房间">×</button>
          </div>
        </header>

        <nav className={styles.tabs} aria-label="房间功能">
          <button className={tab === 'room' ? styles.tabActive : ''} type="button" onClick={() => onTabChange('room')}>家具布置</button>
          <button className={tab === 'decor' ? styles.tabActive : ''} type="button" onClick={() => onTabChange('decor')}>房间换装</button>
          <button className={tab === 'wardrobe' ? styles.tabActive : ''} type="button" onClick={() => onTabChange('wardrobe')}>配饰</button>
          <button className={tab === 'travel' ? styles.tabActive : ''} type="button" onClick={() => onTabChange('travel')}>旅伴{waiting > 0 ? ` · ${waiting} 张待领` : ''}</button>
        </nav>

        {tab === 'room' && (
          <div className={styles.roomLayout}>
            <div className={styles.sceneColumn}>
              <div className={styles.themeStrip} aria-label="选择房间主题">
                <button
                  type="button"
                  className={themeId === HOME_ROOM ? styles.themeChipActive : styles.themeChip}
                  onClick={() => { setThemeId(HOME_ROOM); playSfx('click'); }}
                >
                  小屿的房间
                </button>
                {THEMED_ROOMS.map((entry) => (
                  <button
                    key={entry.id}
                    type="button"
                    className={themeId === entry.id ? styles.themeChipActive : styles.themeChip}
                    onClick={() => { setThemeId(entry.id); playSfx('click'); }}
                  >
                    {isRoomUnlocked(entry, intimacy) ? entry.name : `🔒 ${entry.name}`}
                  </button>
                ))}
              </div>

              {theme ? (
                <div
                  className={styles.themeStage}
                  style={{ aspectRatio: `${theme.width} / ${theme.height}`, maxWidth: `${((theme.width / theme.height) * 62).toFixed(1)}vh` }}
                  aria-label={`${theme.name}样板间，已点亮 ${litKeys.length} 件家具`}
                >
                  <img className={styles.themeBackdrop} src={theme.cover} alt={`${theme.name}样板间`} draggable={false} />
                  {theme.items.map((item) => {
                    if (intimacy < item.intimacy) {
                      return (
                        <Fragment key={item.key}>
                          <span
                            className={styles.markDim}
                            style={{ left: `${item.x}%`, top: `${item.y}%`, width: `${item.w}%`, height: `${item.h}%` }}
                            aria-hidden="true"
                          />
                          <span
                            className={styles.markLocked}
                            style={{ left: `${item.x}%`, top: `${item.y}%` }}
                            title={`${item.name} · 亲密度 ${item.intimacy} 解锁`}
                          >
                            🔒 未解锁
                          </span>
                        </Fragment>
                      );
                    }
                    if (!litKeys.includes(item.key)) return null;
                    return (
                      <button
                        key={item.key}
                        type="button"
                        className={styles.markLit}
                        style={{ left: `${item.x}%`, top: `${item.y}%` }}
                        onClick={() => toggleLit(item.key)}
                        title={`${item.name} · 再点一次就收起`}
                      >
                        ✦ {item.name}
                      </button>
                    );
                  })}
                  {homePet && <span className={styles.roomPet}><PetActor species={homePet.speciesId} name={homePet.name} owner={alias} variant="compact" /></span>}
                  <div className={styles.themeCaption}>
                    <span>{theme.name}</span>
                    <span>{roomUnlocked ? `已点亮 ${litKeys.length} / ${theme.items.length} 件家具` : `亲密度 ${theme.unlock} 解锁这间小屋`}</span>
                  </div>
                </div>
              ) : (
                <div className={`${styles.roomScene} ${styles[`scene_${room.activeFurniture}`]}`} aria-label={`${activeFurniture.name}，${activeFurniture.action}`}>
                  <>
                    <span className={`${styles.roomCloud} ${styles.roomCloudOne}`} />
                    <span className={`${styles.roomCloud} ${styles.roomCloudTwo}`} />
                    <span className={styles.roomSunGlow} />
                    <span className={styles.roomDust}>✦　·　✧　·　✦</span>
                  </>
                  <div className={styles.sceneWindow}><span>✦</span><i /><b /></div>
                  <div className={`${styles.roomFurniture} ${styles.furnitureSofa} ${room.ownedFurniture.includes('sofa') ? styles.owned : ''}`}><span>▰</span></div>
                  <div className={`${styles.roomFurniture} ${styles.furnitureCoffee} ${room.ownedFurniture.includes('coffee') ? styles.owned : ''}`}><span>☕</span></div>
                  <div className={`${styles.roomFurniture} ${styles.furnitureBookshelf} ${room.ownedFurniture.includes('bookshelf') ? styles.owned : ''}`}><span>▤</span></div>
                  <div className={`${styles.roomFurniture} ${styles.furnitureRug} ${room.ownedFurniture.includes('rug') ? styles.owned : ''}`}><span>⌁</span></div>
                  <div className={`${styles.roomFurniture} ${styles.furnitureRecord} ${room.ownedFurniture.includes('record') ? styles.owned : ''}`}><span>◉</span></div>
                  <div className={`${styles.roomFurniture} ${styles.furnitureLamp} ${room.ownedFurniture.includes('lamp') ? styles.owned : ''}`}><span>♧</span></div>
                  <div className={`${styles.roomFurniture} ${styles.furniturePlant} ${room.ownedFurniture.includes('plant') ? styles.owned : ''}`}><span>♣</span></div>
                  <div className={`${styles.roomCharacter} ${styles[`pose_${room.activeFurniture}`]}`}>
                    <img className={styles.roomCharacterArt} src={activePet ? petImageSrc(activePet.speciesId) : petImageSrc('frog')} alt={`${activePet?.name || '小蛙'}在房间里`} />
                    <PetAccessoryLayer items={activeAccessories.map((item) => item.id)} species={activeSpecies} variant="room" offsets={room.accessoryOffsets} />
                    {(room.activeFurniture === 'sofa' || room.activeFurniture === 'bookshelf' || room.activeFurniture === 'rug') && <span className={styles.characterProp}>▤</span>}
                    {room.activeFurniture === 'coffee' && <span className={styles.characterProp}>☕</span>}
                    {room.activeFurniture === 'record' && <span className={styles.characterProp}>◉</span>}
                    {room.activeFurniture === 'lamp' && <span className={styles.characterProp}>✎</span>}
                    {room.activeFurniture === 'plant' && <span className={styles.characterProp}>♧</span>}
                  </div>
                  {homePet && <span className={styles.roomPet}><PetActor species={homePet.speciesId} name={homePet.name} owner={alias} variant="compact" /></span>}
                  <div className={styles.sceneFloor} />
                  <div className={styles.actionLabel}>
                    <span>{waiting > 0 ? `${waiting} 张明信片待领取` : 'NOW PLAYING'}</span>
                    <strong>{waiting > 0 ? '旅伴已经回到家，去旅伴页看看' : homePet ? `${homePet.name}${activeFurniture.action}` : activeFurniture.action}</strong>
                  </div>
                </div>
              )}

              <div className={styles.sceneFooter}>
                <span>{theme ? theme.name : '小屿的房间'}</span>
                <span>{theme ? `已点亮 ${litKeys.length} / ${theme.items.length} 件家具` : `${room.ownedFurniture.length} / ${ROOM_FURNITURE.length} 件家具`}</span>
              </div>
            </div>

            <div className={styles.shopColumn}>
              <div className={styles.rewardCard}>
                <div className={styles.rewardIcon}>✦</div>
                <div><strong>今日陪伴奖励</strong><p>陪小屿聊聊，收下 {DAILY_STARLIGHT_REWARD} 枚星光币</p></div>
                <button type="button" onClick={onClaimDaily} disabled={dailyClaimed}>{dailyClaimed ? '已领取' : `+${DAILY_STARLIGHT_REWARD}`}</button>
              </div>

              {theme ? (
                <>
                  <div className={styles.shopHeading}>
                    <div><span>THEMED ROOM</span><h3>{theme.name}</h3></div>
                    <small>亲密度 {intimacy} · 已解锁 {unlockedCount}/{theme.items.length}</small>
                  </div>
                  <p className={styles.themeIntro}>{theme.intro}　{generateRoomIntro(theme, intimacy, alias)}</p>
                  <div className={styles.themeTools}>
                    <button type="button" onClick={lightAll} disabled={!unlockedCount}>点亮已解锁</button>
                    <button type="button" onClick={clearLit} disabled={!litKeys.length}>收起全部</button>
                  </div>
                  <div className={styles.itemList}>
                    {theme.items.map((item) => {
                      const itemUnlocked = intimacy >= item.intimacy;
                      const active = litKeys.includes(item.key);
                      return <article className={`${styles.itemCard} ${active ? styles.itemActive : ''}`} key={item.key}>
                        <button
                          className={styles.itemSelect}
                          type="button"
                          onClick={() => toggleLit(item.key)}
                          disabled={!itemUnlocked || !roomUnlocked}
                          aria-label={itemUnlocked ? `${active ? '收起' : '点亮'}${item.name}` : `${item.name}尚未解锁`}
                        >
                          <span className={`${styles.itemThumb} ${itemUnlocked ? '' : styles.itemThumbLocked}`}>
                            <img src={item.icon} alt="" loading="lazy" draggable={false} />
                          </span>
                          <span>
                            <strong>{item.name}</strong>
                            <small>{!itemUnlocked ? `亲密度 ${item.intimacy} 解锁` : active ? '已在房间里点亮' : '点击点亮这件家具'}</small>
                          </span>
                        </button>
                        {itemUnlocked ? <span className={styles.ownedLabel}>{active ? '已点亮' : '未点亮'}</span> : <span className={styles.lockLabel}>未解锁</span>}
                      </article>;
                    })}
                  </div>
                </>
              ) : (
                <>
                  <div className={styles.shopHeading}><div><span>ROOM EDIT</span><h3>挑一件家具</h3></div><small>星光币 {room.starCoins}</small></div>
                  <div className={styles.itemList}>
                    {ROOM_FURNITURE.map((item) => {
                      const owned = room.ownedFurniture.includes(item.id);
                      const active = room.activeFurniture === item.id;
                      return <article className={`${styles.itemCard} ${active ? styles.itemActive : ''}`} key={item.id}>
                        <button className={styles.itemSelect} type="button" onClick={() => owned && onSelectFurniture(item.id)} disabled={!owned} aria-label={owned ? `选择${item.name}` : `${item.name}尚未拥有`}>
                          <span className={styles.itemIcon}>{item.icon}</span><span><strong>{item.name}</strong><small>{item.description}</small></span>
                        </button>
                        {owned ? <span className={styles.ownedLabel}>{active ? '使用中' : '已拥有'}</span> : <button className={styles.buyButton} type="button" onClick={() => onBuy(item.id)} disabled={room.starCoins < item.price}><span>购买</span><b>{item.price} ✦</b></button>}
                      </article>;
                    })}
                  </div>
                </>
              )}
            </div>
          </div>
        )}

        {tab === 'decor' && (
          <RoomDecorGame
            intimacy={decorIntimacy(intimacy)}
            placed={room.decor}
            onPlacedChange={onDecorChange}
            onGrantIntimacy={grantIntimacy}
            petSpecies={activeSpecies}
            petName={activePet?.name || '小蛙'}
            petAccessories={activeAccessories.map((item) => item.id)}
            petOffsets={room.accessoryOffsets}
          />
        )}

        {tab === 'wardrobe' && (
          <div className={styles.wardrobeLayout}>
            <div className={styles.wardrobePreview}>
              <div className={styles.wardrobeCharacter}>
                <img className={styles.wardrobeCharacterArt} src={activePet ? petImageSrc(activePet.speciesId) : petImageSrc('frog')} alt={`${activePet?.name || '小蛙'}的换装预览`} />
                <PetAccessoryLayer items={activeAccessories.map((item) => item.id)} species={activeSpecies} variant="wardrobe" offsets={room.accessoryOffsets} onMove={(id, dx, dy) => onMoveAccessory(activeSpecies, id, dx, dy)} />
                <span className={styles.wardrobeSparkle}>✦　·　✧</span>
              </div>
              <span>{activePet?.name || '小蛙'} · {activeAccessories.length ? activeAccessories.map((item) => item.name).join('、') : '自然状态'}</span>
              <small>{activeAccessories.length ? '拖动配饰可改位置，右侧滑杆调大小' : activePet ? `${speciesById(activePet.speciesId).name} · 配饰可以自由叠加` : '青蛙是免费初始旅伴'}</small>
              {hasCustomOffsets && <button className={styles.accessoryReset} type="button" onClick={() => onResetAccessories(activeSpecies)}>恢复默认</button>}
            </div>
            <div className={styles.outfitGrid}>
              <div className={styles.shopHeading}><div><span>COMPANION</span><h3>更换小动物</h3></div><small>{petState.pets.length} 只已解锁</small></div>
              <div className={styles.companionPicker}>
                {PET_SPECIES.map((species) => {
                  const pet = petState.pets.find((item) => item.speciesId === species.id);
                  if (!pet) return null;
                  return <button key={pet.id} type="button" className={`${styles.companionChoice} ${activePet?.id === pet.id ? styles.companionChoiceActive : ''}`} onClick={() => onSelectActive(pet.id)}>
                    <PetSprite species={pet.speciesId} className={styles.companionChoiceSprite} />
                    <span><strong>{pet.name}</strong><small>{species.name}</small></span>
                    <i>{activePet?.id === pet.id ? '当前' : '使用'}</i>
                  </button>;
                })}
              </div>
              <div className={styles.shopHeading}><div><span>ACCESSORIES</span><h3>添加小配饰</h3></div><small>{activeAccessories.length ? `已戴 ${activeAccessories.length} 件` : '可自由叠加'}</small></div>
              {ACCESSORIES.map((item) => {
                const active = room.accessories.includes(item.id);
                const scale = room.accessoryOffsets[`${activeSpecies}:${item.id}`]?.scale ?? 1;
                return (
                  <div className={styles.outfitRow} key={item.id}>
                    <button className={`${styles.outfitCard} ${active ? styles.outfitActive : ''}`} type="button" onClick={() => onToggleAccessory(item.id)} aria-pressed={active}>
                      <span className={styles.outfitSwatch} style={{ background: `${item.accent}22`, color: item.accent }}><span className={styles.accessoryIcon}><AccessoryIcon id={item.id} /></span></span>
                      <span><strong>{item.name}</strong><small>{item.description} · {active ? '已佩戴，点击取下' : '点击佩戴'}</small></span>
                      <i>{active ? '✓' : '＋'}</i>
                    </button>
                    {active && (
                      <label className={styles.outfitSize}>
                        <span>大小</span>
                        <input
                          type="range"
                          min={40}
                          max={200}
                          step={5}
                          value={Math.round(scale * 100)}
                          onChange={(event) => onResizeAccessory(activeSpecies, item.id, Number(event.target.value) / 100)}
                        />
                        <b>{Math.round(scale * 100)}%</b>
                      </label>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {tab === 'travel' && (
          <PetTravelPanel state={petState} activePetId={activePetId} onSelectActive={onSelectActive} onAdopt={onAdoptPet} onDispatch={onDispatchPet} onCollect={onCollectPet} />
        )}
      </section>
    </div>
  );
}
