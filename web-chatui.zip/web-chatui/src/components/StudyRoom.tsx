import { useEffect, useMemo, useState } from 'react';
import { playSfx } from '../audio';
import {
  pickImageRatio,
  pickStudyElement,
  resolveStudyImage,
  STUDY_CONFIG,
  STUDY_INTERVAL_SECONDS,
  STUDY_SENTENCES,
} from '../study';
import type { ImageRatio } from '../study';
import styles from './StudyRoom.module.css';

interface StudyRoomProps {
  open: boolean;
  alias: string;
  onClose: () => void;
}

function formatDuration(seconds: number): string {
  const total = Math.max(0, Math.floor(seconds));
  const minutes = Math.floor(total / 60);
  const rest = total % 60;
  return `${String(minutes).padStart(2, '0')}:${String(rest).padStart(2, '0')}`;
}

/** 关闭时直接卸载，下次进入就是全新的专注时段。 */
export function StudyRoom({ open, alias, onClose }: StudyRoomProps) {
  if (!open) return null;
  return <StudyRoomView alias={alias} onClose={onClose} />;
}

function StudyRoomView({ alias, onClose }: { alias: string; onClose: () => void }) {
  const [ratio, setRatio] = useState<ImageRatio>(() => pickImageRatio());
  const [index, setIndex] = useState(() => Math.floor(Math.random() * STUDY_SENTENCES.length));
  const [running, setRunning] = useState(false);
  const [remaining, setRemaining] = useState(STUDY_INTERVAL_SECONDS);
  const [elapsed, setElapsed] = useState(0);
  const [loaded, setLoaded] = useState(false);
  const [failed, setFailed] = useState(false);

  const sentence = STUDY_SENTENCES[index];
  const element = useMemo(() => pickStudyElement(sentence), [sentence]);
  const imageSrc = resolveStudyImage(sentence, element, ratio);

  // 视口决定出图比例：网页 16:9，窄屏 9:16。
  useEffect(() => {
    const query = window.matchMedia('(max-width: 760px)');
    const sync = () => setRatio(query.matches ? 'mobile' : 'web');
    sync();
    query.addEventListener('change', sync);
    return () => query.removeEventListener('change', sync);
  }, []);

  useEffect(() => {
    setLoaded(false);
    setFailed(false);
  }, [imageSrc]);

  // 提前把下一张背景图加载好，轮换时不闪白。
  useEffect(() => {
    const next = STUDY_SENTENCES[(index + 1) % STUDY_SENTENCES.length];
    const preload = new Image();
    preload.src = resolveStudyImage(next, pickStudyElement(next), ratio);
  }, [index, ratio]);

  useEffect(() => {
    if (!running) return;
    const timer = window.setInterval(() => {
      setElapsed((value) => value + 1);
      setRemaining((value) => (value <= 1 ? 0 : value - 1));
    }, 1000);
    return () => window.clearInterval(timer);
  }, [running]);

  // 倒计时归零：自动换到下一句并重置计时。
  useEffect(() => {
    if (!running || remaining > 0) return;
    setIndex((value) => (value + 1) % STUDY_SENTENCES.length);
    setRemaining(STUDY_INTERVAL_SECONDS);
    playSfx('toggle');
  }, [running, remaining]);

  const switchSentence = () => {
    setIndex((value) => (value + 1) % STUDY_SENTENCES.length);
    setRemaining(STUDY_INTERVAL_SECONDS);
    playSfx('toggle');
  };

  const toggleRunning = () => {
    setRunning((value) => !value);
    playSfx('toggle');
  };

  const progress = ((STUDY_INTERVAL_SECONDS - remaining) / STUDY_INTERVAL_SECONDS) * 100;

  return (
    <div className={styles.studyRoom} role="dialog" aria-modal="true" aria-label="自习室">
      <div className={styles.backdrop} aria-hidden="true">
        {!failed && (
          <img
            className={`${styles.background} ${loaded ? styles.backgroundReady : ''}`}
            src={imageSrc}
            alt=""
            onLoad={() => setLoaded(true)}
            onError={() => setFailed(true)}
          />
        )}
        <span className={styles.scrim} />
      </div>

      <header className={styles.topBar}>
        <div className={styles.branding}>
          <span className={styles.eyebrow}>FOCUS ROOM / 自习室</span>
          <strong>{alias} 的自习室</strong>
        </div>
        <div className={styles.timers}>
          <span><small>本次专注</small><b>{formatDuration(elapsed)}</b></span>
          <span><small>换一句还有</small><b>{formatDuration(remaining)}</b></span>
        </div>
        <button className={styles.exitButton} type="button" onClick={onClose}>退出自习室</button>
      </header>

      {(!loaded || failed) && (
        <p className={styles.loading}>
          {failed ? '这张背景没画出来，先给你一张素色纸，文案照旧陪着你。' : '正在为你铺一张安静的背景…'}
        </p>
      )}

      <div className={styles.copyArea}>
        <span className={styles.typeTag}>
          {sentence.type === 'poem' ? '诗词' : '句子'} · {element}
        </span>
        <p className={styles.sentence}>{sentence.content}</p>
        <span className={styles.sourceHint}>
          {sentence.source
            ? `—— ${sentence.source}`
            : (sentence.type === 'poem' ? '古意 · 陪你写完这一段' : '写给正在坚持的你')}
        </span>
      </div>

      <footer className={styles.controls}>
        <div className={styles.progressTrack}>
          <i style={{ width: `${Math.min(100, Math.max(0, progress))}%` }} />
        </div>
        <div className={styles.controlRow}>
          <button className={styles.primaryButton} type="button" onClick={toggleRunning}>
            {running ? '暂停' : '开始专注'}
          </button>
          <button type="button" onClick={switchSentence} disabled={!STUDY_CONFIG.logic.user_switch}>
            换一句
          </button>
          <button type="button" onClick={onClose}>回到陪伴</button>
        </div>
        <span className={styles.note}>配图由 AI 生成且不含文字 · 文案由心屿叠加呈现</span>
      </footer>
    </div>
  );
}
