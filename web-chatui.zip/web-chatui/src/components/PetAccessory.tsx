/**
 * 旅伴配饰（实物佩戴版）。
 *
 * 与旧版「贴纸」不同：这里把每件配饰画成一件真实质感的矢量实物（针织帽、围巾、
 * 发夹、眼镜、挂坠、睡帽），再按物种的头部 / 脖子 / 眼睛锚点戴到小动物身上，
 * 因此看起来是「穿戴着」而不是「贴上去的」。
 *
 * 坐标体系：锚点的 x / y 是相对「小动物图片方形区域」的百分比。所有旅伴素材都是
 * 1:1 的方形插画并以 object-fit: contain 居中显示，所以外层只要给出一个居中的正
 * 方形覆盖层，锚点就能和动物身体对齐（见 ChatPage.module.css 的 .accessoryLayer）。
 */

import type { ReactElement, PointerEvent as ReactPointerEvent } from 'react';
import { useRef } from 'react';
import type { AccessoryId, AccessoryOffset } from '../room';
import type { PetSpeciesId } from '../pets';
import styles from '../pages/ChatPage.module.css';

export type AccessorySlot = 'hat' | 'nightcap' | 'neck' | 'eyes' | 'pin' | 'charm';

/** 配饰归属的穿戴部位：决定层级与基础尺寸 */
const ACCESSORY_SLOT: Record<AccessoryId, AccessorySlot> = {
  leaf_hat: 'hat',
  sleep_cap: 'nightcap',
  moon_scarf: 'neck',
  star_glasses: 'eyes',
  daisy_pin: 'pin',
  lantern_charm: 'charm',
};

/** 每件配饰的基础大小（占方形区域宽度的百分比） */
const SLOT_SIZE: Record<AccessorySlot, number> = {
  hat: 46,
  nightcap: 50,
  neck: 64,
  eyes: 46,
  pin: 22,
  charm: 26,
};

/** 层级：越靠后越在前面 */
const SLOT_Z: Record<AccessorySlot, number> = {
  charm: 1,
  neck: 2,
  eyes: 3,
  pin: 4,
  hat: 5,
  nightcap: 5,
};

interface Anchor {
  /** 锚点中心，相对动物方形区域（百分比） */
  x: number;
  y: number;
  /** 相对基础尺寸的缩放，用于适配不同体型的旅伴 */
  scale: number;
  /** 旋转角度，让配饰更自然地贴合 */
  rotate: number;
}

type SpeciesAnchors = Record<AccessorySlot, Anchor>;

/**
 * 按物种手工校准的佩戴锚点。
 * 数值来自对 public/pets/*.png 每张插画头身比例的实测，改素材时需要同步微调。
 */
const SPECIES_ANCHORS: Record<PetSpeciesId, SpeciesAnchors> = {
  frog: {
    hat: { x: 50, y: 12, scale: 1.16, rotate: -7 },
    nightcap: { x: 47, y: 11, scale: 1.14, rotate: -16 },
    neck: { x: 50, y: 49, scale: 1.18, rotate: 0 },
    eyes: { x: 50, y: 17, scale: 1.18, rotate: 0 },
    pin: { x: 24, y: 17, scale: 1.1, rotate: -12 },
    charm: { x: 77, y: 66, scale: 1.1, rotate: 8 },
  },
  cat: {
    hat: { x: 50, y: 11, scale: 1.16, rotate: -7 },
    nightcap: { x: 47, y: 10, scale: 1.14, rotate: -16 },
    neck: { x: 50, y: 52, scale: 1.16, rotate: 0 },
    eyes: { x: 50, y: 30, scale: 1.14, rotate: 0 },
    pin: { x: 23, y: 21, scale: 1.12, rotate: -14 },
    charm: { x: 76, y: 72, scale: 1.12, rotate: 8 },
  },
  dog: {
    hat: { x: 50, y: 13, scale: 1.14, rotate: -6 },
    nightcap: { x: 47, y: 12, scale: 1.12, rotate: -15 },
    neck: { x: 50, y: 51, scale: 1.14, rotate: 0 },
    eyes: { x: 50, y: 31, scale: 1.12, rotate: 0 },
    pin: { x: 25, y: 23, scale: 1.1, rotate: -12 },
    charm: { x: 75, y: 74, scale: 1.1, rotate: 8 },
  },
  penguin: {
    hat: { x: 50, y: 10, scale: 1.14, rotate: -6 },
    nightcap: { x: 47, y: 9, scale: 1.12, rotate: -15 },
    neck: { x: 50, y: 47, scale: 1.16, rotate: 0 },
    eyes: { x: 50, y: 28, scale: 1.12, rotate: 0 },
    pin: { x: 27, y: 19, scale: 1.1, rotate: -12 },
    charm: { x: 74, y: 70, scale: 1.1, rotate: 8 },
  },
  parrot: {
    hat: { x: 53, y: 16, scale: 0.84, rotate: -8 },
    nightcap: { x: 50, y: 15, scale: 0.82, rotate: -17 },
    neck: { x: 52, y: 55, scale: 0.9, rotate: 0 },
    eyes: { x: 53, y: 33, scale: 0.84, rotate: 0 },
    pin: { x: 36, y: 23, scale: 0.82, rotate: -12 },
    charm: { x: 71, y: 74, scale: 0.86, rotate: 8 },
  },
  alpaca: {
    hat: { x: 53, y: 12, scale: 0.8, rotate: -6 },
    nightcap: { x: 50, y: 11, scale: 0.78, rotate: -15 },
    neck: { x: 53, y: 45, scale: 0.86, rotate: 0 },
    eyes: { x: 53, y: 31, scale: 0.76, rotate: 0 },
    pin: { x: 42, y: 21, scale: 0.72, rotate: -10 },
    charm: { x: 66, y: 66, scale: 0.82, rotate: 8 },
  },
  deer: {
    hat: { x: 50, y: 21, scale: 0.84, rotate: -6 },
    nightcap: { x: 47, y: 20, scale: 0.82, rotate: -15 },
    neck: { x: 50, y: 56, scale: 0.92, rotate: 0 },
    eyes: { x: 50, y: 37, scale: 0.82, rotate: 0 },
    pin: { x: 33, y: 27, scale: 0.82, rotate: -12 },
    charm: { x: 70, y: 78, scale: 0.88, rotate: 8 },
  },
  fox: {
    hat: { x: 58, y: 17, scale: 0.96, rotate: -6 },
    nightcap: { x: 55, y: 16, scale: 0.94, rotate: -15 },
    neck: { x: 58, y: 53, scale: 1.02, rotate: 0 },
    eyes: { x: 58, y: 34, scale: 0.96, rotate: 0 },
    pin: { x: 43, y: 25, scale: 0.92, rotate: -12 },
    charm: { x: 76, y: 74, scale: 0.98, rotate: 8 },
  },
};

/* ── 配饰实物绘制 ─────────────────────────────────────────── */

function LeafHat(): ReactElement {
  return (
    <svg viewBox="0 0 100 100" className={styles.accessoryArt}>
      <defs>
        <linearGradient id="xaLeafHat" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#b7d39a" />
          <stop offset="1" stopColor="#7d9d7f" />
        </linearGradient>
        <linearGradient id="xaLeafBrim" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#9dbd8b" />
          <stop offset="1" stopColor="#6f8f72" />
        </linearGradient>
      </defs>
      <path d="M17 62C17 36 32 22 50 22C68 22 83 36 83 62Z" fill="url(#xaLeafHat)" stroke="#5f7d63" strokeWidth="2.4" strokeLinejoin="round" />
      <path d="M27 44C33 52 67 52 73 44" fill="none" stroke="#6d8c71" strokeWidth="1.6" opacity="0.7" strokeDasharray="4 4" />
      <path d="M30 30C36 26 44 24 50 24" fill="none" stroke="#e6f2da" strokeWidth="3" strokeLinecap="round" opacity="0.7" />
      <ellipse cx="50" cy="63" rx="34" ry="8.5" fill="url(#xaLeafBrim)" stroke="#5f7d63" strokeWidth="2.4" />
      <path d="M50 22C47 12 52 5 61 4C62 13 58 19 50 22Z" fill="#7fb06c" stroke="#548154" strokeWidth="1.8" strokeLinejoin="round" />
      <path d="M50 22C53 15 49 9 42 9C42 16 45 20 50 22Z" fill="#93c47d" stroke="#548154" strokeWidth="1.6" strokeLinejoin="round" />
      <circle cx="43" cy="52" r="3" fill="#eef6e4" opacity="0.85" />
    </svg>
  );
}

function SleepCap(): ReactElement {
  return (
    <svg viewBox="0 0 100 100" className={styles.accessoryArt}>
      <defs>
        <linearGradient id="xaSleepCap" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#f6d5d6" />
          <stop offset="1" stopColor="#d79fa1" />
        </linearGradient>
        <linearGradient id="xaSleepBrim" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#fbe6e6" />
          <stop offset="1" stopColor="#e2b0b2" />
        </linearGradient>
      </defs>
      <path d="M19 59C22 34 41 24 57 30C71 35 73 22 84 25C87 33 84 40 79 44C68 54 61 46 53 48C42 51 29 57 19 59Z" fill="url(#xaSleepCap)" stroke="#c1898b" strokeWidth="2.4" strokeLinejoin="round" />
      <path d="M24 40C33 45 45 46 55 43" fill="none" stroke="#fdeeee" strokeWidth="2.6" strokeLinecap="round" opacity="0.75" />
      <ellipse cx="47" cy="61" rx="31" ry="8.5" fill="url(#xaSleepBrim)" stroke="#c1898b" strokeWidth="2.4" />
      <circle cx="87" cy="24" r="8.5" fill="#fbe0e0" stroke="#c1898b" strokeWidth="2.2" />
      <path d="M84 19C86 21 88 22 90 21" fill="none" stroke="#e6b6b8" strokeWidth="1.6" strokeLinecap="round" />
      <g fill="#c1898b" opacity="0.7">
        <path d="M78 34l1.6 3.4 3.4 1.6-3.4 1.6L78 44l-1.6-3.4L73 39l3.4-1.6z" />
      </g>
    </svg>
  );
}

function MoonScarf(): ReactElement {
  return (
    <svg viewBox="0 0 100 100" className={styles.accessoryArt}>
      <defs>
        <linearGradient id="xaScarf" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#a9d3dc" />
          <stop offset="1" stopColor="#6f9fb0" />
        </linearGradient>
      </defs>
      <path d="M60 50C66 62 67 76 62 88L50 88C55 76 54 62 48 50Z" fill="url(#xaScarf)" stroke="#5c8695" strokeWidth="2.2" strokeLinejoin="round" />
      <g stroke="#5c8695" strokeWidth="2"><path d="M52 88v6" /><path d="M57 88v6" /><path d="M62 88v6" /></g>
      <path d="M13 33C30 47 70 47 87 33C90 41 87 50 80 52C62 61 38 61 20 52C13 50 10 41 13 33Z" fill="url(#xaScarf)" stroke="#5c8695" strokeWidth="2.4" strokeLinejoin="round" />
      <path d="M22 39C36 48 64 48 78 39" fill="none" stroke="#cfeaf0" strokeWidth="2.6" strokeLinecap="round" opacity="0.8" />
      <path d="M40 46C47 50 55 50 62 47" fill="none" stroke="#5c8695" strokeWidth="1.6" opacity="0.55" />
      <path d="M74 40a6 6 0 1 0 4 10 7.4 7.4 0 1 1-4-10Z" fill="#f2f7d9" stroke="#8fb0ba" strokeWidth="1.4" />
      <circle cx="30" cy="44" r="1.6" fill="#eaf5f7" />
      <circle cx="34" cy="48" r="1.2" fill="#eaf5f7" />
    </svg>
  );
}

function DaisyPin(): ReactElement {
  return (
    <svg viewBox="0 0 100 100" className={styles.accessoryArt}>
      <ellipse cx="50" cy="72" rx="13" ry="5" fill="#8fae86" stroke="#6c8a70" strokeWidth="2.2" transform="rotate(-18 50 72)" />
      <path d="M50 70C46 62 42 56 34 52" fill="none" stroke="#6c8a70" strokeWidth="2.4" strokeLinecap="round" />
      <g fill="#fdfbf2" stroke="#e2d7bd" strokeWidth="1.8">
        <ellipse cx="50" cy="28" rx="9" ry="14" />
        <ellipse cx="50" cy="56" rx="9" ry="14" />
        <ellipse cx="36" cy="42" rx="14" ry="9" />
        <ellipse cx="64" cy="42" rx="14" ry="9" />
        <ellipse cx="40" cy="32" rx="10" ry="7" transform="rotate(-40 40 32)" />
        <ellipse cx="60" cy="32" rx="10" ry="7" transform="rotate(40 60 32)" />
        <ellipse cx="40" cy="52" rx="10" ry="7" transform="rotate(40 40 52)" />
        <ellipse cx="60" cy="52" rx="10" ry="7" transform="rotate(-40 60 52)" />
      </g>
      <circle cx="50" cy="42" r="11" fill="#f4c542" stroke="#d9a72c" strokeWidth="2.2" />
      <circle cx="46" cy="38" r="3" fill="#fbe08a" opacity="0.9" />
      <path d="M50 84C44 88 38 88 33 86" fill="none" stroke="#6c8a70" strokeWidth="2" strokeLinecap="round" opacity="0.7" />
    </svg>
  );
}

function StarGlasses(): ReactElement {
  return (
    <svg viewBox="0 0 100 100" className={styles.accessoryArt}>
      <defs>
        <linearGradient id="xaLens" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#dce9f7" stopOpacity="0.9" />
          <stop offset="1" stopColor="#aebfe0" stopOpacity="0.85" />
        </linearGradient>
      </defs>
      <path d="M8 34L20 30" stroke="#5c6478" strokeWidth="3.4" strokeLinecap="round" />
      <path d="M92 34L80 30" stroke="#5c6478" strokeWidth="3.4" strokeLinecap="round" />
      <path d="M45 50C47 46 53 46 55 50" fill="none" stroke="#5c6478" strokeWidth="3.2" />
      <circle cx="30" cy="52" r="20" fill="url(#xaLens)" stroke="#5c6478" strokeWidth="3.6" />
      <circle cx="70" cy="52" r="20" fill="url(#xaLens)" stroke="#5c6478" strokeWidth="3.6" />
      <path d="M24 44C27 41 31 40 34 41" fill="none" stroke="#ffffff" strokeWidth="3" strokeLinecap="round" opacity="0.85" />
      <path d="M64 44C67 41 71 40 74 41" fill="none" stroke="#ffffff" strokeWidth="3" strokeLinecap="round" opacity="0.85" />
      <g fill="#f4c542">
        <path d="M30 42l3 7 7 3-7 3-3 7-3-7-7-3 7-3z" />
        <path d="M70 42l2.4 5.6L78 50l-5.6 2.4L70 58l-2.4-5.6L62 50l5.6-2.4z" opacity="0.9" />
      </g>
    </svg>
  );
}

function LanternCharm(): ReactElement {
  return (
    <svg viewBox="0 0 100 100" className={styles.accessoryArt}>
      <defs>
        <radialGradient id="xaLantern" cx="0.42" cy="0.36" r="0.72">
          <stop offset="0" stopColor="#ffd9a8" />
          <stop offset="0.6" stopColor="#f0a878" />
          <stop offset="1" stopColor="#d4794f" />
        </radialGradient>
      </defs>
      <path d="M50 4C54 10 54 16 50 22" fill="none" stroke="#a8763f" strokeWidth="2.4" strokeLinecap="round" />
      <path d="M46 18h8l3 6H43z" fill="#c98a4f" stroke="#a8763f" strokeWidth="1.8" strokeLinejoin="round" />
      <ellipse cx="50" cy="46" rx="20" ry="22" fill="url(#xaLantern)" stroke="#b06a3f" strokeWidth="2.4" />
      <path d="M31 46h38" stroke="#b06a3f" strokeWidth="1.4" opacity="0.5" />
      <path d="M35 34c6 4 24 4 30 0" fill="none" stroke="#ffe6c6" strokeWidth="2.4" strokeLinecap="round" opacity="0.7" />
      <path d="M46 68h8l2 5H44z" fill="#c98a4f" stroke="#a8763f" strokeWidth="1.8" strokeLinejoin="round" />
      <g stroke="#d4794f" strokeWidth="2.2" strokeLinecap="round">
        <path d="M48 73v10" /><path d="M52 73v12" /><path d="M56 73v9" />
      </g>
      <circle cx="50" cy="46" r="6" fill="#fff0cf" opacity="0.85" />
    </svg>
  );
}

const ACCESSORY_ART: Record<AccessoryId, () => ReactElement> = {
  leaf_hat: LeafHat,
  sleep_cap: SleepCap,
  moon_scarf: MoonScarf,
  daisy_pin: DaisyPin,
  star_glasses: StarGlasses,
  lantern_charm: LanternCharm,
};

/** 单件配饰的实物图标，可用于图鉴 / 缩略图 */
export function AccessoryIcon({ id }: { id: AccessoryId }) {
  const Art = ACCESSORY_ART[id];
  return <Art />;
}

/** 按物种佩戴的单件配饰：绝对定位到锚点，可手动拖动微调 */
function WornAccessory({
  id,
  species,
  offset,
  interactive,
  onMove,
}: {
  id: AccessoryId;
  species: PetSpeciesId;
  offset: AccessoryOffset;
  interactive: boolean;
  onMove?: (id: AccessoryId, dx: number, dy: number) => void;
}) {
  const slot = ACCESSORY_SLOT[id];
  const anchor = SPECIES_ANCHORS[species][slot];
  const Art = ACCESSORY_ART[id];
  const size = SLOT_SIZE[slot] * anchor.scale * (offset.scale ?? 1);
  const itemRef = useRef<HTMLSpanElement | null>(null);
  const drag = useRef<{ x: number; y: number; dx: number; dy: number } | null>(null);

  const startDrag = (event: ReactPointerEvent<HTMLSpanElement>) => {
    if (!interactive || !onMove) return;
    event.preventDefault();
    event.currentTarget.setPointerCapture(event.pointerId);
    drag.current = { x: event.clientX, y: event.clientY, dx: offset.dx, dy: offset.dy };
  };

  const moveDrag = (event: ReactPointerEvent<HTMLSpanElement>) => {
    const state = drag.current;
    const layer = itemRef.current?.parentElement;
    if (!state || !onMove || !layer) return;
    const rect = layer.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    onMove(
      id,
      state.dx + ((event.clientX - state.x) / rect.width) * 100,
      state.dy + ((event.clientY - state.y) / rect.height) * 100,
    );
  };

  const endDrag = () => {
    drag.current = null;
  };

  return (
    <span
      ref={itemRef}
      className={`${styles.accessoryItem} ${interactive ? styles.accessoryDraggable : ''}`}
      style={{
        left: `${anchor.x + offset.dx}%`,
        top: `${anchor.y + offset.dy}%`,
        width: `${size}%`,
        zIndex: SLOT_Z[slot],
        transform: `translate(-50%, -50%) rotate(${anchor.rotate}deg)`,
      }}
      onPointerDown={startDrag}
      onPointerMove={moveDrag}
      onPointerUp={endDrag}
      onPointerCancel={endDrag}
      role={interactive ? 'button' : undefined}
      tabIndex={interactive ? 0 : undefined}
      title={interactive ? '按住拖动，可以把它挪到合适的位置' : undefined}
      aria-hidden={interactive ? undefined : true}
    >
      <Art />
    </span>
  );
}

/**
 * 旅伴的配饰层：放在小动物图片方形区域的覆盖层里，按物种把小动物穿戴起来。
 * 传入 `onMove` 时（换装预览）配饰支持拖动微调，偏移按物种分别记录。
 */
export function PetAccessoryLayer({
  items,
  species,
  variant,
  offsets,
  onMove,
}: {
  items: AccessoryId[];
  species: PetSpeciesId;
  variant: 'stage' | 'room' | 'wardrobe';
  offsets?: Record<string, AccessoryOffset>;
  onMove?: (id: AccessoryId, dx: number, dy: number) => void;
}) {
  if (items.length === 0) return null;
  const interactive = variant === 'wardrobe' && !!onMove;
  return (
    <span className={`${styles.accessoryLayer} ${styles[`accessoryLayer_${variant}`]}`}>
      {items.map((id) => (
        <WornAccessory
          key={id}
          id={id}
          species={species}
          offset={offsets?.[`${species}:${id}`] || { dx: 0, dy: 0 }}
          interactive={interactive}
          onMove={onMove}
        />
      ))}
    </span>
  );
}
