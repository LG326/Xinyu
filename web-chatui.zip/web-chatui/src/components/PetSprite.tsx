/**
 * 旅伴形象。
 *
 * 图片资源放在 `web-chatui/public/pets/<id>.png`（水彩绘本风、透明背景，512×512），
 * 是抠好背景的小动物插画（早期版本由 `scripts/pets/render-pets.mjs` 生成，现已换成插画素材）。
 * 想换素材时直接替换这些 PNG 即可，组件和样式都不用改。
 *
 * - `PetSprite`：用在列表、领养区等 HTML 场景；
 * - `PetArt`：用在明信片这类 SVG 场景（以 <image> 引用同一张图片）；
 * - `PetActor`：用在主页面舞台与房间里，点一下会切换表情、做小动作并弹出头顶对话。
 */

import type { PetSpeciesId } from '../pets';
import { speciesById } from '../pets';
import styles from './PetSprite.module.css';

interface PetSpriteProps {
  species: PetSpeciesId;
  className?: string;
  /** 兼容旧参数：图片自带柔和投影，这里保留占位 */
  withShadow?: boolean;
}

export function petImageSrc(species: PetSpeciesId): string {
  return `/pets/${species}.png`;
}

/** SVG 场景里的形象：映射到 0-100 的坐标系，和原来的矢量形象尺寸一致 */
export function PetArt({ species }: { species: PetSpeciesId }) {
  return (
    <image
      href={petImageSrc(species)}
      x="0"
      y="0"
      width="100"
      height="100"
      preserveAspectRatio="xMidYMid meet"
    />
  );
}

export function PetSprite({ species, className }: PetSpriteProps) {
  const info = speciesById(species);
  return (
    <span className={className ? `${styles.sprite} ${className}` : styles.sprite}>
      <img className={styles.image} src={petImageSrc(species)} alt={info.name} draggable={false} loading="lazy" />
    </span>
  );
}
