import { useEffect, useState } from 'react';
import { RADIO_TRACKS, getAudioState, playRadioTrack, stepRadio, stopRadio, subscribeAudio } from '../audio';
import panel from '../pages/ChatPage.module.css';
import styles from './RadioCard.module.css';

/**
 * 晚安电台：几首实时合成的纯音乐，可以在面板里直接切歌。
 * 播放时主题音景会自动淡出，停播后再回来。
 */
export function RadioCard() {
  const [audio, setAudio] = useState(() => getAudioState());
  const [listOpen, setListOpen] = useState(false);

  useEffect(() => subscribeAudio(setAudio), []);

  const current = RADIO_TRACKS.find((track) => track.id === audio.radioTrackId) || null;
  const playing = current !== null;
  const label = '晚安电台';

  return (
    <div className={`${panel.statusCard} ${panel.radioCard}`}>
      <span className={panel.cardIcon}>♫</span>
      <div className={styles.body}>
        <div className={styles.head}>
          <div>
            <small>{label}</small>
            <strong className={styles.trackName}>
              {current ? current.name : '还没开始播放'}
              {playing && <span className={styles.bars} aria-hidden="true"><i /><i /><i /></span>}
            </strong>
          </div>
          <button
            className={styles.playButton}
            type="button"
            onClick={() => (playing ? stopRadio() : playRadioTrack(RADIO_TRACKS[0].id))}
            aria-label={playing ? '暂停电台' : '播放电台'}
            title={playing ? '暂停电台' : '播放电台'}
          >
            {playing ? '❙❙' : '▶'}
          </button>
        </div>

        <p>{current ? current.mood : '今晚也可以什么都不做，只听一会儿潮汐。'}</p>

        <div className={styles.controls}>
          <button type="button" onClick={() => stepRadio(-1)} aria-label="上一首" title="上一首">⏮</button>
          <button type="button" onClick={() => (playing ? stopRadio() : playRadioTrack(RADIO_TRACKS[0].id))}>{playing ? '暂停' : '播放'}</button>
          <button type="button" onClick={() => stepRadio(1)} aria-label="下一首" title="下一首">⏭</button>
          <button className={styles.listToggle} type="button" onClick={() => setListOpen((value) => !value)} aria-expanded={listOpen}>
            换一首 {listOpen ? '⌃' : '⌄'}
          </button>
        </div>

        {listOpen && (
          <div className={styles.trackList}>
            {RADIO_TRACKS.map((track) => (
              <button
                key={track.id}
                type="button"
                className={`${styles.track} ${track.id === audio.radioTrackId ? styles.trackActive : ''}`}
                onClick={() => playRadioTrack(track.id)}
                title={track.mood}
              >
                <span>{track.id === audio.radioTrackId ? '❙❙' : '♪'}</span>
                <b>{track.name}</b>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
