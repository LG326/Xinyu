import { useEffect, useState } from 'react';
import { RADIO_TRACKS, getAudioState, setMusicEnabled, setSfxEnabled, setVolume, subscribeAudio } from '../audio';
import type { ThemeName } from '../types';
import styles from './AudioControl.module.css';

interface AudioControlProps {
  theme: ThemeName;
}

const scapeName: Record<ThemeName, string> = {
  morning: '潮汐与风铃',
};

export function AudioControl({ theme }: AudioControlProps) {
  const [audio, setAudio] = useState(() => getAudioState());

  useEffect(() => subscribeAudio(setAudio), []);

  const toggleMusic = () => setMusicEnabled(!audio.musicEnabled);
  const radioTrack = RADIO_TRACKS.find((track) => track.id === audio.radioTrackId) || null;
  const label = !audio.musicEnabled ? '已静音' : radioTrack ? '电台' : '轻音乐';

  return (
    <div className={styles.control}>
      <button
        className={styles.button}
        type="button"
        aria-pressed={audio.musicEnabled}
        aria-label={audio.musicEnabled ? '关闭音乐' : '打开音乐'}
        title={!audio.musicEnabled ? '打开音乐' : radioTrack ? `晚安电台播放中：${radioTrack.name}` : `正在播放：${scapeName[theme]}`}
        onClick={toggleMusic}
      >
        <span className={styles.icon} aria-hidden="true">
          {audio.musicEnabled ? <span className={styles.bars}><i /><i /><i /></span> : '🔇'}
        </span>
        <span className={styles.label}>{label}</span>
      </button>
      <div className={styles.panel} role="group" aria-label="声音设置">
        <div className={styles.row}>
          <span>音量 · {Math.round(audio.volume * 100)}%</span>
          <input
            type="range"
            min={5}
            max={100}
            value={Math.round(audio.volume * 100)}
            aria-label="背景音乐音量"
            onChange={(event) => setVolume(Number(event.target.value) / 100)}
          />
        </div>
        <label className={styles.check} data-sfx="click">
          <input type="checkbox" checked={audio.sfxEnabled} onChange={(event) => setSfxEnabled(event.target.checked)} />
          点击音效
        </label>
        <p className={styles.scape}>
          {!audio.musicEnabled
            ? '音乐已暂停，聊天记录不受影响'
            : radioTrack ? `晚安电台播放中：${radioTrack.name}` : `当前音景：${scapeName[theme]}`}
        </p>
      </div>
    </div>
  );
}
