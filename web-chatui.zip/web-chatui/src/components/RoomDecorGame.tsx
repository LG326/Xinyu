/**
 * 房间换装玩法：空房间画布 + 亲密度解锁 + 拖拽摆放 + 3D 预览。
 */
import { lazy, Suspense, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { PointerEvent as ReactPointerEvent } from 'react';
import type { AccessoryId, PlacedDecor, RoomState } from '../room';
import type { PetSpeciesId } from '../pets';
import { DECOR_ROOMS, decorItemByKey, decorRoomById } from '../decor';
import { PetAccessoryLayer } from './PetAccessory';
import { petImageSrc } from './PetSprite';
import styles from './RoomDecorGame.module.css';

// three.js 只在打开预览弹窗时才加载，避免拖大首屏包体
const ModelViewer = lazy(() => import('./ModelViewer').then((mod) => ({ default: mod.ModelViewer })));

interface RoomDecorGameProps {
  /** 已折算到从 0 起的换装亲密度 */
  intimacy: number;
  placed: PlacedDecor[];
  onPlacedChange: (next: PlacedDecor[]) => void;
  /** 测试用：一次性加亲密度，用来解锁全部家具 */
  onGrantIntimacy?: (delta: number) => void;
  /** 当前所选旅伴：进入房间后会出现的小动物 */
  petSpecies: PetSpeciesId;
  petName: string;
  petAccessories: AccessoryId[];
  petOffsets: RoomState['accessoryOffsets'];
}

interface DragState {
  key: string;
  roomId: string;
  pointerX: number;
  pointerY: number;
  moved: boolean;
  fromCanvas: boolean;
}

const MOVE_THRESHOLD = 5;

export function RoomDecorGame({
  intimacy, placed, onPlacedChange, onGrantIntimacy, petSpecies, petName, petAccessories, petOffsets,
}: RoomDecorGameProps) {
  const canvasRef = useRef<HTMLDivElement | null>(null);
  const dragRef = useRef<DragState | null>(null);
  const petDragRef = useRef(false);
  const [activeRoomId, setActiveRoomId] = useState(DECOR_ROOMS[0].id);
  const [drag, setDrag] = useState<DragState | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [preview, setPreview] = useState<{ roomId: string; key: string } | null>(null);
  // 小动物在每个房间里的落脚点（脚底对齐），选中房间后它就会出现在房间里
  const [petSpots, setPetSpots] = useState<Record<string, { x: number; y: number }>>({});

  const room = decorRoomById(activeRoomId);
  const roomPlaced = useMemo(() => placed.filter((item) => item.roomId === activeRoomId), [placed, activeRoomId]);
  const placedKeys = new Set(roomPlaced.map((item) => item.key));
  const unlockedCount = room.items.filter((item) => intimacy >= item.intimacy).length;

  useEffect(() => {
    if (!toast) return undefined;
    const timer = window.setTimeout(() => setToast(null), 2400);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const toNormalized = useCallback((clientX: number, clientY: number) => {
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return null;
    return {
      x: Math.max(0.03, Math.min(0.97, (clientX - rect.left) / rect.width)),
      y: Math.max(0.03, Math.min(0.97, (clientY - rect.top) / rect.height)),
    };
  }, []);

  const petSpot = petSpots[activeRoomId] ?? { x: 0.5, y: 0.7 };
  const movePet = (clientX: number, clientY: number) => {
    const point = toNormalized(clientX, clientY);
    if (point) setPetSpots((current) => ({ ...current, [activeRoomId]: point }));
  };

  const startDrag = (key: string, event: ReactPointerEvent, fromCanvas: boolean) => {
    const item = decorItemByKey(room, key);
    if (!item) return;
    if (!fromCanvas && intimacy < item.intimacy) {
      setToast(`亲密度达到 ${item.intimacy} 才能解锁「${item.name}」，当前 ${intimacy}`);
      return;
    }
    event.preventDefault();
    const next: DragState = {
      key, roomId: activeRoomId, pointerX: event.clientX, pointerY: event.clientY,
      moved: false, fromCanvas,
    };
    dragRef.current = next;
    setDrag(next);
  };

  useEffect(() => {
    if (!drag) return undefined;
    const onMove = (event: PointerEvent) => {
      const state = dragRef.current;
      if (!state) return;
      const moved = state.moved
        || Math.abs(event.clientX - state.pointerX) > MOVE_THRESHOLD
        || Math.abs(event.clientY - state.pointerY) > MOVE_THRESHOLD;
      const next = { ...state, moved };
      dragRef.current = next;
      setDrag(next);
      if (moved && state.fromCanvas) {
        const point = toNormalized(event.clientX, event.clientY);
        if (point) {
          onPlacedChange(placed.map((entry) => (
            entry.roomId === state.roomId && entry.key === state.key ? { ...entry, ...point } : entry
          )));
        }
      }
    };
    const onUp = (event: PointerEvent) => {
      const state = dragRef.current;
      dragRef.current = null;
      setDrag(null);
      if (!state) return;
      if (!state.moved) {
        setPreview({ roomId: state.roomId, key: state.key });
        return;
      }
      if (!state.fromCanvas) {
        const rect = canvasRef.current?.getBoundingClientRect();
        const inside = rect
          && event.clientX >= rect.left && event.clientX <= rect.right
          && event.clientY >= rect.top && event.clientY <= rect.bottom;
        const point = toNormalized(event.clientX, event.clientY);
        if (rect && inside && point) {
          onPlacedChange([...placed, { roomId: state.roomId, key: state.key, ...point }]);
        }
      }
    };
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
    window.addEventListener('pointercancel', onUp);
    return () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
      window.removeEventListener('pointercancel', onUp);
    };
  }, [drag, placed, onPlacedChange, toNormalized]);

  const removeItem = (roomId: string, key: string) => {
    onPlacedChange(placed.filter((entry) => !(entry.roomId === roomId && entry.key === key)));
  };

  const previewItem = preview ? decorItemByKey(decorRoomById(preview.roomId), preview.key) : null;
  const previewPlaced = preview ? placedKeys.has(preview.key) : false;

  return (
    <div className={styles.decor}>
      <div className={styles.canvasWrap}>
        <div className={styles.roomTabs} role="tablist" aria-label="主题小屋">
          {DECOR_ROOMS.map((entry) => (
            <button
              key={entry.id}
              type="button"
              role="tab"
              aria-selected={entry.id === activeRoomId}
              className={entry.id === activeRoomId ? styles.roomTabActive : ''}
              onClick={() => { setActiveRoomId(entry.id); setPreview(null); }}
            >
              {entry.name}
            </button>
          ))}
        </div>
        <div
          className={styles.canvas}
          ref={canvasRef}
          style={{ backgroundImage: `url(${room.empty})`, aspectRatio: `${room.width} / ${room.height}` }}
        >
          {roomPlaced.map((entry) => {
            const item = decorItemByKey(room, entry.key);
            if (!item) return null;
            const dragging = drag?.key === entry.key && drag.moved;
            // 越靠下（离镜头越近）越大，补一点纵深
            const depth = 1 + (entry.y - 0.5) * 0.22;
            return (
              <div
                key={entry.key}
                className={`${styles.placed} ${dragging ? styles.placedDragging : ''}`}
                style={{
                  left: `${entry.x * 100}%`,
                  top: `${entry.y * 100}%`,
                  width: `${item.w}%`,
                  transform: `translate(-50%, -50%) scale(${depth.toFixed(3)})`,
                  zIndex: Math.round(entry.y * 100),
                }}
                onPointerDown={(event) => startDrag(entry.key, event, true)}
                role="button"
                tabIndex={0}
                title={`${item.name} · 拖动可移动，点击看 3D`}
              >
                <span className={styles.shadow} aria-hidden="true" />
                <img src={item.icon} alt={item.name} draggable={false} />
                <button
                  className={styles.removeBadge}
                  type="button"
                  onPointerDown={(event) => event.stopPropagation()}
                  onClick={(event) => { event.stopPropagation(); removeItem(entry.roomId, entry.key); }}
                  aria-label={`收回${item.name}`}
                >
                  ×
                </button>
              </div>
            );
          })}

          {/* 所选小动物：选择哪间房就出现在哪间房里，可拖动换位置 */}
          <div
            className={styles.petSpot}
            style={{ left: `${petSpot.x * 100}%`, top: `${petSpot.y * 100}%`, zIndex: Math.round(petSpot.y * 100) + 1 }}
            role="img"
            aria-label={`${petName}在${room.name}里`}
            title={`${petName} · 拖动可以换个位置`}
            onPointerDown={(event) => {
              petDragRef.current = true;
              event.preventDefault();
              event.currentTarget.setPointerCapture(event.pointerId);
            }}
            onPointerMove={(event) => { if (petDragRef.current) movePet(event.clientX, event.clientY); }}
            onPointerUp={() => { petDragRef.current = false; }}
            onPointerCancel={() => { petDragRef.current = false; }}
          >
            <span className={styles.petShadow} aria-hidden="true" />
            <span className={styles.petArt}>
              <img src={petImageSrc(petSpecies)} alt={petName} draggable={false} />
              <PetAccessoryLayer items={petAccessories} species={petSpecies} variant="room" offsets={petOffsets} />
            </span>
            <span className={styles.petTag}>{petName}</span>
          </div>
        </div>
        <p className={styles.canvasHint}>
          {room.name} · 已摆放 {roomPlaced.length} / {room.items.length} 件 · 从右侧拖进房间，拖动可再调整，右上角 × 收回
        </p>
      </div>

      <div className={styles.sidebar}>
        <div className={styles.sideHead}>
          <div><span>FURNITURE</span><h3>{room.name}</h3></div>
          <small>亲密度 {intimacy} · 已解锁 {unlockedCount}/{room.items.length}</small>
        </div>
        {onGrantIntimacy && (
          <button className={styles.grantBtn} type="button" onClick={() => onGrantIntimacy(1000)}>
            测试：+1000 亲密度（一键解锁全部家具）
          </button>
        )}
        <div className={styles.itemList}>
          {room.items.map((item) => {
            const locked = intimacy < item.intimacy;
            const isPlaced = placedKeys.has(item.key);
            return (
              <button
                key={item.key}
                className={`${styles.itemCard} ${locked ? styles.itemLocked : ''} ${isPlaced ? styles.itemPlaced : ''}`}
                type="button"
                onPointerDown={(event) => startDrag(item.key, event, false)}
              >
                <span className={styles.itemThumb}>
                  <img src={item.icon} alt="" draggable={false} />
                  {locked && <b className={styles.lock}>🔒</b>}
                </span>
                <span className={styles.itemMeta}>
                  <strong>{item.name}</strong>
                  <small>{locked ? `亲密度 ${item.intimacy} 解锁` : isPlaced ? '已摆放 · 点击看 3D' : '可摆放 · 点击看 3D'}</small>
                </span>
                <i>{locked ? '—' : isPlaced ? '✓' : '＋'}</i>
              </button>
            );
          })}
        </div>
      </div>

      {drag && drag.moved && !drag.fromCanvas && (
        <img
          className={styles.dragGhost}
          src={decorItemByKey(decorRoomById(drag.roomId), drag.key)?.icon}
          alt=""
          style={{ left: drag.pointerX, top: drag.pointerY, width: 96 }}
        />
      )}

      {toast && <div className={styles.toast} role="status">{toast}</div>}

      {preview && previewItem && (
        <div className={styles.modal} role="dialog" aria-label={`${previewItem.name} 3D 预览`}>
          <div className={styles.modalCard}>
            <header>
              <div><span>3D PREVIEW</span><h4>{previewItem.name}</h4></div>
              <button type="button" onClick={() => setPreview(null)} aria-label="关闭预览">×</button>
            </header>
            <div className={styles.stage}>
              <Suspense fallback={<span className={styles.stageLoading}>正在加载 3D 模型…</span>}>
                <ModelViewer src={previewItem.model} />
              </Suspense>
            </div>
            <footer>
              <small>拖动旋转 · 滚轮缩放</small>
              {previewPlaced
                ? <button type="button" className={styles.recall} onClick={() => { removeItem(preview.roomId, preview.key); setPreview(null); }}>收回侧边栏</button>
                : <button type="button" className={styles.recall} onClick={() => setPreview(null)}>关闭</button>}
            </footer>
          </div>
        </div>
      )}
    </div>
  );
}
