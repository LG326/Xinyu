import { useMemo, useRef, useState } from 'react';
import type { MouseEvent, ReactNode } from 'react';
import type { Destination } from '../pets';
import { continentName, createRandom } from '../pets';
import styles from './WorldMap.module.css';

type Point = [number, number];
type Box = [number, number, number, number];

interface Landmass {
  name: string;
  label: Point;
  points: Point[];
  /** 卫星模式里这片陆地铺多少颗城市灯 */
  lights: number;
}

/**
 * 简化的大陆轮廓。坐标直接用等距圆柱投影的换算值：
 * x = 经度 + 180，y = 90 - 纬度，所以和 `pets.ts` 里目的地的经纬度天然对齐。
 * 地图的 viewBox 是 360 × 180，正好一单位等于一度。
 */
const LANDMASSES: Landmass[] = [
  {
    name: '北美洲',
    label: [72, 44],
    lights: 90,
    points: [[12, 25], [25, 19], [55, 20], [85, 22], [120, 30], [127, 42], [99, 65], [90, 70], [101, 81], [78, 71], [65, 60], [56, 50], [55, 42], [20, 35]],
  },
  {
    name: '南美洲',
    label: [120, 110],
    lights: 55,
    points: [[105, 80], [120, 79], [145, 97], [132, 118], [118, 142], [105, 140], [107, 120], [100, 95], [100, 88]],
  },
  {
    name: '欧洲',
    label: [186, 44],
    lights: 110,
    points: [[171, 53], [176, 42], [176, 34], [190, 30], [205, 19], [212, 32], [220, 36], [203, 50], [192, 46], [188, 56], [178, 56]],
  },
  {
    name: '非洲',
    label: [196, 92],
    lights: 70,
    points: [[170, 55], [190, 53], [213, 59], [231, 79], [222, 92], [215, 115], [200, 125], [192, 118], [185, 85], [163, 76], [163, 68]],
  },
  {
    name: '亚洲',
    label: [268, 40],
    lights: 170,
    points: [[215, 50], [230, 65], [225, 77], [235, 58], [250, 68], [258, 82], [270, 68], [280, 80], [283, 89], [288, 75], [300, 60], [307, 52], [325, 46], [340, 30], [300, 16], [255, 18], [222, 34]],
  },
  {
    name: '大洋洲',
    label: [312, 126],
    lights: 34,
    points: [[294, 112], [315, 102], [326, 109], [330, 127], [295, 124]],
  },
  {
    name: '南极洲',
    label: [180, 172],
    lights: 0,
    points: [[16, 166], [70, 162], [130, 165], [200, 161], [260, 165], [320, 160], [344, 172], [344, 180], [16, 180]],
  },
  { name: '格陵兰', label: [140, 22], lights: 4, points: [[125, 20], [135, 12], [152, 16], [160, 26], [146, 32], [128, 30]] },
  { name: '日本', label: [316, 56], lights: 12, points: [[310, 52], [318, 46], [325, 48], [320, 58], [312, 60]] },
  { name: '马达加斯加', label: [228, 110], lights: 8, points: [[224, 100], [230, 104], [232, 114], [226, 118], [222, 108]] },
  { name: '新西兰', label: [349, 136], lights: 10, points: [[345, 128], [352, 126], [357, 134], [350, 142], [344, 136]] },
];

/** 用 Catmull-Rom 把折线变成圆润的海岸线。 */
function smoothClosedPath(points: Point[]): string {
  const total = points.length;
  const at = (index: number) => points[(index + total) % total];
  const fix = (value: number) => value.toFixed(1);
  let path = `M${fix(at(0)[0])} ${fix(at(0)[1])}`;
  for (let index = 0; index < total; index += 1) {
    const previous = at(index - 1);
    const current = at(index);
    const next = at(index + 1);
    const after = at(index + 2);
    const c1x = current[0] + (next[0] - previous[0]) / 6;
    const c1y = current[1] + (next[1] - previous[1]) / 6;
    const c2x = next[0] - (after[0] - current[0]) / 6;
    const c2y = next[1] - (after[1] - current[1]) / 6;
    path += ` C${fix(c1x)} ${fix(c1y)} ${fix(c2x)} ${fix(c2y)} ${fix(next[0])} ${fix(next[1])}`;
  }
  return `${path}Z`;
}

function bounds(points: Point[]): Box {
  const xs = points.map((point) => point[0]);
  const ys = points.map((point) => point[1]);
  return [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)];
}

/** 射线法判断点是否落在大陆轮廓里，卫星模式点按放大时会用到。 */
function inPolygon(px: number, py: number, points: Point[]): boolean {
  let inside = false;
  for (let index = 0, previous = points.length - 1; index < points.length; previous = index, index += 1) {
    const [xi, yi] = points[index];
    const [xj, yj] = points[previous];
    if ((yi > py) !== (yj > py) && px < ((xj - xi) * (py - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

const LAND_PATHS = LANDMASSES.map((landmass) => ({
  name: landmass.name,
  label: landmass.label,
  d: smoothClosedPath(landmass.points),
}));

/** 点按一片陆地时，镜头拉到多远 */
interface View {
  name: string;
  /** 缩放中心（地图坐标 0-360 / 0-180） */
  x: number;
  y: number;
  scale: number;
}

const WORLD_VIEW: View = { name: '世界', x: 180, y: 90, scale: 1 };

const LAND_VIEWS = LANDMASSES
  .filter((land) => land.lights > 0)
  .map((land) => {
    const [x0, y0, x1, y1] = bounds(land.points);
    const scale = clamp(Math.min(360 / (x1 - x0), 180 / (y1 - y0)) * 0.8, 1.6, 3.4);
    return { name: land.name, points: land.points, view: { name: land.name, x: (x0 + x1) / 2, y: (y0 + y1) / 2, scale } };
  });

/* ── 手绘涂鸦地图的零件 ─────────────────────────────────── */

const INK = '#4a3f38';
const SAND_DARK = '#ece0c2';
const GREEN = '#a9c99a';
const GREEN_DARK = '#7ea277';
const PINK = '#f2b4bd';
const RED = '#e0806c';
const BLUE = '#9cc4da';
const YELLOW = '#f4d78e';
const CREAM = '#fdfaf1';
const WHITE = '#ffffff';
const BROWN = '#c08a5a';

const STROKE = { stroke: INK, strokeWidth: 1, strokeLinejoin: 'round', strokeLinecap: 'round' } as const;

/** 一整套手绘小涂鸦，散落在陆地与海洋上，像绘本里的世界地图。 */
const DOODLES: Record<string, ReactNode> = {
  cloud: (
    <g>
      <path d="M-8.5 2.2 C-11.8 2.2 -12.6 -2.2 -9.6 -3.6 C-9.8 -7.6 -4.6 -9.4 -2 -6.6 C-0.6 -10.8 6 -10.6 7 -6.4 C10.8 -4.8 11 2.2 8 2.2 Z" fill={CREAM} {...STROKE} />
      <path d="M-4.4 -0.6 q1.5 1.4 3 0 M1.2 -0.6 q1.5 1.4 3 0" fill="none" stroke={INK} strokeWidth="0.9" strokeLinecap="round" />
    </g>
  ),
  star: (
    <path d="M0 -6.5 C1.2 -1.8 1.8 -1.2 6.5 0 C1.8 1.2 1.2 1.8 0 6.5 C-1.2 1.8 -1.8 1.2 -6.5 0 C-1.8 -1.2 -1.2 -1.8 0 -6.5 Z" fill={YELLOW} {...STROKE} strokeWidth="0.8" />
  ),
  fish: (
    <g {...STROKE} fill={BLUE}>
      <path d="M-6 0 Q0 -5 6 0 Q0 5 -6 0 Z" />
      <path d="M5 0 L10.4 -4 L10.4 4 Z" />
      <circle cx="-2.2" cy="-0.8" r="0.8" fill={INK} stroke="none" />
    </g>
  ),
  whale: (
    <g {...STROKE} fill={BLUE}>
      <path d="M-12 0 Q-8 -7.4 0 -7.4 Q9 -7.4 11 -1 Q12 2.4 8 3.2 L-8 3.2 Q-12 3.2 -12 0 Z" />
      <path d="M9.6 -0.6 L15 -5 Q12.6 1 15 6.4 L9.6 3 Z" />
      <path d="M-3 -7 Q-4.4 -11 -1 -12" fill="none" stroke={INK} strokeWidth="1" />
      <circle cx="5.6" cy="-2.4" r="0.9" fill={INK} stroke="none" />
      <path d="M-6 -1.2 Q-1.6 0.6 2.6 -1.2" fill="none" stroke={INK} strokeWidth="0.8" />
    </g>
  ),
  boat: (
    <g {...STROKE}>
      <path d="M-9 3 L9 3 L6 7.2 L-6 7.2 Z" fill={RED} />
      <path d="M0 -8.4 L0 3" fill="none" stroke={INK} strokeWidth="1" />
      <path d="M1 -8.4 L7.4 2 L1 2 Z" fill={CREAM} />
      <path d="M-1 -6.4 L-6.4 2 L-1 2 Z" fill={YELLOW} />
    </g>
  ),
  tree: (
    <g {...STROKE}>
      <rect x="-1" y="-1" width="2" height="7" rx="1" fill={BROWN} />
      <circle cx="0" cy="-3.4" r="5.4" fill={GREEN} />
      <circle cx="-2" cy="-4.8" r="3.2" fill={GREEN_DARK} />
    </g>
  ),
  pine: (
    <g {...STROKE}>
      <rect x="-0.9" y="3" width="1.8" height="5" rx="0.9" fill={BROWN} />
      <path d="M0 -10 L5 -2.4 L-5 -2.4 Z" fill={GREEN_DARK} />
      <path d="M0 -6 L6 3 L-6 3 Z" fill={GREEN} />
    </g>
  ),
  palm: (
    <g {...STROKE}>
      <path d="M0 7.4 Q-2.2 0 0 -5" fill="none" stroke={BROWN} strokeWidth="1.8" />
      <path d="M0 -5 Q-6 -9.4 -9.4 -6.2 Q-4.4 -5 -1 -4 Z" fill={GREEN} />
      <path d="M0 -5 Q6 -9.4 9.4 -6.2 Q4.4 -5 1 -4 Z" fill={GREEN} />
      <path d="M0 -5 Q-3 -11.4 0 -11.4 Q2.4 -9 1 -4 Z" fill={GREEN_DARK} />
    </g>
  ),
  balloon: (
    <g {...STROKE}>
      <path d="M0 -12 a8 8.4 0 0 1 8 8.4 q0 6 -8 11 q-8 -5 -8 -11 a8 8.4 0 0 1 8 -8.4 Z" fill={PINK} />
      <path d="M0 -12 V7.4 M-4.4 -10.6 q2.4 9 0 17.8 M4.4 -10.6 q-2.4 9 0 17.8" fill="none" stroke={INK} strokeWidth="0.7" />
      <rect x="-3" y="8" width="6" height="4.4" rx="1" fill={BROWN} />
    </g>
  ),
  windmill: (
    <g {...STROKE}>
      <path d="M-4 8 L4 8 L2.6 -4 L-2.6 -4 Z" fill={CREAM} />
      <path d="M-3.4 -4 L3.4 -4 L0 -7.4 Z" fill={RED} />
      <path d="M0 -5.4 L0 -12.4 M0 -5.4 L6.2 -1.8 M0 -5.4 L0 1.6 M0 -5.4 L-6.2 -1.8" fill="none" stroke={INK} strokeWidth="1.1" />
    </g>
  ),
  eiffel: (
    <g {...STROKE}>
      <path d="M-7 9 L-2.6 -3 h5.2 L7 9 h-3.6 L0 1.6 L-3.4 9 Z" fill={BROWN} />
      <path d="M-4.4 -3 h8.8 M-4.8 2.6 h9.6" fill="none" stroke={INK} strokeWidth="0.8" />
      <path d="M0 -3 V-8" fill="none" stroke={INK} strokeWidth="0.9" />
      <circle cx="0" cy="-9" r="0.9" fill={YELLOW} />
    </g>
  ),
  pagoda: (
    <g {...STROKE}>
      <rect x="-0.9" y="-9.4" width="1.8" height="3.4" fill={YELLOW} />
      <rect x="-3.8" y="-6.4" width="7.6" height="2.4" fill={CREAM} />
      <path d="M-7.4 -3.8 Q0 -8.4 7.4 -3.8 Q0 -1.6 -7.4 -3.8 Z" fill={RED} />
      <path d="M-6.4 0.6 Q0 -4 6.4 0.6 Q0 2.8 -6.4 0.6 Z" fill={RED} />
      <path d="M-5.4 5 Q0 0.4 5.4 5 Q0 7.2 -5.4 5 Z" fill={RED} />
      <rect x="-2.8" y="4.6" width="5.6" height="5" fill={CREAM} />
    </g>
  ),
  liberty: (
    <g {...STROKE}>
      <path d="M-3 9 L-3 -2 Q-3 -5.2 0 -5.2 Q3 -5.2 3 -2 L3 9 Z" fill={GREEN_DARK} />
      <circle cx="0" cy="-7.6" r="2.2" fill={GREEN_DARK} />
      <path d="M-2.4 -8.4 l-1 -2 M-0.8 -9.8 v-2 M1 -9.8 v-2 M2.6 -8.4 l1 -2" fill="none" stroke={INK} strokeWidth="0.8" />
      <path d="M2.4 -4 L6 -9.2" fill="none" stroke={INK} strokeWidth="1.2" />
      <path d="M5 -10.8 q1.8 -1.8 2.8 0 q-1.4 -0.6 -2.8 0 Z" fill={YELLOW} />
      <rect x="-3.8" y="9" width="7.6" height="2" fill={SAND_DARK} />
    </g>
  ),
  taj: (
    <g {...STROKE}>
      <rect x="-8.4" y="6" width="16.8" height="3" fill={CREAM} />
      <rect x="-5" y="-1" width="10" height="7" fill={CREAM} />
      <path d="M-5 -1 Q0 -9.4 5 -1 Z" fill={CREAM} />
      <path d="M0 -9.4 V-11.6" fill="none" stroke={INK} strokeWidth="0.8" />
      <rect x="-7.6" y="-3.4" width="1.8" height="9.4" fill={SAND_DARK} />
      <rect x="5.8" y="-3.4" width="1.8" height="9.4" fill={SAND_DARK} />
      <circle cx="-6.7" cy="-4.6" r="1.1" fill={CREAM} />
      <circle cx="6.7" cy="-4.6" r="1.1" fill={CREAM} />
      <path d="M0 6 V1.4 M-2.8 6 V2 M2.8 6 V2" fill="none" stroke={INK} strokeWidth="0.7" />
    </g>
  ),
  pyramid: (
    <g {...STROKE}>
      <path d="M-9 8 L0 -9 L9 8 Z" fill={YELLOW} />
      <path d="M0 -9 L9 8 L2.4 8 Z" fill={SAND_DARK} />
    </g>
  ),
  wall: (
    <g {...STROKE}>
      <path d="M-11 5 Q-5 -1 0 3 Q5 7 11 1 L11 6 Q5 12 0 8 Q-5 4 -11 10 Z" fill={SAND_DARK} />
      <rect x="-2.4" y="-4" width="5" height="8" fill={SAND_DARK} />
      <path d="M-3.6 -4 h7.2 l-1 -3.2 h-5.2 Z" fill={RED} />
      <path d="M-1 -0.6 h2" fill="none" stroke={INK} strokeWidth="0.7" />
    </g>
  ),
  igloo: (
    <g {...STROKE}>
      <path d="M-9 8 A9 9 0 0 1 9 8 Z" fill={WHITE} />
      <path d="M-6 3 q2 1.6 4 0 M-0.6 1 q2 1.6 4 0 M-4 6.4 q2 1.6 4 0 M2 5 q2 1.6 4 0" fill="none" stroke={INK} strokeWidth="0.6" />
      <path d="M-2.6 8 V4.8 a2.6 2.6 0 0 1 5.2 0 V8 Z" fill={SAND_DARK} />
    </g>
  ),
  penguin: (
    <g {...STROKE}>
      <ellipse cx="0" cy="1.4" rx="5" ry="7" fill={INK} />
      <ellipse cx="0" cy="2.6" rx="3.2" ry="5" fill={CREAM} />
      <circle cx="0" cy="-5.4" r="3.6" fill={INK} />
      <path d="M0 -4.6 l3.2 1.6 l-3.2 1.6 Z" fill={YELLOW} />
      <circle cx="-1.3" cy="-6.2" r="0.7" fill={CREAM} stroke="none" />
      <circle cx="1.3" cy="-6.2" r="0.7" fill={CREAM} stroke="none" />
    </g>
  ),
  elephant: (
    <g {...STROKE}>
      <ellipse cx="-1" cy="0" rx="7.6" ry="5.4" fill={BLUE} />
      <circle cx="6.4" cy="-1" r="3.8" fill={BLUE} />
      <path d="M8.4 0.4 q3 2.2 2.4 5.6 q-1.4 -1.6 -3.6 -1.6 Z" fill={BLUE} />
      <path d="M-6 4.6 v4.2 M-1 5 v4.2 M3.4 4.6 v4.2" fill="none" stroke={INK} strokeWidth="1.1" />
      <circle cx="7" cy="-1.6" r="0.8" fill={INK} stroke="none" />
    </g>
  ),
  giraffe: (
    <g {...STROKE}>
      <rect x="-5.6" y="1" width="11" height="5" rx="2.4" fill={YELLOW} />
      <path d="M3 1 V-8" stroke={YELLOW} strokeWidth="2.6" fill="none" />
      <circle cx="3.4" cy="-9.4" r="2" fill={YELLOW} />
      <path d="M-4.6 6 v3.6 M-1 6 v3.6 M2 6 v3.6" fill="none" stroke={INK} strokeWidth="1.1" />
      <path d="M2.6 -11.2 v-1.6 M4.6 -11.2 v-1.6" fill="none" stroke={INK} strokeWidth="0.8" />
      <g fill={BROWN} stroke="none">
        <circle cx="-3" cy="3" r="0.8" />
        <circle cx="0" cy="4.2" r="0.8" />
        <circle cx="2" cy="2.6" r="0.8" />
      </g>
    </g>
  ),
  panda: (
    <g {...STROKE}>
      <circle cx="-4.2" cy="-5.4" r="2.2" fill={INK} />
      <circle cx="4.2" cy="-5.4" r="2.2" fill={INK} />
      <circle cx="0" cy="0" r="6" fill={CREAM} />
      <ellipse cx="-2.4" cy="-0.6" rx="1.7" ry="2.2" fill={INK} stroke="none" transform="rotate(-18 -2.4 -0.6)" />
      <ellipse cx="2.4" cy="-0.6" rx="1.7" ry="2.2" fill={INK} stroke="none" transform="rotate(18 2.4 -0.6)" />
      <circle cx="-2.4" cy="-0.6" r="0.6" fill={CREAM} stroke="none" />
      <circle cx="2.4" cy="-0.6" r="0.6" fill={CREAM} stroke="none" />
      <ellipse cx="0" cy="2.8" rx="0.9" ry="0.7" fill={INK} stroke="none" />
      <path d="M-1.6 3.8 q1.6 1.4 3.2 0" fill="none" stroke={INK} strokeWidth="0.7" />
    </g>
  ),
  octopus: (
    <g {...STROKE}>
      <path d="M-7 2.4 a7 7 0 0 1 14 0 v1 H-7 Z" fill={PINK} />
      <path d="M-6 3.4 q-1 4.4 -3.4 5.4 q2.4 0.6 3.4 -1.2 M-2 3.4 q-0.6 4.4 0 6.4 M2 3.4 q0.6 4.4 0 6.4 M6 3.4 q1 4.4 3.4 5.4 q-2.4 0.6 -3.4 -1.2" fill="none" stroke={INK} strokeWidth="1" />
      <circle cx="-2.4" cy="-0.6" r="0.9" fill={INK} stroke="none" />
      <circle cx="2.4" cy="-0.6" r="0.9" fill={INK} stroke="none" />
    </g>
  ),
  opera: (
    <g {...STROKE}>
      <path d="M-9 6 h18 v2.2 h-18 Z" fill={SAND_DARK} />
      <path d="M-8 6 q1 -9 6 -10 q-1 5 1 10 Z" fill={CREAM} />
      <path d="M-1 6 q1 -8 5 -9 q-1 4 1 9 Z" fill={CREAM} />
      <path d="M4 6 q1 -6 4 -7 q-1 3 1 7 Z" fill={CREAM} />
    </g>
  ),
  flower: (
    <g {...STROKE}>
      {[0, 72, 144, 216, 288].map((angle) => (
        <ellipse key={angle} cx="0" cy="-4.4" rx="2.6" ry="4" fill={PINK} transform={`rotate(${angle})`} />
      ))}
      <circle cx="0" cy="0" r="1.8" fill={YELLOW} />
    </g>
  ),
};

/** [涂鸦, x, y, 缩放, 旋转]，坐标同样是地图 viewBox 单位。 */
const DOODLE_PLACEMENTS: Array<[string, number, number, number, number]> = [
  // 北美洲
  ['cloud', 28, 14, 1.05, 0],
  ['pine', 45, 33, 1, 0],
  ['pine', 56, 42, 0.82, 0],
  ['balloon', 32, 45, 0.95, 0],
  ['liberty', 101, 46, 1, 0],
  ['tree', 72, 60, 0.9, 0],
  // 南美洲
  ['palm', 112, 99, 0.95, 0],
  ['flower', 128, 113, 0.9, 0],
  ['pine', 108, 126, 0.78, 0],
  // 欧洲
  ['windmill', 180, 42, 0.9, 0],
  ['eiffel', 194, 37, 1, 0],
  ['tree', 172, 50, 0.8, 0],
  // 非洲
  ['pyramid', 212, 64, 1, 0],
  ['elephant', 181, 84, 1, 0],
  ['giraffe', 202, 76, 0.95, 0],
  ['tree', 189, 101, 0.85, 0],
  // 亚洲
  ['wall', 262, 46, 1, 0],
  ['panda', 243, 60, 1, 0],
  ['taj', 258, 63, 0.95, 0],
  ['pagoda', 288, 47, 0.95, 0],
  ['elephant', 250, 70, 0.78, 0],
  ['palm', 292, 79, 0.9, 0],
  // 大洋洲 / 日本 / 格陵兰 / 南极
  ['opera', 314, 116, 1, 0],
  ['tree', 302, 121, 0.8, 0],
  ['flower', 318, 57, 0.7, 0],
  ['pine', 140, 24, 0.85, 0],
  ['igloo', 210, 170, 1, 0],
  ['penguin', 150, 170, 0.95, 0],
  ['penguin', 176, 174, 0.78, 0],
  // 海洋
  ['cloud', 112, 11, 0.9, 0],
  ['cloud', 250, 13, 0.95, 0],
  ['cloud', 340, 30, 0.8, 0],
  ['cloud', 148, 152, 0.85, 0],
  ['whale', 148, 108, 1.15, 0],
  ['whale', 96, 158, 0.9, 0],
  ['boat', 244, 104, 1, 0],
  ['boat', 62, 96, 0.85, 0],
  ['fish', 104, 90, 0.9, 0],
  ['fish', 300, 96, 0.8, 0],
  ['octopus', 224, 88, 0.95, 0],
  ['star', 60, 60, 0.8, 0],
  ['star', 336, 90, 0.7, 0],
  ['star', 20, 130, 0.75, 0],
  ['star', 250, 140, 0.7, 0],
  ['star', 175, 88, 0.6, 0],
  ['star', 268, 168, 0.7, 0],
];

/* ── 卫星夜景 ───────────────────────────────────────────── */

/** 没有目的地、但夜里也亮着的区域（城市群），让灯光分布更像真实的地球夜景。 */
const LIGHT_HUBS: Point[] = [
  [196, 62], [200, 66], [206, 70], [191, 44], [199, 40],
  [212, 40], [218, 36], [201, 38], [196, 42],
  [230, 52], [240, 58], [250, 52], [262, 48], [270, 55], [278, 60], [255, 62], [262, 66], [286, 56],
  [300, 50], [306, 52], [296, 54],
  [83, 40], [90, 44], [75, 38], [70, 44], [95, 48],
  [70, 52], [78, 62], [86, 68],
  [115, 100], [125, 108], [130, 116],
  [205, 90], [210, 96], [188, 80],
  [215, 108], [220, 104], [218, 96],
  [55, 60], [130, 30],
  [315, 118], [308, 122], [322, 120],
];

interface LightField {
  dim: string;
  mid: string;
  bright: string;
  glows: Array<{ x: number; y: number; r: number }>;
}

/** 把成千上万颗灯压成 3 条 path，既像真夜景又不会拖慢渲染。 */
function squarePath(points: Point[], size: number): string {
  const half = size / 2;
  return points
    .map(([x, y]) => `M${(x - half).toFixed(2)} ${(y - half).toFixed(2)}h${size}v${size}h-${size}z`)
    .join('');
}

function buildLights(destinations: Destination[]): LightField {
  const rng = createRandom(20260318);
  const gauss = () => (rng() + rng() + rng() + rng() - 2) * 0.6;
  const dim: Point[] = [];
  const mid: Point[] = [];
  const bright: Point[] = [];
  const glows: Array<{ x: number; y: number; r: number }> = [];

  const add = (x: number, y: number, weight: number) => {
    if (weight > 0.76) bright.push([x, y]);
    else if (weight > 0.4) mid.push([x, y]);
    else dim.push([x, y]);
  };

  // 陆地上稀疏的底噪，让整片大陆有一点微光
  LANDMASSES.forEach((land) => {
    const [x0, y0, x1, y1] = bounds(land.points);
    let placed = 0;
    let tries = 0;
    while (placed < land.lights && tries < land.lights * 18) {
      tries += 1;
      const x = x0 + rng() * (x1 - x0);
      const y = y0 + rng() * (y1 - y0);
      if (!inPolygon(x, y, land.points)) continue;
      placed += 1;
      add(x, y, rng() * 0.62);
    }
  });

  // 每个目的地附近形成一小片明亮的城市群
  destinations.forEach((destination) => {
    const cx = destination.x * 3.6;
    const cy = destination.y * 1.8;
    for (let index = 0; index < 16; index += 1) {
      add(cx + gauss() * 4.4, cy + gauss() * 3.4, 0.45 + rng() * 0.6);
    }
    glows.push({ x: cx, y: cy, r: 5.4 + rng() * 2.4 });
  });

  LIGHT_HUBS.forEach(([hx, hy]) => {
    for (let index = 0; index < 14; index += 1) {
      add(hx + gauss() * 5, hy + gauss() * 4, 0.35 + rng() * 0.55);
    }
    glows.push({ x: hx, y: hy, r: 5 + rng() * 2.5 });
  });

  return { dim: squarePath(dim, 0.75), mid: squarePath(mid, 1.15), bright: squarePath(bright, 1.75), glows };
}

interface MapLabel {
  name: string;
  x: number;
  y: number;
  /** 1 = 大洲 / 大洋，2 = 主要国家，3 = 近邻国家 */
  tier: 1 | 2 | 3;
}

/** 卫星模式的国家与地区标注，放大到一定程度才逐级出现。 */
const MAP_LABELS: MapLabel[] = [
  { name: '北冰洋', x: 176, y: 9, tier: 1 },
  { name: '太平洋', x: 34, y: 96, tier: 1 },
  { name: '大西洋', x: 152, y: 80, tier: 1 },
  { name: '印度洋', x: 242, y: 108, tier: 1 },
  { name: '南极洲', x: 180, y: 172, tier: 1 },
  { name: '格陵兰', x: 140, y: 22, tier: 1 },
  { name: '北美洲', x: 62, y: 52, tier: 1 },
  { name: '南美洲', x: 120, y: 112, tier: 1 },
  { name: '欧洲', x: 190, y: 26, tier: 1 },
  { name: '非洲', x: 196, y: 104, tier: 1 },
  { name: '亚洲', x: 290, y: 24, tier: 1 },
  { name: '大洋洲', x: 312, y: 134, tier: 1 },

  { name: '美国', x: 103, y: 51, tier: 2 },
  { name: '加拿大', x: 96, y: 30, tier: 2 },
  { name: '墨西哥', x: 81, y: 70.6, tier: 2 },
  { name: '巴西', x: 132, y: 106, tier: 2 },
  { name: '阿根廷', x: 121.6, y: 124.6, tier: 2 },
  { name: '英国', x: 180, y: 40, tier: 2 },
  { name: '法国', x: 182.4, y: 42.4, tier: 2 },
  { name: '德国', x: 193.4, y: 37.5, tier: 2 },
  { name: '俄罗斯', x: 224, y: 30, tier: 2 },
  { name: '土耳其', x: 212.9, y: 50.1, tier: 2 },
  { name: '沙特阿拉伯', x: 226.7, y: 65.3, tier: 2 },
  { name: '埃及', x: 211.2, y: 60, tier: 2 },
  { name: '尼日利亚', x: 187.5, y: 81, tier: 2 },
  { name: '肯尼亚', x: 216.8, y: 91.3, tier: 2 },
  { name: '南非', x: 198.4, y: 123.9, tier: 2 },
  { name: '印度', x: 257.2, y: 61.4, tier: 2 },
  { name: '中国', x: 296.4, y: 50.1, tier: 2 },
  { name: '蒙古', x: 286.9, y: 42.1, tier: 2 },
  { name: '日本', x: 319.7, y: 54.3, tier: 2 },
  { name: '印度尼西亚', x: 286.8, y: 96.2, tier: 2 },
  { name: '澳大利亚', x: 329.1, y: 125.3, tier: 2 },

  { name: '冰岛', x: 158, y: 26, tier: 3 },
  { name: '爱尔兰', x: 173.7, y: 36.7, tier: 3 },
  { name: '挪威', x: 190.8, y: 30.1, tier: 3 },
  { name: '瑞典', x: 198.1, y: 30.7, tier: 3 },
  { name: '芬兰', x: 204.9, y: 29.8, tier: 3 },
  { name: '荷兰', x: 184.9, y: 37.6, tier: 3 },
  { name: '比利时', x: 184.4, y: 39.6, tier: 3 },
  { name: '波兰', x: 201, y: 37.8, tier: 3 },
  { name: '捷克', x: 194.4, y: 39.9, tier: 3 },
  { name: '奥地利', x: 196.4, y: 41.8, tier: 3 },
  { name: '瑞士', x: 188.2, y: 43.6, tier: 3 },
  { name: '意大利', x: 192.5, y: 48.1, tier: 3 },
  { name: '西班牙', x: 176.3, y: 49.6, tier: 3 },
  { name: '希腊', x: 203.7, y: 52, tier: 3 },
  { name: '乌克兰', x: 207.5, y: 40.5, tier: 3 },
  { name: '伊朗', x: 231.4, y: 54.3, tier: 3 },
  { name: '巴基斯坦', x: 253.1, y: 56.3, tier: 3 },
  { name: '韩国', x: 307, y: 52.4, tier: 3 },
  { name: '越南', x: 285.8, y: 69, tier: 3 },
  { name: '泰国', x: 280.5, y: 76.3, tier: 3 },
  { name: '柬埔寨', x: 284.9, y: 78.4, tier: 3 },
  { name: '秘鲁', x: 103, y: 102, tier: 3 },
  { name: '哥伦比亚', x: 105.9, y: 85.3, tier: 3 },
  { name: '玻利维亚', x: 115, y: 110, tier: 3 },
  { name: '智利', x: 109.3, y: 123.4, tier: 3 },
  { name: '古巴', x: 97.6, y: 66.9, tier: 3 },
  { name: '摩洛哥', x: 173.2, y: 56, tier: 3 },
  { name: '阿尔及利亚', x: 183, y: 53.6, tier: 3 },
  { name: '埃塞俄比亚', x: 218.7, y: 81, tier: 3 },
  { name: '马达加斯加', x: 227.5, y: 108.9, tier: 3 },
  { name: '新西兰', x: 351, y: 133, tier: 3 },
];

const LABEL_TIER_SCALE: Record<1 | 2 | 3, number> = { 1: 1, 2: 1.75, 3: 2.5 };

/* ── 目的地聚合 ─────────────────────────────────────────── */

interface Marker {
  key: string;
  x: number;
  y: number;
  items: Destination[];
}

/**
 * 目的地变多以后，同一个大洲上的点会挤在一起。
 * 按当前缩放把靠得近的地点合成一个聚合点，点开聚合点就自动拉近。
 */
function buildMarkers(destinations: Destination[], scale: number): Marker[] {
  const threshold = 11 / scale;
  const markers: Marker[] = [];
  destinations.forEach((destination) => {
    const x = destination.x * 3.6;
    const y = destination.y * 1.8;
    const near = markers.find((marker) => Math.hypot(marker.x - x, marker.y - y) < threshold);
    if (!near) {
      markers.push({ key: destination.id, x, y, items: [destination] });
      return;
    }
    near.items.push(destination);
    near.x = near.items.reduce((sum, item) => sum + item.x * 3.6, 0) / near.items.length;
    near.y = near.items.reduce((sum, item) => sum + item.y * 1.8, 0) / near.items.length;
  });
  return markers;
}

/* ── 组件 ───────────────────────────────────────────────── */

type MapMode = 'doodle' | 'satellite';

interface WorldMapProps {
  destinations: Destination[];
  /** 当前选中的目的地 */
  selectedId: string | null;
  /** 正在旅行中的目的地（有旅伴在路上） */
  travelingIds: string[];
  /** 已经收到过明信片的目的地 */
  visitedIds: string[];
  onPick: (destination: Destination) => void;
}

export function WorldMap({ destinations, selectedId, travelingIds, visitedIds, onPick }: WorldMapProps) {
  const [mode, setMode] = useState<MapMode>('doodle');
  const [stack, setStack] = useState<View[]>([]);
  const frameRef = useRef<HTMLDivElement | null>(null);
  const view = stack.length ? stack[stack.length - 1] : WORLD_VIEW;

  const lights = useMemo(() => buildLights(destinations), [destinations]);
  const markers = useMemo(() => buildMarkers(destinations, view.scale), [destinations, view.scale]);
  const waves = useMemo(() => {
    const rng = createRandom(19700101);
    const list: Array<{ x: number; y: number; s: number; r: number }> = [];
    let guard = 0;
    while (list.length < 30 && guard < 900) {
      guard += 1;
      const x = rng() * 360;
      const y = rng() * 180;
      if (LANDMASSES.some((land) => (land.lights > 0 ? inPolygon(x, y, land.points) : false))) continue;
      list.push({ x, y, s: 0.6 + rng() * 0.8, r: (rng() - 0.5) * 18 });
    }
    return list;
  }, []);

  const push = (next: View) => setStack((previous) => [...previous, next].slice(-3));
  const back = () => setStack((previous) => previous.slice(0, -1));
  const zoomBy = (factor: number) => setStack((previous) => {
    const current = previous.length ? previous[previous.length - 1] : WORLD_VIEW;
    const scale = clamp(current.scale * factor, 1, 3.4);
    return [...previous.slice(0, -1), { ...current, scale }];
  });

  const switchMode = (next: MapMode) => {
    setMode(next);
    setStack([]);
  };

  /** 卫星模式下点陆地：按经纬度反推落点，落在哪片陆地就拉到哪片。 */
  const handleMapClick = (event: MouseEvent<SVGSVGElement>) => {
    if (mode !== 'satellite' || !frameRef.current) return;
    const rect = frameRef.current.getBoundingClientRect();
    const px = ((event.clientX - rect.left) / rect.width) * 360;
    const py = ((event.clientY - rect.top) / rect.height) * 180;
    const mx = view.x + (px - view.x) / view.scale;
    const my = view.y + (py - view.y) / view.scale;
    const hit = LAND_VIEWS.find((entry) => inPolygon(mx, my, entry.points));
    if (hit) {
      if (view.name === hit.name) return;
      push(hit.view);
    } else {
      setStack([]);
    }
  };

  const zoomed = view.scale > 1.02;

  return (
    <div className={styles.map} data-mode={mode} ref={frameRef}>
      <div
        className={styles.stage}
        style={{ transform: `scale(${view.scale})`, transformOrigin: `${(view.x / 360) * 100}% ${(view.y / 180) * 100}%` }}
      >
        <svg viewBox="0 0 360 180" className={styles.canvas} role="img" aria-label="全球旅行地图" onClick={handleMapClick}>
          <defs>
            <linearGradient id="xinyu-map-ocean" x1="0" y1="0" x2="0.6" y2="1">
              <stop offset="0%" stopColor="var(--ocean-a)" />
              <stop offset="100%" stopColor="var(--ocean-b)" />
            </linearGradient>
            <radialGradient id="xinyu-map-glow">
              <stop offset="0%" stopColor="#ffe0a8" stopOpacity=".9" />
              <stop offset="55%" stopColor="#ffb764" stopOpacity=".28" />
              <stop offset="100%" stopColor="#ff9a4d" stopOpacity="0" />
            </radialGradient>
          </defs>

          <rect width="360" height="180" className={styles.ocean} fill="url(#xinyu-map-ocean)" />

          {/* 手绘模式：海面上零星的波浪 */}
          <g className={styles.waves}>
            {waves.map((wave, index) => (
              <path
                key={index}
                d="M-5 0 q2.5 -2.4 5 0 q2.5 2.4 5 0"
                transform={`translate(${wave.x} ${wave.y}) rotate(${wave.r}) scale(${wave.s})`}
              />
            ))}
          </g>

          {/* 卫星模式：城市灯光的辉光 */}
          <g className={styles.glowLayer}>
            {lights.glows.map((glow, index) => (
              <circle key={index} cx={glow.x} cy={glow.y} r={glow.r} fill="url(#xinyu-map-glow)" />
            ))}
          </g>

          {/* 陆地：先垫一层错位的浅色，像手绘时描歪的第二笔 */}
          <g className={styles.landBack}>
            {LAND_PATHS.map((landmass) => <path key={landmass.name} d={landmass.d} />)}
          </g>
          <g className={styles.land}>
            {LAND_PATHS.map((landmass) => <path key={landmass.name} d={landmass.d} />)}
          </g>

          {/* 卫星模式：大陆上的城市灯 */}
          <g className={styles.lights}>
            <path d={lights.dim} />
            <path d={lights.mid} />
            <path d={lights.bright} />
          </g>

          {/* 手绘模式：绘本风的大陆名字 + 满地图的小涂鸦 */}
          <g className={styles.doodleLayer}>
            {LAND_PATHS.map((landmass) => (
              <text key={landmass.name} x={landmass.label[0]} y={landmass.label[1]} className={styles.doodleLabel}>{landmass.name}</text>
            ))}
            {DOODLE_PLACEMENTS.map(([kind, x, y, s, r], index) => (
              <g key={`${kind}-${index}`} transform={`translate(${x} ${y}) rotate(${r}) scale(${s})`}>{DOODLES[kind]}</g>
            ))}
          </g>

          {/* 卫星模式：国家与地区标注，点一下就拉近 */}
          <g className={styles.labels}>
            {MAP_LABELS.map((label) => {
              const visible = view.scale >= LABEL_TIER_SCALE[label.tier];
              if (!visible) return null;
              const clickable = label.tier > 1;
              return (
                <text
                  key={label.name}
                  x={label.x}
                  y={label.y}
                  className={`${styles.label} ${styles[`tier${label.tier}`]} ${clickable ? styles.labelClickable : ''}`}
                  onClick={clickable
                    ? (event) => {
                      event.stopPropagation();
                      push({ name: label.name, x: label.x, y: label.y, scale: clamp(view.scale * 1.45, 1.75, 3.4) });
                    }
                    : undefined}
                >
                  {label.name}
                </text>
              );
            })}
          </g>
        </svg>

        <div className={styles.pins}>
          {markers.map((marker) => {
            if (marker.items.length === 1) {
              const destination = marker.items[0];
              const traveling = travelingIds.includes(destination.id);
              const visited = visitedIds.includes(destination.id);
              const selected = selectedId === destination.id;
              return (
                <button
                  key={marker.key}
                  type="button"
                  className={`${styles.pin} ${selected ? styles.pinSelected : ''} ${traveling ? styles.pinTraveling : ''}`}
                  style={{ left: `${(marker.x / 360) * 100}%`, top: `${(marker.y / 180) * 100}%` }}
                  onClick={() => onPick(destination)}
                  title={`${destination.name} · ${destination.region} · 约 ${destination.minutes} 分钟${destination.niche ? ' · 小众' : ''}`}
                  aria-label={`选择一个旅伴去${destination.name}旅行`}
                >
                  <i />
                  <b>{destination.name}{destination.niche && <span className={styles.nicheTag}>小众</span>}</b>
                  {visited && <em aria-hidden="true">✉</em>}
                </button>
              );
            }
            const names = marker.items.map((item) => item.name);
            return (
              <button
                key={`cluster-${marker.key}`}
                type="button"
                className={styles.cluster}
                style={{ left: `${(marker.x / 360) * 100}%`, top: `${(marker.y / 180) * 100}%` }}
                onClick={() => push({ name: continentName(marker.items[0].continent), x: marker.x, y: marker.y, scale: clamp(view.scale * 2, 1.7, 3.4) })}
                title={`${names.join(' · ')}（点开拉近查看）`}
                aria-label={names.join('、')}
              >
                <i>{names.length}</i>
              </button>
            );
          })}
        </div>
      </div>

      <div className={styles.modes} role="group" aria-label="地图模式">
        <button type="button" className={`${styles.modeButton} ${mode === 'doodle' ? styles.modeButtonOn : ''}`} onClick={() => switchMode('doodle')}>手绘</button>
        <button type="button" className={`${styles.modeButton} ${mode === 'satellite' ? styles.modeButtonOn : ''}`} onClick={() => switchMode('satellite')}>卫星</button>
      </div>

      {(mode === 'satellite' || zoomed) && (
        <div className={styles.controls}>
          <button type="button" className={styles.controlButton} onClick={() => zoomBy(1.45)} aria-label="放大" title="放大">＋</button>
          <button type="button" className={styles.controlButton} onClick={() => zoomBy(1 / 1.45)} aria-label="缩小" title="缩小">－</button>
          <button type="button" className={styles.controlButton} onClick={() => setStack([])} aria-label="回到世界" title="回到世界">⤢</button>
        </div>
      )}

      {zoomed && (
        <button type="button" className={styles.viewBadge} onClick={stack.length > 1 ? back : () => setStack([])}>
          <span aria-hidden="true">‹</span>{view.name}
        </button>
      )}

      {!zoomed && (
        <span className={styles.hint}>
          {mode === 'satellite' ? '点陆地放大看这个国家 · 再点国家名继续拉近' : '点一个地点，再选一位旅伴出发'}
        </span>
      )}
    </div>
  );
}
