import type { CSSProperties } from 'react';
import type { ChatMessage } from '../types';
import type { PetSpeciesId } from '../pets';
import { petImageSrc } from './PetSprite';
import styles from './Bubble.module.css';

interface BubbleProps {
  message: ChatMessage;
  alias: string;
  companionSpecies?: PetSpeciesId;
  bondValue: number;
  bondRaised?: boolean;
  isLatest?: boolean;
  isTyping?: boolean;
}

function IslandAvatar({ emotion, species, compact = false }: { emotion: string; species?: PetSpeciesId; compact?: boolean }) {
  return (
    <div className={`${styles.avatar} ${compact ? styles.avatarCompact : ''}`} data-emotion={emotion} style={{ '--emotion-glow': `var(--emotion-${emotion})` } as CSSProperties} aria-hidden="true">
      {species ? <img className={styles.avatarPetImage} src={petImageSrc(species)} alt="" /> : <>
        <span className={styles.avatarGlow} />
        <span className={styles.avatarMoon}>☾</span>
        <span className={styles.avatarIsland} />
      </>}
    </div>
  );
}

export function Bubble({ message, alias, companionSpecies, bondValue, bondRaised = false, isLatest = false, isTyping = false }: BubbleProps) {
  const isUser = message.position === 'right';
  const emotion = message.emotion ?? '平静';
  const glowStyle = !isUser ? { '--emotion-glow': `var(--emotion-${emotion})` } as CSSProperties : undefined;
  const roleLabel = isUser ? '你' : alias;

  return (
    <div className={`${styles.row} ${isUser ? styles.user : styles.assistant}`}>
      {!isUser && <IslandAvatar emotion={emotion} species={companionSpecies} />}
      <div className={styles.messageGroup}>
        <span className={styles.role}>{roleLabel}</span>
        <div className={`${styles.bubble} ${bondRaised && isLatest ? styles.bondPulse : ''}`} style={glowStyle} data-emotion={emotion}>
          {message.content.text}
          {isTyping && <span className={styles.typingCursor} aria-label="正在输入" />}
        </div>
      </div>
      {!isUser && (
        <div className={styles.bondRing} style={{ '--bond-percent': bondValue } as CSSProperties} aria-label={`羁绊值 ${bondValue}/100`}>
          <span>{Math.round(bondValue)}</span>
        </div>
      )}
    </div>
  );
}
