import { useEffect, useState } from 'react';
import styles from './AgentStatus.module.css';

const STATES = ['在等你说话', '正在看云', '刚泡了一杯茶', '短暂发呆', '有点困了'];
export function AgentStatus({ memoryCount, bondValue, emotion }: { memoryCount: number; bondValue: number; emotion: string }) {
  const [expanded, setExpanded] = useState(false);
  const [status, setStatus] = useState(STATES[new Date().getHours() % STATES.length]);
  useEffect(() => { const id = window.setInterval(() => setStatus(STATES[Math.floor(Math.random() * STATES.length)]), 18000); return () => window.clearInterval(id); }, []);
  return <section className={`${styles.card} ${expanded ? styles.expanded : ''}`}>
    <button className={styles.title} type="button" onClick={() => setExpanded((value) => !value)}><span>✦ 智能体状态</span><span>{expanded ? '收起' : '展开'}⌄</span></button>
    <div className={styles.status}><i />在线·健康陪伴<span className={styles.statusText}>/ {status}</span></div>
    {expanded && <div className={styles.details}><span>情绪 <b>{emotion}</b></span><span>记忆 <b>{memoryCount} 条</b></span><span>羁绊 <b>{Math.round(bondValue)}/100</b></span><div className={styles.bondBar} aria-label={`羁绊值 ${Math.round(bondValue)}/100`}><i style={{ width: `${Math.min(100, Math.max(0, bondValue))}%` }} /></div><small>小屿会在合适时主动回应，但不会打扰或替代现实关系。</small></div>}
  </section>;
}
