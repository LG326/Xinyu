export interface AuthAccount {
  id: string;
  username: string;
  display_name: string;
}

export interface AuthSession {
  token: string;
  account: AuthAccount;
}

const SESSION_KEY = 'xinyu-auth-session';

export function readAuthSession(): AuthSession | null {
  try {
    const raw = window.localStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    const session = JSON.parse(raw) as AuthSession;
    return session?.token && session.account?.id ? session : null;
  } catch {
    return null;
  }
}

export function saveAuthSession(session: AuthSession): void {
  window.localStorage.setItem(SESSION_KEY, JSON.stringify(session));
}

export function clearAuthSession(): void {
  window.localStorage.removeItem(SESSION_KEY);
}

export function apiFetch(input: RequestInfo | URL, init: RequestInit = {}): Promise<Response> {
  const session = readAuthSession();
  const headers = new Headers(init.headers);
  if (session?.token) headers.set('Authorization', `Bearer ${session.token}`);
  return fetch(input, { ...init, headers });
}
