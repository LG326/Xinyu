import { useEffect, useState } from 'react';
import { ChatPage } from './pages/ChatPage';
import { apiFetch, clearAuthSession, readAuthSession, saveAuthSession, type AuthSession } from './auth';
import { LoginPage, type LoginSuccessPayload } from './pages/LoginPage';

export default function App() {
  const [session, setSession] = useState<AuthSession | null>(() => readAuthSession());
  const [checkingSession, setCheckingSession] = useState(() => Boolean(readAuthSession()));

  useEffect(() => {
    const existing = readAuthSession();
    if (!existing) return;
    apiFetch('/api/auth/me')
      .then((response) => response.ok ? response.json() : Promise.reject(new Error('session expired')))
      .then((data) => {
        const next = { token: existing.token, account: data.account } as AuthSession;
        saveAuthSession(next);
        setSession(next);
      })
      .catch(() => { clearAuthSession(); setSession(null); })
      .finally(() => setCheckingSession(false));
  }, []);

  const handleLoginSuccess = (_payload: LoginSuccessPayload) => {
    saveAuthSession(_payload.session);
    setSession(_payload.session);
  };

  const handleLogout = async () => {
    await apiFetch('/api/auth/logout', { method: 'POST' }).catch(() => undefined);
    clearAuthSession();
    setSession(null);
  };

  if (checkingSession) return <div className="auth-loading" aria-label="正在检查登录状态" />;
  return session ? <ChatPage account={session.account} onLogout={handleLogout} /> : <LoginPage onLoginSuccess={handleLoginSuccess} />;
}
