export type ThemeName = 'morning';
export type Emotion = '开心' | '难过' | '生气' | '焦虑' | '平静';

export interface ChatMessage {
  _id: string;
  type: 'text';
  content: { text: string };
  position: 'left' | 'right';
  emotion?: Emotion;
  createdAt?: number;
}
