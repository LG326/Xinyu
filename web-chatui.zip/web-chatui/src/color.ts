/** 颜色混合工具，供宠物形象和明信片调色共用。 */

function parse(color: string): [number, number, number] {
  // 支持 #rgb / #rrggbb，也支持本函数产出的 rgb(r, g, b)，便于连续调色。
  const matched = color.match(/rgba?\(([^)]+)\)/i);
  if (matched) {
    const parts = matched[1].split(',').map((value) => parseFloat(value));
    return [parts[0] || 0, parts[1] || 0, parts[2] || 0];
  }
  const value = color.replace('#', '');
  const full = value.length === 3 ? value.split('').map((char) => char + char).join('') : value;
  return [parseInt(full.slice(0, 2), 16), parseInt(full.slice(2, 4), 16), parseInt(full.slice(4, 6), 16)];
}

export function mixColor(from: string, to: string, ratio: number): string {
  const [r1, g1, b1] = parse(from);
  const [r2, g2, b2] = parse(to);
  const blend = (a: number, b: number) => Math.round(a + (b - a) * ratio);
  return `rgb(${blend(r1, r2)}, ${blend(g1, g2)}, ${blend(b1, b2)})`;
}
