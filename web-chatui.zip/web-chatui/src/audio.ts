/**
 * 心屿 · 轻缓背景音乐、晚安电台与交互音效。
 *
 * 所有声音都由 Web Audio API 实时合成，不依赖任何外部音频文件：
 * - 音景对应「晨雾岛屿」，作为轻缓的陪伴底噪；
 * - 「晚安电台」提供若干首纯音乐，播放时主题音景自动让位，停播后恢复；
 * - 音色保持轻、缓、低音量，作为陪伴底噪而不是主角；
 * - 浏览器不允许无交互自动播放，因此音频上下文在首次用户手势时才创建，
 *   之后按用户偏好自动续播。
 */

import type { ThemeName } from './types';

export type SfxKind = 'click' | 'toggle' | 'send' | 'pet';

export interface AudioState {
  musicEnabled: boolean;
  sfxEnabled: boolean;
  playing: boolean;
  volume: number;
  /** 正在播放的电台曲目，未播放时为 null */
  radioTrackId: string | null;
}

export interface Soundscape {
  /** 和弦进行，每一项是一组频率（Hz），使用开放五度让听感更松弛 */
  chords: number[][];
  /** 每个和弦持续秒数 */
  chordSeconds: number;
  /** 旋律音阶（Hz），从中随机取音 */
  scale: number[];
  /** 旋律平均间隔秒数，实际会在 0.65～1.7 倍之间浮动 */
  noteSeconds: number;
  /** 铺底音色 */
  wave: OscillatorType;
  /** 铺底低通截止频率 */
  filter: number;
  /** 底噪类型与滤波 */
  noise: 'brown' | 'white';
  noiseFilter: { type: BiquadFilterType; frequency: number; q: number };
  /** 底噪强度 */
  ambience: number;
  /** 底噪起伏速度（Hz），模拟潮汐或数据流 */
  ambienceLfo: number;
  /** 铺底音量系数 */
  level: number;
  /** 旋律音量系数 */
  noteLevel: number;
  /** 旋律织体：随机旋律、和弦琶音、八音盒式单音 */
  pattern?: 'melody' | 'arpeggio' | 'chime';
}

export interface RadioTrack {
  id: string;
  name: string;
  mood: string;
  config: Soundscape;
}

const SOUNDSCAPES: Record<ThemeName, Soundscape> = {
  // 晨雾岛屿：温暖开放的五度和弦 + 稀疏的木质风铃，底噪是缓慢起伏的潮汐。
  morning: {
    chords: [
      [130.81, 196.0, 261.63, 392.0],
      [110.0, 164.81, 220.0, 329.63],
      [87.31, 174.61, 261.63, 349.23],
      [98.0, 196.0, 293.66, 392.0],
    ],
    chordSeconds: 9,
    scale: [523.25, 587.33, 659.25, 783.99, 880.0],
    noteSeconds: 2.7,
    wave: 'triangle',
    filter: 1500,
    noise: 'brown',
    noiseFilter: { type: 'lowpass', frequency: 520, q: 0.4 },
    ambience: 0.5,
    ambienceLfo: 0.07,
    level: 1,
    noteLevel: 0.55,
  },
};

/**
 * 晚安电台：几首纯音乐，都是实时合成的器乐小品，
 * 每首用不同的和弦、织体与底噪区分气质，播放时会把主题音景淡出。
 */
export const RADIO_TRACKS: RadioTrack[] = [
  {
    id: 'tide',
    name: '潮汐小夜曲',
    mood: '退潮后的沙滩，只有水声和一点点钢琴',
    config: {
      chords: [[110.0, 164.81, 220.0, 261.63], [87.31, 174.61, 261.63, 349.23], [130.81, 196.0, 261.63, 392.0], [98.0, 196.0, 293.66, 392.0]],
      chordSeconds: 8,
      scale: [220.0, 261.63, 293.66, 329.63, 392.0],
      noteSeconds: 0.78,
      wave: 'triangle',
      filter: 1650,
      noise: 'brown',
      noiseFilter: { type: 'lowpass', frequency: 500, q: 0.4 },
      ambience: 0.56,
      ambienceLfo: 0.06,
      level: 1,
      noteLevel: 0.5,
      pattern: 'arpeggio',
    },
  },
  {
    id: 'stardust',
    name: '星屑摇篮曲',
    mood: '八音盒一样的星星，一颗一颗落在枕边',
    config: {
      chords: [[130.81, 196.0, 261.63], [110.0, 164.81, 220.0], [87.31, 174.61, 261.63], [98.0, 146.83, 196.0]],
      chordSeconds: 10,
      scale: [1046.5, 1174.66, 1318.51, 1567.98, 2093.0],
      noteSeconds: 1.6,
      wave: 'sine',
      filter: 1150,
      noise: 'white',
      noiseFilter: { type: 'highpass', frequency: 4200, q: 0.3 },
      ambience: 0.18,
      ambienceLfo: 0.1,
      level: 0.95,
      noteLevel: 0.34,
      pattern: 'chime',
    },
  },
  {
    id: 'rainstudy',
    name: '雨夜书桌',
    mood: '窗外的雨、台灯和写到一半的日记',
    config: {
      chords: [[73.42, 146.83, 220.0], [58.27, 116.54, 174.61], [87.31, 174.61, 261.63], [55.0, 110.0, 164.81]],
      chordSeconds: 12,
      scale: [293.66, 349.23, 440.0, 523.25, 587.33],
      noteSeconds: 0.92,
      wave: 'sine',
      filter: 820,
      noise: 'white',
      noiseFilter: { type: 'lowpass', frequency: 1750, q: 0.5 },
      ambience: 0.72,
      ambienceLfo: 0.05,
      level: 0.95,
      noteLevel: 0.42,
      pattern: 'arpeggio',
    },
  },
  {
    id: 'fireflies',
    name: '萤火虫草地',
    mood: '夏夜的草地，虫鸣一闪一闪',
    config: {
      chords: [[82.41, 164.81, 246.94], [130.81, 196.0, 261.63], [98.0, 146.83, 196.0], [73.42, 146.83, 220.0]],
      chordSeconds: 9,
      scale: [659.25, 783.99, 880.0, 987.77, 1174.66],
      noteSeconds: 1.05,
      wave: 'triangle',
      filter: 1850,
      noise: 'white',
      noiseFilter: { type: 'highpass', frequency: 5200, q: 0.3 },
      ambience: 0.14,
      ambienceLfo: 0.2,
      level: 0.95,
      noteLevel: 0.3,
      pattern: 'chime',
    },
  },
  {
    id: 'deepsea',
    name: '深海漂移',
    mood: '什么都不必想，跟着水流慢慢下沉',
    config: {
      chords: [[55.0, 82.41, 110.0], [49.0, 73.42, 98.0], [61.74, 92.5, 123.47]],
      chordSeconds: 14,
      scale: [220.0, 246.94, 293.66, 329.63],
      noteSeconds: 5.6,
      wave: 'sine',
      filter: 520,
      noise: 'brown',
      noiseFilter: { type: 'lowpass', frequency: 320, q: 0.4 },
      ambience: 0.46,
      ambienceLfo: 0.04,
      level: 0.95,
      noteLevel: 0.3,
      pattern: 'melody',
    },
  },
  {
    id: 'islandbell',
    name: '岛屿风铃',
    mood: '海风穿过屋檐，风铃一声一声',
    config: {
      chords: [[98.0, 146.83, 196.0, 293.66], [110.0, 164.81, 220.0, 329.63], [87.31, 174.61, 261.63], [130.81, 196.0, 261.63]],
      chordSeconds: 10,
      scale: [1318.51, 1567.98, 1760.0, 2093.0, 2349.32],
      noteSeconds: 1.35,
      wave: 'triangle',
      filter: 2200,
      noise: 'brown',
      noiseFilter: { type: 'lowpass', frequency: 620, q: 0.4 },
      ambience: 0.5,
      ambienceLfo: 0.08,
      level: 0.95,
      noteLevel: 0.26,
      pattern: 'chime',
    },
  },
];

const RADIO_BY_ID = new Map(RADIO_TRACKS.map((track) => [track.id, track]));

export function radioTrackIndex(id: string | null): number {
  if (!id) return -1;
  return RADIO_TRACKS.findIndex((track) => track.id === id);
}

function configFor(layerId: string): Soundscape {
  const theme = SOUNDSCAPES[layerId as ThemeName];
  if (theme) return theme;
  return RADIO_BY_ID.get(layerId)?.config ?? SOUNDSCAPES.morning;
}

const MUSIC_KEY = 'xinyu-audio-music';
const SFX_KEY = 'xinyu-audio-sfx';
const VOLUME_KEY = 'xinyu-audio-volume';
const DEFAULT_VOLUME = 0.45;
const FADE_SECONDS = 1.8;
const INTERACTIVE_SELECTOR = 'button, [role="button"], a[href], input[type="submit"], .Composer-sendBtn';
/** 输入区自己发声音（发送音效），避免和通用点击音效重叠。 */
const SILENT_SELECTOR = '.Composer';

interface Layer {
  id: string;
  bus: GainNode;
  timer: number;
  nextChordAt: number;
  nextNoteAt: number;
  chordIndex: number;
  /** 当前和弦的音，供琶音织体使用 */
  chordTones: number[];
  dispose: () => void;
}

let audioCtx: AudioContext | null = null;
let musicGain: GainNode | null = null;
let sfxGain: GainNode | null = null;
let musicEnabled = readFlag(MUSIC_KEY, true);
let sfxEnabled = readFlag(SFX_KEY, true);
let volume = readVolume();
let desiredTheme: ThemeName = 'morning';
let radioTrackId: string | null = null;
let activeLayer: Layer | null = null;
let installed = false;
let lastSfxAt = 0;
const noiseBuffers = new Map<string, AudioBuffer>();
const listeners = new Set<(state: AudioState) => void>();

function readFlag(key: string, fallback: boolean): boolean {
  try {
    const raw = window.localStorage.getItem(key);
    return raw === null ? fallback : raw === '1';
  } catch {
    return fallback;
  }
}

function writeFlag(key: string, value: boolean): void {
  try {
    window.localStorage.setItem(key, value ? '1' : '0');
  } catch {
    /* localStorage 不可用时忽略，只影响下次打开的记忆 */
  }
}

function readVolume(): number {
  try {
    const raw = Number(window.localStorage.getItem(VOLUME_KEY));
    return Number.isFinite(raw) && raw > 0 && raw <= 1 ? raw : DEFAULT_VOLUME;
  } catch {
    return DEFAULT_VOLUME;
  }
}

function snapshot(): AudioState {
  return { musicEnabled, sfxEnabled, playing: activeLayer !== null, volume, radioTrackId };
}

function emit(): void {
  const state = snapshot();
  listeners.forEach((listener) => listener(state));
}

export function getAudioState(): AudioState {
  return snapshot();
}

export function subscribeAudio(listener: (state: AudioState) => void): () => void {
  listeners.add(listener);
  listener(snapshot());
  return () => {
    listeners.delete(listener);
  };
}

function musicLevel(): number {
  return volume ** 1.25 * 0.5;
}

function sfxLevel(): number {
  return volume * 0.72;
}

function ensureContext(): AudioContext | null {
  if (audioCtx) return audioCtx;
  try {
    const Ctor = window.AudioContext
      ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return null;
    const ctx = new Ctor();
    const master = ctx.createGain();
    master.gain.value = musicLevel();
    master.connect(ctx.destination);
    const effects = ctx.createGain();
    effects.gain.value = sfxLevel();
    effects.connect(ctx.destination);
    audioCtx = ctx;
    musicGain = master;
    sfxGain = effects;
  } catch {
    return null;
  }
  return audioCtx;
}

function getNoiseBuffer(ctx: AudioContext, kind: 'brown' | 'white'): AudioBuffer {
  const cached = noiseBuffers.get(kind);
  if (cached) return cached;
  const length = Math.floor(ctx.sampleRate * 4);
  const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  let last = 0;
  for (let index = 0; index < length; index += 1) {
    const white = Math.random() * 2 - 1;
    if (kind === 'brown') {
      last = (last + 0.02 * white) / 1.02;
      data[index] = last * 3.1;
    } else {
      data[index] = white * 0.6;
    }
  }
  noiseBuffers.set(kind, buffer);
  return buffer;
}

function scheduleChord(layer: Layer, sc: Soundscape, freqs: number[], at: number): void {
  const ctx = audioCtx;
  if (!ctx) return;
  const duration = sc.chordSeconds;
  const voice = ctx.createGain();
  voice.gain.setValueAtTime(0.0001, at);
  voice.gain.linearRampToValueAtTime(0.2 * sc.level, at + duration * 0.38);
  voice.gain.linearRampToValueAtTime(0.0001, at + duration * 1.12);

  const filter = ctx.createBiquadFilter();
  filter.type = 'lowpass';
  filter.Q.value = 0.7;
  filter.frequency.setValueAtTime(sc.filter * 0.55, at);
  filter.frequency.linearRampToValueAtTime(sc.filter, at + duration * 0.5);
  filter.frequency.linearRampToValueAtTime(sc.filter * 0.72, at + duration * 1.1);

  voice.connect(filter);
  filter.connect(layer.bus);

  const stopAt = at + duration * 1.16;
  layer.chordTones = freqs;
  freqs.forEach((freq, index) => {
    [-5, 5].forEach((detune) => {
      const osc = ctx.createOscillator();
      osc.type = sc.wave;
      osc.frequency.value = freq;
      osc.detune.value = detune;
      const gain = ctx.createGain();
      gain.gain.value = index === 0 ? 0.3 : 0.2;
      osc.connect(gain);
      gain.connect(voice);
      osc.start(at);
      osc.stop(stopAt);
    });
  });
}

function scheduleNote(layer: Layer, sc: Soundscape, at: number): void {
  const ctx = audioCtx;
  if (!ctx) return;
  const pattern = sc.pattern ?? 'melody';
  let freq = sc.scale[Math.floor(Math.random() * sc.scale.length)];
  if (pattern === 'arpeggio' && layer.chordTones.length) {
    // 琶音：在和弦音之间来回，听感更像钢琴分解和弦。
    const tones = layer.chordTones;
    const step = layer.chordIndex * 2 + Math.floor(Math.random() * 3);
    freq = tones[step % tones.length] * (step % 4 === 3 ? 2 : 1);
  }
  const osc = ctx.createOscillator();
  osc.type = sc.wave === 'sine' ? 'sine' : 'triangle';
  osc.frequency.value = freq;
  const gain = ctx.createGain();
  const chime = pattern === 'chime';
  const peak = sc.noteLevel * (chime ? 0.055 : 0.085);
  const release = chime ? 3.6 : 2.8;
  gain.gain.setValueAtTime(0.0001, at);
  gain.gain.linearRampToValueAtTime(peak, at + (chime ? 0.03 : 0.12));
  gain.gain.exponentialRampToValueAtTime(0.0001, at + release);
  const filter = ctx.createBiquadFilter();
  filter.type = 'lowpass';
  filter.frequency.value = Math.min(sc.filter * 2.4, 5200);
  osc.connect(gain);
  gain.connect(filter);
  filter.connect(layer.bus);
  osc.start(at);
  osc.stop(at + release + 0.1);
}

function pump(layer: Layer): void {
  const ctx = audioCtx;
  if (!ctx) return;
  const sc = configFor(layer.id);
  const horizon = ctx.currentTime + 1.4;
  while (layer.nextChordAt < horizon) {
    scheduleChord(layer, sc, sc.chords[layer.chordIndex % sc.chords.length], layer.nextChordAt);
    layer.chordIndex += 1;
    layer.nextChordAt += sc.chordSeconds;
  }
  while (layer.nextNoteAt < horizon) {
    if (Math.random() < 0.82) scheduleNote(layer, sc, layer.nextNoteAt);
    layer.nextNoteAt += sc.noteSeconds * (0.65 + Math.random() * 1.05);
  }
}

function createLayer(layerId: string): Layer | null {
  const ctx = audioCtx;
  if (!ctx || !musicGain) return null;
  const sc = configFor(layerId);
  const bus = ctx.createGain();
  bus.gain.setValueAtTime(0.0001, ctx.currentTime);
  bus.connect(musicGain);

  // 环境底噪：潮汐或星尘，用慢速 LFO 调制音量，让声音有呼吸感。
  const noise = ctx.createBufferSource();
  noise.buffer = getNoiseBuffer(ctx, sc.noise);
  noise.loop = true;
  const noiseFilter = ctx.createBiquadFilter();
  noiseFilter.type = sc.noiseFilter.type;
  noiseFilter.frequency.value = sc.noiseFilter.frequency;
  noiseFilter.Q.value = sc.noiseFilter.q;
  const noiseGain = ctx.createGain();
  noiseGain.gain.value = sc.ambience * 0.11;
  const lfo = ctx.createOscillator();
  lfo.type = 'sine';
  lfo.frequency.value = sc.ambienceLfo;
  const lfoGain = ctx.createGain();
  lfoGain.gain.value = sc.ambience * 0.055;
  lfo.connect(lfoGain);
  lfoGain.connect(noiseGain.gain);
  noise.connect(noiseFilter);
  noiseFilter.connect(noiseGain);
  noiseGain.connect(bus);
  noise.start();
  lfo.start();

  const now = ctx.currentTime;
  const layer: Layer = {
    id: layerId,
    bus,
    timer: 0,
    nextChordAt: now + 0.4,
    nextNoteAt: now + sc.noteSeconds,
    chordIndex: 0,
    chordTones: sc.chords[0] ?? [],
    dispose: () => {
      try {
        noise.stop();
        lfo.stop();
      } catch {
        /* 已停止时忽略 */
      }
    },
  };
  layer.timer = window.setInterval(() => pump(layer), 240);
  pump(layer);
  bus.gain.linearRampToValueAtTime(1, now + FADE_SECONDS);
  return layer;
}

function releaseLayer(layer: Layer): void {
  const ctx = audioCtx;
  if (!ctx) return;
  window.clearInterval(layer.timer);
  const now = ctx.currentTime;
  try {
    layer.bus.gain.cancelScheduledValues(now);
    layer.bus.gain.setValueAtTime(Math.max(layer.bus.gain.value, 0.0001), now);
    layer.bus.gain.linearRampToValueAtTime(0.0001, now + FADE_SECONDS);
  } catch {
    /* 忽略调度异常，直接进入清理 */
  }
  window.setTimeout(() => {
    layer.dispose();
    try {
      layer.bus.disconnect();
    } catch {
      /* 已断开时忽略 */
    }
  }, (FADE_SECONDS + 0.4) * 1000);
}

function switchTo(layerId: string): void {
  if (activeLayer?.id === layerId) return;
  const next = createLayer(layerId);
  const previous = activeLayer;
  activeLayer = next;
  if (previous) releaseLayer(previous);
  emit();
}

/** 当前应该播放的音层：电台优先，其次跟随主题。 */
function currentTargetId(): string {
  return radioTrackId ?? desiredTheme;
}

function silence(): void {
  if (!activeLayer) return;
  releaseLayer(activeLayer);
  activeLayer = null;
  emit();
}

async function unlock(): Promise<void> {
  const ctx = ensureContext();
  if (!ctx) return;
  if (ctx.state === 'suspended') {
    try {
      await ctx.resume();
    } catch {
      return;
    }
  }
  if (ctx.state !== 'running') return;
  if (musicEnabled) switchTo(currentTargetId());
  emit();
}

function isInteractive(target: EventTarget | null): boolean {
  return target instanceof Element && target.closest(INTERACTIVE_SELECTOR) !== null;
}

/**
 * 决定某个点击该发什么声音。
 * 元素可以用 data-sfx="toggle|send|off|click" 覆盖默认行为。
 */
function resolveSfx(target: EventTarget | null): SfxKind | null {
  if (!(target instanceof Element)) return null;
  if (target.closest(SILENT_SELECTOR)) return null;
  const marked = target.closest('[data-sfx]');
  if (marked instanceof HTMLElement) {
    const value = marked.dataset.sfx;
    if (value === 'off') return null;
    if (value === 'toggle' || value === 'send') return value;
    return 'click';
  }
  return isInteractive(target) ? 'click' : null;
}

function playBlip(at: number, from: number, to: number, release: number, level: number): void {
  const ctx = audioCtx;
  const out = sfxGain;
  if (!ctx || !out) return;
  const osc = ctx.createOscillator();
  osc.type = 'sine';
  osc.frequency.setValueAtTime(from, at);
  osc.frequency.exponentialRampToValueAtTime(to, at + release * 0.7);
  const gain = ctx.createGain();
  const peak = level * 0.16;
  gain.gain.setValueAtTime(0.0001, at);
  gain.gain.linearRampToValueAtTime(peak, at + 0.01);
  gain.gain.exponentialRampToValueAtTime(0.0001, at + release + 0.14);
  osc.connect(gain);
  gain.connect(out);
  osc.start(at);
  osc.stop(at + release + 0.18);

  // 叠一层很轻的泛音，避免点击声过于干硬。
  const harmonic = ctx.createOscillator();
  harmonic.type = 'triangle';
  harmonic.frequency.value = to * 2;
  const harmonicGain = ctx.createGain();
  harmonicGain.gain.setValueAtTime(0.0001, at);
  harmonicGain.gain.linearRampToValueAtTime(peak * 0.22, at + 0.008);
  harmonicGain.gain.exponentialRampToValueAtTime(0.0001, at + release * 0.8);
  harmonic.connect(harmonicGain);
  harmonicGain.connect(out);
  harmonic.start(at);
  harmonic.stop(at + release + 0.14);
}

export function playSfx(kind: SfxKind): void {
  if (!sfxEnabled) return;
  const ctx = audioCtx;
  if (!ctx || ctx.state !== 'running') return;
  const now = performance.now();
  if (now - lastSfxAt < 55) return;
  lastSfxAt = now;
  const at = ctx.currentTime + 0.01;
  if (kind === 'click') {
    const base = 760;
    playBlip(at, base, base * 1.05, 0.12, 0.5);
    return;
  }
  if (kind === 'send') {
    playBlip(at, 420, 640, 0.24, 0.45);
    return;
  }
  if (kind === 'pet') {
    // 逗小动物：两声轻轻上扬的「啾」，像它在回应你。
    playBlip(at, 620, 900, 0.13, 0.5);
    playBlip(at + 0.11, 900, 1240, 0.2, 0.4);
    return;
  }
  const chime = [523.25, 659.25];
  chime.forEach((freq, index) => playBlip(at + index * 0.14, freq, freq, 0.9, 0.34));
}

/** 主题音景跟随界面主题切换，切换时两个音景会交叉淡入淡出。 */
export function setThemeSoundscape(theme: ThemeName): void {
  desiredTheme = theme;
  // 电台播放中时不打断，等电台停播再回到主题音景。
  if (radioTrackId) return;
  if (audioCtx && audioCtx.state === 'running' && musicEnabled) switchTo(theme);
}

/** 播放晚安电台的某一首纯音乐，会自动把主题音景淡出。 */
export function playRadioTrack(trackId: string): void {
  const track = RADIO_BY_ID.get(trackId);
  if (!track) return;
  radioTrackId = trackId;
  if (!musicEnabled) {
    musicEnabled = true;
    writeFlag(MUSIC_KEY, true);
  }
  const ctx = audioCtx;
  if (!ctx || ctx.state !== 'running') {
    void unlock();
    emit();
    return;
  }
  switchTo(trackId);
}

/** 停止电台，回到当前主题音景。 */
export function stopRadio(): void {
  if (!radioTrackId) return;
  radioTrackId = null;
  if (audioCtx && audioCtx.state === 'running' && musicEnabled) switchTo(desiredTheme);
  else emit();
}

export function toggleRadio(trackId: string): void {
  if (radioTrackId === trackId) stopRadio();
  else playRadioTrack(trackId);
}

/** 切到上一首 / 下一首；未在播放时从第一首开始。 */
export function stepRadio(offset: number): void {
  const total = RADIO_TRACKS.length;
  const current = radioTrackIndex(radioTrackId);
  const nextIndex = current < 0 ? (offset > 0 ? 0 : total - 1) : (current + offset + total) % total;
  playRadioTrack(RADIO_TRACKS[nextIndex].id);
}

export function setMusicEnabled(enabled: boolean): void {
  musicEnabled = enabled;
  writeFlag(MUSIC_KEY, enabled);
  if (!enabled) {
    silence();
    return;
  }
  void unlock();
}

export function setSfxEnabled(enabled: boolean): void {
  sfxEnabled = enabled;
  writeFlag(SFX_KEY, enabled);
  if (enabled) void unlock();
  emit();
}

export function setVolume(next: number): void {
  volume = Math.min(1, Math.max(0.05, next));
  try {
    window.localStorage.setItem(VOLUME_KEY, String(volume));
  } catch {
    /* 忽略存储失败 */
  }
  const ctx = audioCtx;
  if (ctx) {
    musicGain?.gain.setTargetAtTime(musicLevel(), ctx.currentTime, 0.06);
    sfxGain?.gain.setTargetAtTime(sfxLevel(), ctx.currentTime, 0.06);
  }
  emit();
}

/** 由页面在挂载时调用一次：注册解锁与全局点击音效。 */
export function initAudio(): void {
  if (installed) return;
  installed = true;
  document.addEventListener('pointerdown', (event) => {
    void unlock();
    const kind = resolveSfx(event.target);
    if (kind) playSfx(kind);
  }, true);
  document.addEventListener('keydown', (event) => {
    void unlock();
    if (event.key !== 'Enter' && event.key !== ' ') return;
    const kind = resolveSfx(event.target);
    if (kind) playSfx(kind);
  }, true);
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible' && musicEnabled && audioCtx?.state === 'suspended') void unlock();
  });
  emit();
}
