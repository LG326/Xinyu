import { FormEvent, useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { apiFetch, type AuthSession } from '../auth';
import './LoginPage.css';

export interface LoginSuccessPayload {
  session: AuthSession;
}

interface LoginPageProps {
  onLoginSuccess: (payload: LoginSuccessPayload) => void;
}

type ActiveField = 'username' | 'password' | null;

const FIREFLY_SEEDS = [
  { x: .065, y: .42, radius: 2.4, phase: 0 },
  { x: .285, y: .45, radius: 2.8, phase: 1.2 },
  { x: .34, y: .58, radius: 2.2, phase: 2.7 },
  { x: .09, y: .67, radius: 2.6, phase: 3.8 },
  { x: .32, y: .76, radius: 2.1, phase: 4.6 },
  { x: .44, y: .5, radius: 2.4, phase: 5.4 },
  { x: .18, y: .78, radius: 1.9, phase: 6.2 },
];

function FireflyCanvas({ activeField, active }: { activeField: ActiveField; active: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const pointerRef = useRef({ x: -10, y: -10 });

  useEffect(() => {
    const canvas = canvasRef.current;
    const host = canvas?.parentElement;
    if (!canvas || !host) return undefined;
    const context = canvas.getContext('2d');
    if (!context) return undefined;
    let frame = 0;
    let width = 0;
    let height = 0;
    const resize = () => {
      const rect = host.getBoundingClientRect();
      const ratio = Math.min(window.devicePixelRatio || 1, 2);
      width = rect.width;
      height = rect.height;
      canvas.width = Math.round(width * ratio);
      canvas.height = Math.round(height * ratio);
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;
      context.setTransform(ratio, 0, 0, ratio, 0, 0);
    };
    const observer = new ResizeObserver(resize);
    observer.observe(host);
    resize();
    const draw = (time: number) => {
      context.clearRect(0, 0, width, height);
      const targetX = activeField ? width * .16 : pointerRef.current.x;
      const targetY = activeField ? height * .57 : pointerRef.current.y;
      FIREFLY_SEEDS.forEach((seed, index) => {
        const drift = Math.sin(time / 1450 + seed.phase) * 12;
        const driftY = Math.cos(time / 1250 + seed.phase * 1.7) * 10;
        let x = width * seed.x + drift;
        let y = height * seed.y + driftY;
        if (activeField || active) {
          const amount = activeField ? .17 : .05;
          x += (targetX - x) * amount;
          y += (targetY - y) * amount;
        }
        const pulse = .72 + Math.sin(time / 370 + seed.phase) * .28;
        const radius = seed.radius * (activeField ? 1.25 : 1);
        const glow = context.createRadialGradient(x, y, 0, x, y, radius * 7);
        glow.addColorStop(0, `rgba(255,245,177,${.88 * pulse})`);
        glow.addColorStop(1, 'rgba(255,212,113,0)');
        context.fillStyle = glow;
        context.beginPath();
        context.arc(x, y, radius * 7, 0, Math.PI * 2);
        context.fill();
        context.fillStyle = `rgba(255,247,190,${.78 + pulse * .2})`;
        context.beginPath();
        context.arc(x, y, radius, 0, Math.PI * 2);
        context.fill();
        if (index === 0 && activeField) {
          context.strokeStyle = 'rgba(124,185,168,.25)';
          context.lineWidth = 1;
          context.beginPath();
          context.arc(x, y, radius * 3, 0, Math.PI * 2);
          context.stroke();
        }
      });
      frame = window.requestAnimationFrame(draw);
    };
    frame = window.requestAnimationFrame(draw);
    return () => {
      observer.disconnect();
      window.cancelAnimationFrame(frame);
    };
  }, [activeField, active]);

  return <canvas ref={canvasRef} className="hanging-firefly-canvas" aria-hidden="true" />;
}

function HangingPlank({ children, className = '', paused }: { children: React.ReactNode; className?: string; paused: boolean }) {
  return (
    <motion.div
      className={`hanging-plank ${className}`}
      animate={{ rotate: paused ? 0 : [-1, 1, -1] }}
      transition={paused ? { duration: .2 } : { duration: 4, repeat: Infinity, ease: 'easeInOut' }}
    >
      <span className="plank-grain" aria-hidden="true" />
      <span className="plank-nail plank-nail-left" aria-hidden="true" />
      <span className="plank-nail plank-nail-right" aria-hidden="true" />
      {children}
    </motion.div>
  );
}

export function LoginPage({ onLoginSuccess }: LoginPageProps) {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [activeField, setActiveField] = useState<ActiveField>(null);
  const [pointerNear, setPointerNear] = useState(false);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [success, setSuccess] = useState(false);
  const completionTimer = useRef<number | null>(null);

  useEffect(() => () => {
    if (completionTimer.current) window.clearTimeout(completionTimer.current);
  }, []);

  const finish = (session: AuthSession) => {
    setSuccess(true);
    completionTimer.current = window.setTimeout(() => onLoginSuccess({ session }), 850);
  };

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    if (busy) return;
    setError('');
    const accountName = username.trim();
    if (!/^[A-Za-z0-9][A-Za-z0-9_-]{2,31}$/.test(accountName)) {
      setError('账号需为 3-32 位英文或数字开头，可使用下划线和短横线');
      return;
    }
    if (password.length < 8 || password.length > 128) {
      setError('密码需为 8-128 位字符');
      return;
    }
    setBusy(true);
    try {
      const endpoint = mode === 'register' ? '/api/auth/register' : '/api/auth/login';
      const response = await apiFetch(endpoint, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ username: accountName, password, display_name: displayName.trim() }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        const detail = String(data.detail || '登录服务暂不可用，请确认应用服务正在运行');
        if (mode === 'login' && response.status === 401) {
          throw new Error('账号或密码不正确。新用户请先切换到“注册账号”，注册完成后再用相同账号登录。');
        }
        throw new Error(detail);
      }
      finish(data as AuthSession);
    } catch (submissionError) {
      setBusy(false);
      setError(submissionError instanceof TypeError
        ? '无法连接登录服务，请确认使用项目提供的网页地址并检查后端是否运行。'
        : submissionError instanceof Error ? submissionError.message : '账号操作失败，请稍后再试');
    }
  };

  const guest = async () => {
    if (busy) return;
    setError('');
    setBusy(true);
    try {
      const response = await apiFetch('/api/auth/guest', { method: 'POST' });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(String(data.detail || '游客入口暂时不可用'));
      finish(data as AuthSession);
    } catch (guestError) {
      setBusy(false);
      setError(guestError instanceof Error ? guestError.message : '游客入口暂时不可用');
    }
  };

  const switchMode = (nextMode: 'login' | 'register') => {
    setMode(nextMode);
    setError('');
  };

  return (
    <main
      className={`hanging-login ${success ? 'hanging-login-success' : ''}`}
      onMouseMove={(event) => {
        const target = event.target as HTMLElement;
        setPointerNear(Boolean(target.closest('.hanging-form, .hanging-plank, .hanging-lantern-button')));
      }}
      onMouseLeave={() => setPointerNear(false)}
    >
      <img className="hanging-login-background" src="/login-island.png" alt="晨雾森林、树洞信箱、青蛙和湖边木栈桥" aria-hidden="true" />
      <div className="hanging-login-shade" aria-hidden="true" />
      <div className="hanging-scene">
        <FireflyCanvas activeField={activeField} active={pointerNear} />

        <motion.div
          className="hanging-login-title"
          initial={{ opacity: 0, y: -12 }}
          animate={{ opacity: success ? 0 : 1, y: 0 }}
          transition={{ duration: 1, ease: 'easeOut' }}
        >
          <span>MIST ISLAND · 07</span>
          <h1>晨雾岛屿</h1>
          <p>今天的潮汐很轻，适合把心事写进手帐。</p>
        </motion.div>

        <motion.form
          className={`hanging-form ${mode === 'register' ? 'hanging-form-register' : ''}`}
          onSubmit={submit}
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: success ? 0 : 1, y: 0 }}
          transition={{ duration: 1, ease: 'easeOut', delay: .12 }}
        >
          <div className="hanging-rope hanging-rope-main" aria-hidden="true"><span /></div>

          <HangingPlank className="hanging-plank-name" paused={activeField === 'username'}>
            <label htmlFor="auth-username">账号名</label>
            <input
              id="auth-username"
              value={username}
              onChange={(event) => setUsername(event.target.value)}
              onFocus={() => setActiveField('username')}
              onBlur={() => setActiveField(null)}
              placeholder="例如 xiaoyu_01"
              autoComplete="username"
              maxLength={32}
              disabled={busy}
            />
          </HangingPlank>

          {mode === 'register' && (
            <motion.div
              className="hanging-register-plank"
              initial={{ opacity: 0, y: -10, scale: .95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ duration: .32 }}
            >
              <label htmlFor="auth-display-name">昵称（可选）</label>
              <input id="auth-display-name" value={displayName} onChange={(event) => setDisplayName(event.target.value)} placeholder="希望被怎样称呼？" autoComplete="name" maxLength={32} disabled={busy} />
            </motion.div>
          )}

          <span className="hanging-rope hanging-rope-join" aria-hidden="true"><i /></span>

          <HangingPlank className="hanging-plank-password" paused={activeField === 'password'}>
            <label htmlFor="auth-password">树洞暗号</label>
            <input
              id="auth-password"
              type="password"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              onFocus={() => setActiveField('password')}
              onBlur={() => setActiveField(null)}
              placeholder="盛一勺星光进去"
              autoComplete={mode === 'register' ? 'new-password' : 'current-password'}
              maxLength={128}
              disabled={busy}
            />
          </HangingPlank>

          <div className="hanging-mode" role="tablist" aria-label="账号操作">
            <button type="button" className={mode === 'login' ? 'active' : ''} onClick={() => switchMode('login')} disabled={busy}>登录账号</button>
            <button type="button" className={mode === 'register' ? 'active' : ''} onClick={() => switchMode('register')} disabled={busy}>注册账号</button>
          </div>

          <p className="hanging-auth-hint">
            {mode === 'login'
              ? '新用户先注册，注册完成后即可登录。'
              : '账号 3-32 位；密码 8-128 位，注册后自动登录。'}
          </p>

          {error && <p className="hanging-error" role="alert">{error}</p>}

          <button className="hanging-lantern-button" type="submit" disabled={busy} aria-label={mode === 'register' ? '创建账号并启封登岛' : '登录并启封登岛'}>
            <span className="hanging-lantern" aria-hidden="true"><i /><b /><em /></span>
            <strong>启封·登岛</strong>
          </button>
        </motion.form>

        <motion.button
          className="hanging-guest"
          type="button"
          onClick={() => void guest()}
          disabled={busy}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: success ? 0 : 1, y: 0 }}
          transition={{ duration: .8, delay: .4, ease: 'easeOut' }}
        >
          以游客身份悄悄登岛
        </motion.button>
      </div>
      <motion.div className="hanging-success-wash" initial={{ opacity: 0 }} animate={{ opacity: success ? 1 : 0 }} transition={{ duration: .8 }} aria-hidden="true" />
    </main>
  );
}

export default LoginPage;
