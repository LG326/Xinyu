import { useEffect, useMemo, useRef, useState } from 'react';
import type { CSSProperties } from 'react';
import Chat from '@chatui/core';
import { AudioControl } from '../components/AudioControl';
import { Bubble } from '../components/Bubble';
import { RadioCard } from '../components/RadioCard';
import { initAudio, playRadioTrack, playSfx, setThemeSoundscape } from '../audio';
import { MemoryPanel } from '../components/MemoryPanel';
import type { MemoryItem } from '../components/MemoryPanel';
import { journalSignature, loadJournalEntries, subscribeJournal } from '../journal';
import type { JournalEntry } from '../journal';
import { PetActor } from '../components/PetActor';
import { RoomPanel } from '../components/RoomPanel';
import type { RoomTab } from '../components/RoomPanel';
import { StudyRoom } from '../components/StudyRoom';
import { ACCESSORIES, DAILY_STARLIGHT_REWARD, getInitialRoomState, getLocalDateKey, ROOM_FURNITURE } from '../room';
import type { AccessoryId, RoomFurnitureId, RoomState } from '../room';
import { petImageSrc } from '../components/PetSprite';
import { PetAccessoryLayer } from '../components/PetAccessory';
import { adoptPet, addChatBond, collectPet, dispatchPet, getInitialPetState, petStatus, savePetState, speciesById } from '../pets';
import type { PetSpeciesId, PetState } from '../pets';
import type { ChatMessage, Emotion, ThemeName } from '../types';
import styles from './ChatPage.module.css';
import { apiFetch, type AuthAccount } from '../auth';

const ALIAS_KEY = 'xinyu-companion-alias';
const SKIN_KEY = 'xinyu-companion-skin';
const ACTIVE_PET_KEY = 'xinyu-active-pet';
const initialMessage: ChatMessage = {
  _id: 'welcome', type: 'text', position: 'left', content: { text: '我在。今天想聊点什么？' }, emotion: '平静',
};

function getInitialAlias(key: string, fallback: string): string {
  return window.localStorage.getItem(key)?.trim() || fallback.trim() || '小屿';
}

function getInitialSkin(key = SKIN_KEY): string {
  return window.localStorage.getItem(key)?.trim() || 'island';
}

interface StoryState {
  progress: number;
  chapter: number;
  title: string;
  next_hint: string;
}

interface Skin {
  id: string;
  name: string;
  description: string;
  style: string;
}

const skinUnlockAt: Record<string, number> = { island: 0, stargazer: 20, adventure: 60 };

function isSkinUnlocked(skin: Skin, progress: number, currentSkin: string): boolean {
  // Keep an already selected skin usable if an older server profile predates these UI rules.
  return skin.id === currentSkin || progress >= (skinUnlockAt[skin.id] ?? 100);
}

function particleStyle(index: number): CSSProperties {
  const left = (index * 37) % 100;
  const top = (index * 61) % 100;
  const delay = -((index * 1.7) % 14);
  const size = 1 + (index % 3) * .55;
  return { left: `${left}%`, top: `${top}%`, width: `${size}px`, height: `${size}px`, animationDelay: `${delay}s` };
}

interface ChatPageProps {
  account: AuthAccount;
  onLogout: () => void;
}

export function ChatPage({ account, onLogout }: ChatPageProps) {
  const theme: ThemeName = 'morning';
  const USER_ID = account.id;
  const storageScope = account.id;
  const aliasKey = `${ALIAS_KEY}:${account.id}`;
  const skinKey = `${SKIN_KEY}:${account.id}`;
  const activePetKey = `${ACTIVE_PET_KEY}:${account.id}`;
  const roomKey = `xinyu-room-state:${storageScope}`;
  const [alias, setAlias] = useState(() => getInitialAlias(aliasKey, account.display_name));
  const [draftAlias, setDraftAlias] = useState(alias);
  const [skinId, setSkinId] = useState(() => getInitialSkin(skinKey));
  const [skins, setSkins] = useState<Skin[]>([]);
  const [story, setStory] = useState<StoryState>({ progress: 0, chapter: 1, title: '岛屿日志 · 第 1 章', next_hint: '继续记录一次真实近况' });
  const [skinSaving, setSkinSaving] = useState<string | null>(null);
  const [bondValue, setBondValue] = useState(40);
  const [messages, setMessages] = useState<ChatMessage[]>([initialMessage]);
  const [emotion, setEmotion] = useState<Emotion>('平静');
  const [isSending, setIsSending] = useState(false);
  const [bondRaised, setBondRaised] = useState(false);
  const [typingId, setTypingId] = useState<string | null>(null);
  const [memoryOpen, setMemoryOpen] = useState(false);
  const [remoteMemories, setRemoteMemories] = useState<MemoryItem[]>([]);
  const [localJournal, setLocalJournal] = useState<JournalEntry[]>(() => loadJournalEntries(storageScope));
  const [leftOpen, setLeftOpen] = useState(false);
  const [rightOpen, setRightOpen] = useState(false);
  const [activeHint, setActiveHint] = useState('小屿正在等你说话…');
  const [roomOpen, setRoomOpen] = useState(false);
  const [studyOpen, setStudyOpen] = useState(false);
  const [roomTab, setRoomTab] = useState<RoomTab>('room');
  const [room, setRoom] = useState<RoomState>(() => getInitialRoomState(storageScope));
  const [petState, setPetState] = useState<PetState>(() => getInitialPetState(storageScope));
  const [activePetId, setActivePetId] = useState<string | null>(() => window.localStorage.getItem(activePetKey));
  const [petNow, setPetNow] = useState(() => Date.now());
  const [bondGain, setBondGain] = useState(0);
  const typingTimerRef = useRef<number | null>(null);
  const bondGainTimerRef = useRef<number | null>(null);

  useEffect(() => {
    initAudio();
  }, []);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    window.localStorage.setItem('xinyu-chat-theme', 'morning');
    setThemeSoundscape(theme);
  }, []);

  useEffect(() => {
    window.localStorage.setItem(roomKey, JSON.stringify(room));
  }, [room, roomKey]);

  useEffect(() => {
    savePetState(petState, storageScope);
  }, [petState, storageScope]);

  // 旅伴的旅行进度用时间戳推算，这里节流刷新一次，用来提示“已经回家”。
  useEffect(() => {
    const timer = window.setInterval(() => setPetNow(Date.now()), 10000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => () => {
    if (typingTimerRef.current) window.clearInterval(typingTimerRef.current);
    if (bondGainTimerRef.current) window.clearTimeout(bondGainTimerRef.current);
  }, []);

  useEffect(() => {
    apiFetch('/api/skins')
      .then((response) => response.ok ? response.json() : Promise.reject(new Error('skins failed')))
      .then((data) => setSkins(Array.isArray(data.skins) ? data.skins : []))
      .catch(() => undefined);
    apiFetch('/api/story')
      .then((response) => response.ok ? response.json() : Promise.reject(new Error('story failed')))
      .then((data) => {
        if (data && Number.isFinite(Number(data.progress))) {
          setStory({ progress: Number(data.progress), chapter: Number(data.chapter) || 1, title: String(data.title || ''), next_hint: String(data.next_hint || '') });
        }
      })
      .catch(() => undefined);
  }, []);

  useEffect(() => {
    apiFetch('/api/memories?limit=100').then((r) => r.ok ? r.json() : null).then((data) => {
      if (data && Array.isArray(data.memories)) setRemoteMemories(data.memories);
    }).catch(() => undefined);
  }, []);

  // 本地手帐（用户在面板里写、或点「写进手帐」记下的）变化时同步过来。
  useEffect(() => subscribeJournal(setLocalJournal, storageScope), [storageScope]);

  useEffect(() => {
    apiFetch('/api/history')
      .then((response) => response.ok ? response.json() : Promise.reject(new Error('history failed')))
      .then((data) => {
        if (Array.isArray(data.messages) && data.messages.length) {
          setMessages(data.messages.map((message: { id: string; role: string; content: string }) => ({
            _id: message.id, type: 'text', position: message.role === 'user' ? 'right' : 'left', content: { text: message.content },
          })));
        }
        if (Number.isFinite(Number(data.bond_value))) setBondValue(Number(data.bond_value));
        if (data.companion_alias) { setAlias(data.companion_alias); setDraftAlias(data.companion_alias); }
        if (data.skin_id) { setSkinId(String(data.skin_id)); window.localStorage.setItem(skinKey, String(data.skin_id)); }
      })
      .catch(() => undefined);
  }, []);

  // 手帐 = 用户本地写下的内容 + 后端长期记忆，去重后按时间倒序。
  const journalView = useMemo(() => {
    const signatures = new Set(localJournal.map((entry) => journalSignature(entry.content)));
    return [
      ...localJournal.map((entry) => ({ id: entry.id, content: entry.content, created_at: entry.created_at })),
      ...remoteMemories
        .filter((item) => !signatures.has(journalSignature(item.content)))
        .map((item) => ({ id: String(item.id), content: item.content, created_at: item.created_at })),
    ].sort((a, b) => new Date(b.created_at || 0).getTime() - new Date(a.created_at || 0).getTime());
  }, [localJournal, remoteMemories]);
  const memoryCount = journalView.length;
  const recentMemories = journalView.slice(0, 3);

  const particles = useMemo(() => Array.from({ length: 24 }, (_, index) => index), []);
  const pendingPostcards = petState.pets.filter((pet) => petStatus(pet, petNow) === 'returned').length;
  const activePet = petState.pets.find((pet) => pet.id === activePetId)
    || petState.pets.find((pet) => petStatus(pet, petNow) !== 'traveling')
    || petState.pets[0]
    || null;
  const activeAccessories = ACCESSORIES.filter((item) => room.accessories.includes(item.id));

  useEffect(() => {
    if (activePet) {
      if (activePetId !== activePet.id) {
        setActivePetId(activePet.id);
        window.localStorage.setItem(activePetKey, activePet.id);
      }
      return;
    }
    if (activePetId) {
      setActivePetId(null);
      window.localStorage.removeItem(activePetKey);
    }
  }, [activePet, activePetId]);

  const saveAlias = async () => {
    const nextAlias = draftAlias.trim().slice(0, 32) || '小屿';
    setAlias(nextAlias);
    window.localStorage.setItem(aliasKey, nextAlias);
    await apiFetch('/api/preferences', {
      method: 'PUT', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ user_id: USER_ID, mode: 'reality', companion_alias: nextAlias, skin_id: skinId, reminder_frequency: 'standard' }),
    }).catch(() => undefined);
  };

  const selectSkin = async (nextSkinId: string) => {
    const nextSkin = skins.find((skin) => skin.id === nextSkinId);
    if (!nextSkin || !isSkinUnlocked(nextSkin, story.progress, skinId) || skinSaving) return;
    const previousSkin = skinId;
    setSkinId(nextSkinId);
    setSkinSaving(nextSkinId);
    window.localStorage.setItem(skinKey, nextSkinId);
    try {
      const response = await apiFetch('/api/preferences', {
        method: 'PUT', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ user_id: USER_ID, mode: 'reality', companion_alias: alias, skin_id: nextSkinId, reminder_frequency: 'standard' }),
      });
      if (!response.ok) throw new Error('skin save failed');
      setActiveHint(`${nextSkin.name} 已换上`);
    } catch {
      setSkinId(previousSkin);
      window.localStorage.setItem(skinKey, previousSkin);
      setActiveHint('皮肤暂时没有保存成功，请再试一次');
    } finally {
      setSkinSaving(null);
    }
  };

  const showBondGain = (amount: number) => {
    setBondGain(amount);
    if (bondGainTimerRef.current) window.clearTimeout(bondGainTimerRef.current);
    bondGainTimerRef.current = window.setTimeout(() => setBondGain(0), 2600);
  };

  const adoptNewPet = (speciesId: PetSpeciesId) => {
    const result = adoptPet(petState, speciesId);
    setPetState(result.state);
    setActiveHint(result.message);
    if (result.ok) {
      const adoptedPet = result.state.pets[result.state.pets.length - 1];
      if (adoptedPet) {
        setActivePetId(adoptedPet.id);
        window.localStorage.setItem(activePetKey, adoptedPet.id);
      }
    }
    if (result.ok) playSfx('toggle');
  };

  const selectActivePet = (petId: string) => {
    const pet = petState.pets.find((item) => item.id === petId);
    if (!pet) return;
    setActivePetId(pet.id);
    window.localStorage.setItem(activePetKey, pet.id);
    setActiveHint(`${pet.name}成为主页面旅伴`);
  };

  const sendPetTraveling = (petId: string, destinationId: string) => {
    const result = dispatchPet(petState, petId, destinationId);
    setPetState(result.state);
    setActiveHint(result.message);
    if (result.ok) playSfx('click');
  };

  const collectPetPostcard = (petId: string) => {
    const result = collectPet(petState, petId);
    setPetState(result.state);
    if (!result.ok) {
      setActiveHint(result.message);
      return;
    }
    if (result.starCoins > 0) setRoom((current) => ({ ...current, starCoins: current.starCoins + result.starCoins }));
    setActiveHint(`${result.message} · 还带回 ${result.starCoins} 枚星光币`);
    playSfx('toggle');
  };

  const handleSend = async (first: string, second?: string) => {
    const text = String(second ?? first ?? '').trim();
    if (!text || isSending) return;
    const userMessage: ChatMessage = { _id: `user-${Date.now()}`, type: 'text', position: 'right', content: { text } };
    setMessages((current) => [...current, userMessage]);
    playSfx('send');
    setIsSending(true);
    setActiveHint('小屿正在整理你的这句话…');
    try {
      const response = await apiFetch('/api/chat', {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ user_id: USER_ID, message: text, mode: 'reality', companion_alias: alias, skin_id: skinId }),
      });
      if (!response.ok) throw new Error('chat failed');
      const data = await response.json();
      const reply = String(data.reply || '我在。');
      const assistantId = `assistant-${Date.now()}`;
      const replyEmotion = (data.emotion || '平静') as Emotion;
      if (data.usage_notice) setActiveHint(String(data.usage_notice));
      if (data.memory_event) {
        setActiveHint('小屿把这件事记进手帐了');
        apiFetch('/api/memories?limit=100').then((memoryResponse) => memoryResponse.ok ? memoryResponse.json() : null).then((memoryData) => {
          if (memoryData && Array.isArray(memoryData.memories)) setRemoteMemories(memoryData.memories);
        }).catch(() => undefined);
      } else if (data.simulation) {
        setActiveHint('模拟推演已完成');
      } else if (data.interaction_event) {
        setActiveHint('小屿接住了这份亲密互动');
      }
      // 每聊一轮攒好感度，用来领养旅伴和送它们出门旅行。
      const bondDelta = Number(data.bond_delta) || 0;
      const previewGain = addChatBond(petState, bondDelta).gained;
      setPetState((current) => addChatBond(current, bondDelta).state);
      if (previewGain > 0) showBondGain(previewGain);
      setMessages((current) => [...current, { _id: assistantId, type: 'text', position: 'left', content: { text: '' }, emotion: replyEmotion }]);
      setTypingId(assistantId);
      setActiveHint('小屿正在输入…');
      let cursor = 0;
      typingTimerRef.current = window.setInterval(() => {
        cursor += 1;
        setMessages((current) => current.map((item) => item._id === assistantId ? { ...item, content: { text: reply.slice(0, cursor) } } : item));
        if (cursor >= reply.length) {
          if (typingTimerRef.current) window.clearInterval(typingTimerRef.current);
          typingTimerRef.current = null;
          setTypingId(null);
          setIsSending(false);
          setActiveHint('小屿在等你说话');
        }
      }, 34);
      if (Number.isFinite(Number(data.bond_value))) setBondValue(Number(data.bond_value));
      if (data.story && Number.isFinite(Number(data.story.progress))) setStory({ progress: Number(data.story.progress), chapter: Number(data.story.chapter) || 1, title: String(data.story.title || ''), next_hint: String(data.story.next_hint || '') });
      if (Number(data.bond_delta) > 0) { setBondRaised(true); window.setTimeout(() => setBondRaised(false), 1300); }
      if (data.emotion) setEmotion(data.emotion as Emotion);
    } catch {
      setMessages((current) => [...current, { _id: `error-${Date.now()}`, type: 'text', position: 'left', content: { text: '现在还没连上后端。启动 API 后再来找我。' }, emotion: '平静' }]);
      setIsSending(false);
      setActiveHint('小屿暂时没连上后端');
    }
  };

  const openRoom = (tab: RoomTab = 'room') => {
    setRoomTab(tab);
    setRoomOpen(true);
  };

  const openStudy = () => {
    setStudyOpen(true);
    setActiveHint('进入自习室，先专注这一段时间');
  };

  const claimDailyStars = () => {
    if (room.lastDailyClaim === getLocalDateKey()) return;
    setRoom((current) => ({ ...current, starCoins: current.starCoins + DAILY_STARLIGHT_REWARD, lastDailyClaim: getLocalDateKey() }));
    setActiveHint('今日星光已收下，小屿把它放进房间了');
  };

  const buyFurniture = (id: RoomFurnitureId) => {
    const item = ROOM_FURNITURE.find((entry) => entry.id === id);
    if (!item || room.ownedFurniture.includes(id)) return;
    if (room.starCoins < item.price) {
      setActiveHint(`再陪小屿聊一会儿，就能带走${item.name}`);
      return;
    }
    setRoom((current) => ({ ...current, starCoins: current.starCoins - item.price, ownedFurniture: [...current.ownedFurniture, id], activeFurniture: id }));
    setActiveHint(`${item.name}已经放进房间，小屿有新的地方待着了`);
  };

  const selectFurniture = (id: RoomFurnitureId) => {
    const item = ROOM_FURNITURE.find((entry) => entry.id === id);
    if (!item || !room.ownedFurniture.includes(id)) return;
    setRoom((current) => ({ ...current, activeFurniture: id }));
    setActiveHint(item.action);
  };

  const toggleAccessory = (id: AccessoryId) => {
    setRoom((current) => ({
      ...current,
      accessories: current.accessories.includes(id)
        ? current.accessories.filter((item) => item !== id)
        : [...current.accessories, id],
    }));
    setActiveHint('小配饰已经更新，可以继续叠加其他配饰');
  };

  // 配饰位置按「物种 + 配饰」记录，拖动换装预览里的配饰即可微调佩戴位置。
  // 只更新坐标，保留用户已经调好的大小倍率，避免一拖动就跳回初始大小。
  const moveAccessory = (speciesId: PetSpeciesId, id: AccessoryId, dx: number, dy: number) => {
    setRoom((current) => {
      const key = `${speciesId}:${id}`;
      const base = current.accessoryOffsets[key] || {};
      return {
        ...current,
        accessoryOffsets: { ...current.accessoryOffsets, [key]: { ...base, dx, dy } },
      };
    });
  };

  const resetAccessoryOffsets = (speciesId: PetSpeciesId) => {
    setRoom((current) => {
      const next = { ...current.accessoryOffsets };
      for (const key of Object.keys(next)) {
        if (key.startsWith(`${speciesId}:`)) delete next[key];
      }
      return { ...current, accessoryOffsets: next };
    });
    setActiveHint('已经恢复这只旅伴的默认佩戴位置');
  };

  const resizeAccessory = (speciesId: PetSpeciesId, id: AccessoryId, scale: number) => {
    setRoom((current) => {
      const key = `${speciesId}:${id}`;
      const base = current.accessoryOffsets[key] || { dx: 0, dy: 0 };
      return {
        ...current,
        accessoryOffsets: { ...current.accessoryOffsets, [key]: { ...base, scale } },
      };
    });
  };

  const triggerQuickAction = (action: string) => {
    if (action.includes('换装') || action.includes('配饰')) {
      openRoom('wardrobe');
      return;
    }
    // 点「晚安电台」顺手把电台开播，可以边听边聊。
    if (action.includes('晚安电台')) {
      playRadioTrack('tide');
      setActiveHint('晚安电台已开播 · 潮汐小夜曲');
    }
    // 「写进手帐」打开真正的手帐编辑器，由用户填写要记录的内容；
    // 不再把示例句“清晨喝咖啡”偷偷写入手帐或发送给模型。
    if (action.includes('写进手帐')) {
      setMemoryOpen(true);
      setActiveHint('手帐已经打开，写下你真正想记住的内容吧');
      return;
    }
    handleSend('text', quickActionText[action]);
  };

  const quickActions = ['🖐️ 摸摸头', '☕ 送杯热茶', '📖 写进手帐', '🌙 晚安电台'];

  const quickActionText: Record<string, string> = {
    '摸摸头': '我想被你摸摸头。', '✨ 摸摸头': '我想被你摸摸头。',
    '🖐️ 摸摸头': '我想被你摸摸头。',
    '送杯热茶': '给你送一杯热茶，陪你坐一会儿。', '☕ 送杯热茶': '给你送一杯热茶，陪你坐一会儿。',
    '📷 分享今天': '我想和你分享今天发生的一件事。',
    '分享今天': '我想和你分享今天发生的一件事。', '🌌 分享今天': '我想和你分享今天发生的一件事。',
    '📖 写进手帐': '',
    '🌙 晚安电台': '我有点累，想听一段晚安电台。',
    '👕 换装': '我想给小屿加一件小配饰。',
    '换装': '我想给小屿加一件小配饰。', '🎭 换装': '我想给小屿加一件小配饰。',
    '◈ 系统状态': '/status', '/status': '/status', '/analyze 今日状态': '/analyze 今日状态', '/mission 今日任务': '/mission 今日任务',
    '⚡ 物理接触警报': '我想被你摸摸头。',
  };

  const modeProfile = {
    eyebrow: 'ISLAND JOURNAL / 07',
    title: '晨雾岛屿',
    subtitle: '今天的潮汐很轻，适合把心事写进手帐。',
    stageLabel: '岛屿灯火 · 正在为你亮着',
    panelLabel: '岛屿状态',
    activity: '潮汐平稳 · 适合慢慢说话',
  };
  return (
    <main className={`${styles.page} ${styles.morning}`} data-theme="morning">
      <div className={styles.particles} aria-hidden="true">{particles.map((index) => <i key={index} style={particleStyle(index)} />)}</div>
      <header className={styles.header}>
        <div className={styles.identity}>
          <div className={styles.avatar} data-emotion={emotion} data-skin={skinId} style={{ '--emotion-glow': `var(--emotion-${emotion})` } as CSSProperties} aria-hidden="true"><img className={styles.avatarImage} src={petImageSrc(activePet?.speciesId || 'frog')} alt="" /></div>
          <div><strong>{alias}</strong><span><i />{activePet ? `${activePet.name} · ${speciesById(activePet.speciesId).name}` : modeProfile.activity}</span></div>
        </div>
        <div className={styles.headerWidget}>
          <span>☁️ 情绪：{emotion}</span>
          <span className={styles.widgetBond}>♥ 羁绊 {Math.round(bondValue)}/100</span>
          <div className={styles.bondProgress}><i style={{ width: `${Math.min(100, Math.max(0, bondValue))}%` }} /></div>
        </div>
        <div className={styles.headerActions}><button className={styles.memoryButton} type="button" onClick={() => setMemoryOpen(true)}>📖 记忆 <em>{memoryCount}</em></button><AudioControl theme={theme} /><button className={styles.memoryButton} type="button" onClick={onLogout}>退出登录</button></div>
      </header>
      <div className={styles.divider} />
      <p className={styles.tagline}><span>{modeProfile.eyebrow}</span> {modeProfile.title} · {modeProfile.subtitle}</p>
      <div className={styles.workspace}>
        <aside className={`${styles.companionPanel} ${leftOpen ? styles.drawerOpen : ''}`} aria-label="角色陪伴区">
          <button className={styles.drawerToggle} type="button" onClick={() => setLeftOpen((value) => !value)} aria-expanded={leftOpen}>☾ <span>{modeProfile.panelLabel}</span><b>{leftOpen ? '收起' : '展开'}⌄</b></button>
          <div className={styles.companionBody}>
            <div className={`${styles.characterStage} ${styles.islandStage}`} aria-label="晨雾岛屿中的小屿">
              <>
                <span className={`${styles.sceneCloud} ${styles.sceneCloudOne}`} />
                <span className={`${styles.sceneCloud} ${styles.sceneCloudTwo}`} />
                <span className={styles.sceneSunbeam} />
                <span className={styles.scenePetals}>✿　·　✧</span>
              </>
              <div className={styles.characterHalo} />
              {activePet ? (
                <span className={styles.stageActor}>
                  <PetActor species={activePet.speciesId} name={activePet.name} owner={alias} />
                  <PetAccessoryLayer items={activeAccessories.map((item) => item.id)} species={activePet.speciesId} variant="stage" offsets={room.accessoryOffsets} />
                </span>
              ) : (
                <span className={styles.stageActor}>
                  <PetActor species="frog" name="小蛙" owner={alias} />
                  <PetAccessoryLayer items={activeAccessories.map((item) => item.id)} species="frog" variant="stage" offsets={room.accessoryOffsets} />
                </span>
              )}
              <div className={styles.characterStars}>✿　·　☾</div>
            </div>
            <span className={styles.modeEyebrow}>{modeProfile.eyebrow}</span>
            <h2>{activePet?.name || '小蛙'}</h2><p className={styles.characterCaption}>{activePet ? `${speciesById(activePet.speciesId).name} · ${speciesById(activePet.speciesId).intro}` : '青蛙旅伴 · 免费加入，陪你慢慢旅行'}</p>
            <div className={styles.bondCircle} style={{ '--bond-percent': `${Math.min(100, Math.max(0, bondValue))}%` } as CSSProperties}><div><strong>{Math.round(bondValue)}</strong><small>羁绊值</small></div></div>
            <div className={styles.companionActions}>
              <button type="button" onClick={() => openRoom('wardrobe')}><span>🧢</span> 配饰</button>
              <button type="button" onClick={() => openRoom('room')}><span>⌂</span> 小屿的房间</button>
              <button className={styles.travelAction} type="button" onClick={() => openRoom('travel')}><span>✉</span> 旅伴与明信片{pendingPostcards > 0 ? ` · ${pendingPostcards} 张待领` : ''}</button>
              <button className={styles.studyAction} type="button" onClick={openStudy}><span>📖</span> 自习室</button>
            </div>
            <>
              <div className={styles.companionStat}><span>今日陪伴</span><strong>23 分钟 · +{DAILY_STARLIGHT_REWARD} 星光币</strong></div>
              <div className={styles.companionStat}><span>状态</span><strong className={styles.online}><i />在线</strong></div>
              <div className={styles.storyMini}><span>今日手帐</span><strong>{story.title || `岛屿日志 · 第 ${story.chapter} 章`}</strong><div className={styles.storyTrack}><i style={{ width: `${story.progress}%` }} /></div><small>{story.progress}% · {story.next_hint}</small></div>
            </>
          </div>
        </aside>
        <section className={styles.chatColumn}>
          <div className={styles.behaviorHint}>✦ {activeHint}{bondGain > 0 && <span className={styles.bondGain}>♥ 好感度 +{bondGain}</span>}</div>
          <section className={styles.chatFrame}>
        <div className={`${styles.metaRow} ${styles.morningMeta}`}>
          <div><span className={styles.modeLabel}>{modeProfile.title}</span><small>{modeProfile.subtitle}</small></div>
          <div className={styles.settings}><label htmlFor="alias">称呼</label><input id="alias" value={draftAlias} maxLength={32} onChange={(event) => setDraftAlias(event.target.value)} onBlur={saveAlias} /></div>
        </div>
        <div className={`${styles.modeDeck} ${styles.morningDeck}`}>
          <span className={styles.deckIcon}>☼</span><div><b>今日潮汐</b><small>把一件小事交给手帐，或者打开晚安电台。</small></div><button type="button" onClick={openStudy}>📖 自习室</button><button type="button" onClick={() => triggerQuickAction('🌙 晚安电台')}>🌙 晚安电台</button>
        </div>
        <div className={styles.chatShell}>
          <Chat
            locale="zh-CN"
            messages={messages}
            onSend={handleSend}
            placeholder="今天想聊点什么？"
            isTyping={isSending}
            renderQuickReplies={() => <div className={styles.quickActions} role="toolbar" aria-label="快捷互动">{quickActions.map((action) => <button key={action} type="button" onClick={() => triggerQuickAction(action)}>{action}</button>)}</div>}
            renderMessageContent={(message) => <Bubble message={message as ChatMessage} alias={alias} companionSpecies={activePet?.speciesId} bondValue={bondValue} bondRaised={bondRaised} isLatest={message._id === messages[messages.length - 1]?._id} isTyping={message._id === typingId} />}
            navbar={{ title: '' }}
          />
        </div>
        {isSending && <span className={styles.sending}>小屿正在想怎么接住这句话…</span>}
        <div className={styles.footerNote}>羁绊值每日有上限 · 不与付费绑定 · 不替代现实关系或专业心理服务</div>
          </section>
        </section>
        <aside className={`${styles.statusPanel} ${rightOpen ? styles.drawerOpen : ''}`} aria-label="小屿状态面板">
          <button className={styles.drawerToggle} type="button" onClick={() => setRightOpen((value) => !value)} aria-expanded={rightOpen}>☁ <span>岛屿手帐</span><b>{rightOpen ? '收起' : '展开'}⌄</b></button>
          <div className={styles.statusBody}>
            <>
              <div className={styles.statusCard}><span className={styles.cardIcon}>☁</span><div><small>现在的心情</small><strong>{emotion}</strong></div><em className={styles.emotionDot} style={{ background: `var(--emotion-${emotion})` }} /></div>
              <div className={styles.statusCard}><span className={styles.cardIcon}>♥</span><div><small>羁绊值</small><strong>{Math.round(bondValue)} / 100</strong><div className={styles.miniProgress}><i style={{ width: `${Math.min(100, Math.max(0, bondValue))}%` }} /></div></div></div>
              <div className={`${styles.statusCard} ${styles.memoryCard}`}><span className={styles.cardIcon}>▤</span><div><small>最近写进手帐</small>{recentMemories.length ? recentMemories.map((memory) => <p key={memory.id}>{memory.content}</p>) : <p>还没有新的长期记忆</p>}</div></div>
              <RadioCard />
            </>
            <div className={styles.statusCard}><span className={styles.cardIcon}>🐸</span><div><small>当前旅伴</small><strong>{activePet?.name || '小蛙'} · {speciesById(activePet?.speciesId || 'frog').name}</strong><p>{activeHint}</p><button className={styles.inlineAction} type="button" onClick={() => openRoom('travel')}>更换旅伴</button></div></div>
            <div className={styles.statusCard}><span className={styles.cardIcon}>✦</span><div><small>陪伴状态</small><strong>在线 · 健康陪伴</strong><p>青蛙是免费初始旅伴，其他小动物可在旅伴页解锁。</p></div></div>
            <button className={styles.openMemory} type="button" onClick={() => setMemoryOpen(true)}>▤ 查看全部记忆 <span>{memoryCount}</span></button>
          </div>
        </aside>
      </div>
      <MemoryPanel userId={USER_ID} storageScope={storageScope} open={memoryOpen} onClose={() => setMemoryOpen(false)} onMemoriesChange={setRemoteMemories} />
      <StudyRoom open={studyOpen} alias={alias} onClose={() => setStudyOpen(false)} />
      <RoomPanel storageScope={storageScope} open={roomOpen} tab={roomTab} alias={alias} room={room} petState={petState} activePet={activePet} activePetId={activePetId} onSelectActive={selectActivePet} onClose={() => setRoomOpen(false)} onTabChange={setRoomTab} onClaimDaily={claimDailyStars} onBuy={buyFurniture} onSelectFurniture={selectFurniture} onToggleAccessory={toggleAccessory} onDecorChange={(next) => setRoom((current) => ({ ...current, decor: next }))} onMoveAccessory={moveAccessory} onResizeAccessory={resizeAccessory} onResetAccessories={resetAccessoryOffsets} onAdoptPet={adoptNewPet} onDispatchPet={sendPetTraveling} onCollectPet={collectPetPostcard} />
    </main>
  );
}
