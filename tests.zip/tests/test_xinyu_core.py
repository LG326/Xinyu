from __future__ import annotations

import shutil
import sqlite3
import tempfile
import unittest
from pathlib import Path

from database import SQLiteStore
from intimacy import BondSignal, calculate_bond_signal
from nodes import (
    CHAT_PROMPT,
    _answer_memory_question,
    _command_response,
    _extract_user_fact,
    _interaction_instruction,
    emotion_analysis_node,
    response_generation_node,
)


class XinyuCoreTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = Path(tempfile.mkdtemp(prefix="xinyu-tests-"))
        self.db_path = self.temp_dir / "xinyu.sqlite3"

    def tearDown(self) -> None:
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_new_profile_defaults_to_reality_and_xiaoyu(self) -> None:
        profile = SQLiteStore(self.db_path).get_profile()
        self.assertEqual(profile.user_id, "default_user")
        self.assertEqual(profile.display_name, "你")
        self.assertEqual(profile.mode, "reality")
        self.assertEqual(profile.companion_alias, "小屿")

    def test_bond_daily_positive_cap_is_three(self) -> None:
        store = SQLiteStore(self.db_path)
        self.assertEqual(store.apply_bond_delta(2, "daily_sharing")[1], 2)
        self.assertEqual(store.apply_bond_delta(2, "care_expression")[1], 1)
        self.assertEqual(store.apply_bond_delta(2, "daily_sharing")[1], 0)
        self.assertEqual(store.get_profile().bond_value, 43)

    def test_preferences_and_usage_stats_are_persisted(self) -> None:
        store = SQLiteStore(self.db_path)
        store.get_profile()
        store.set_preferences("default_user", mode="dimensional", companion_alias="屿")
        store.save_turn("今天很累", "先休息一下", "难过")
        profile = store.get_profile()
        self.assertEqual(profile.mode, "dimensional")
        self.assertEqual(profile.companion_alias, "屿")
        self.assertEqual(store.get_usage_stats()["today_messages"], 1)

    def test_memory_items_story_and_interaction_events(self) -> None:
        store = SQLiteStore(self.db_path)
        store.get_profile()
        memory_id = store.add_memory_item("default_user", "我喜欢海盐拿铁", "开心")
        self.assertEqual(store.list_memory_items()[0]["id"], memory_id)
        self.assertTrue(store.delete_memory_item("default_user", memory_id))
        store.record_interaction("default_user", "skin_changed", "stargazer")
        self.assertEqual(store.list_interactions()[0]["event_type"], "skin_changed")
        self.assertEqual(store.advance_story("default_user", "dimensional"), 1)

    def test_high_risk_is_detected_without_model(self) -> None:
        state = emotion_analysis_node({"user_input": "我不想活了"})
        self.assertEqual(state["risk_level"], "high")

        class FailingModel:
            def invoke(self, _prompt):
                raise AssertionError("high-risk responses must not call the model")

        result = response_generation_node(
            {"user_input": "我不想活了", "risk_level": "high"},
            {"configurable": {"chat_model": FailingModel()}},
        )
        self.assertIn("12356", result["response"])
        self.assertEqual(result["safety_notice"], "high_risk_referral")

    def test_mode_and_alias_are_prompt_variables(self) -> None:
        variables = CHAT_PROMPT.input_variables
        self.assertIn("mode", variables)
        self.assertIn("companion_alias", variables)
        self.assertIsInstance(calculate_bond_signal("今天下班了", "平静", None), BondSignal)

    def test_preference_memory_is_extracted_and_answered_deterministically(self) -> None:
        fact = _extract_user_fact("我喜欢吃西兰花")
        self.assertIsNotNone(fact)
        self.assertEqual(fact[1], "preference")

        class FailingModel:
            def invoke(self, _prompt):
                raise AssertionError("confirmed preference questions should not depend on model wording")

        result = response_generation_node(
            {"user_input": "我喜欢吃什么", "emotion": "平静", "memories": ["用户我喜欢吃西兰花"]},
            {"configurable": {"chat_model": FailingModel()}},
        )
        self.assertIn("西兰花", result["response"])
        self.assertIn("咖啡", _answer_memory_question("我喜欢喝什么？", ["用户我喜欢喝咖啡", "用户我喜欢跑步"]) or "")

    def test_mode_specific_commands_interactions_and_memory_receipts(self) -> None:
        self.assertIn("[系统分析]", _command_response("/analyze 今天的计划") or "")
        self.assertEqual(_interaction_instruction("我想摸摸头", "dimensional")[1], "head_pat")
        self.assertEqual(_interaction_instruction("给你送热茶", "reality")[1], "hot_tea")
        self.assertEqual(_extract_user_fact("帮我记住：我喜欢咖啡")[0], "用户我喜欢咖啡")

        class ShortModel:
            def invoke(self, _prompt):
                return type("Response", (), {"content": "收到，我记下啦。"})()

        result = response_generation_node(
            {
                "user_input": "我喜欢咖啡",
                "mode": "reality",
                "emotion": "平静",
                "history": [],
            },
            {"configurable": {"chat_model": ShortModel()}},
        )
        self.assertTrue("手帐" in result["response"] or "记下" in result["response"])
        self.assertEqual(result["memory_event"], "用户我喜欢咖啡")

    def test_dimensional_hypothesis_receives_simulation_label(self) -> None:
        class ShortModel:
            def invoke(self, _prompt):
                return type("Response", (), {"content": "星图开始重排，航线出现三种可能。"})()

        result = response_generation_node(
            {
                "user_input": "如果我生活在平行宇宙会怎样？",
                "mode": "dimensional",
                "emotion": "平静",
                "history": [],
            },
            {"configurable": {"chat_model": ShortModel()}},
        )
        self.assertIn("[模拟推演]", result["response"])
        self.assertTrue(result["simulation_requested"])

    def test_legacy_database_migrates_without_losing_history(self) -> None:
        connection = sqlite3.connect(self.db_path)
        connection.executescript(
            """
            CREATE TABLE user_profiles (
                user_id TEXT PRIMARY KEY, display_name TEXT NOT NULL,
                intimacy REAL NOT NULL DEFAULT 40, daily_positive REAL NOT NULL DEFAULT 0,
                gain_date TEXT NOT NULL, last_user_at TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
            );
            CREATE TABLE conversation_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT NOT NULL,
                role TEXT NOT NULL, content TEXT NOT NULL, emotion TEXT, created_at TEXT NOT NULL
            );
            CREATE TABLE intimacy_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT NOT NULL, event TEXT NOT NULL,
                requested_delta REAL NOT NULL, applied_delta REAL NOT NULL, created_at TEXT NOT NULL
            );
            INSERT INTO user_profiles VALUES ('司序', '司序', 44, 1, '2026-09-14', NULL, '2026-09-14', '2026-09-14');
            INSERT INTO conversation_history (user_id, role, content, emotion, created_at)
            VALUES ('司序', 'user', '我喜欢桂花乌龙', '开心', '2026-09-14T10:00:00');
            INSERT INTO intimacy_events VALUES (1, '司序', 'daily_sharing', 1, 1, '2026-09-14T10:00:00');
            """
        )
        connection.close()

        store = SQLiteStore(self.db_path)
        self.assertEqual(store.get_profile("default_user").bond_value, 44)
        self.assertEqual(len(store.load_history("default_user")), 1)
        names = {
            row[0]
            for row in sqlite3.connect(self.db_path).execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            )
        }
        self.assertIn("bond_events", names)
        self.assertNotIn("intimacy_events", names)


if __name__ == "__main__":
    unittest.main()
