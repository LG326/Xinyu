const state = {
  userId: localStorage.getItem('xinyu-user-id') || 'default_user',
  messages: [],
  bondValue: 40,
  mode: 'reality',
  companionAlias: localStorage.getItem('xinyu-companion-alias') || '小屿',
  emotion: '平静',
  sending: false,
  online: false,
};

const initialMessage = { id: 'welcome', role: 'assistant', content: '我在。今天想从哪件事说起？', status: 'sent' };
const messagesEl = document.querySelector('#messages');
const inputEl = document.querySelector('#message-input');
const sendButton = document.querySelector('#send-button');
const runtimePill = document.querySelector('.runtime-pill');
const runtimeLabel = document.querySelector('#runtime-label');

function setRuntime(online, label) {
  state.online = online;
  runtimePill.classList.toggle('offline', !online);
  runtimeLabel.textContent = label || (online ? 'API 已连接' : '演示模式');
  document.querySelector('#connection-hint').textContent = online ? '对话会同步到长期记忆' : 'API 未连接，可先浏览演示界面';
}

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[char]));
}

function renderMessages() {
  messagesEl.innerHTML = state.messages.map((message) => {
    const isUser = message.role === 'user';
    const avatar = isUser ? '' : '<img class="message-avatar" src="/web/assets/xinyu-avatar-crop.png" alt="小屿" />';
    const status = message.status === 'failed' ? '<div class="message-meta">发送失败 · 点击重新发送</div>' : '';
    return `<div class="message-row ${isUser ? 'user' : 'assistant'}">${avatar}<div><div class="bubble">${escapeHtml(message.content)}</div>${status}</div></div>`;
  }).join('');
  messagesEl.scrollTop = messagesEl.scrollHeight;
  document.querySelector('#message-count').textContent = `${state.messages.length} 条消息`;
}

function showTyping() {
  const node = document.createElement('div');
  node.className = 'message-row assistant typing';
  node.id = 'typing-indicator';
  node.innerHTML = '<img class="message-avatar" src="/web/assets/xinyu-avatar-crop.png" alt="小屿" /><div><div class="bubble"><i class="typing-dot"></i><i class="typing-dot"></i><i class="typing-dot"></i></div></div>';
  messagesEl.appendChild(node);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function updateInsights(data = {}) {
  const bondValue = Number(data.bond_value ?? data.intimacy);
  if (Number.isFinite(bondValue)) state.bondValue = Math.max(0, Math.min(100, bondValue));
  if (data.emotion) state.emotion = String(data.emotion);
  document.querySelector('#emotion-value').textContent = state.emotion;
  document.querySelector('#bond-value').textContent = Math.round(state.bondValue);
  document.querySelector('#bond-progress').style.width = `${state.bondValue}%`;
  const caption = state.bondValue >= 70 ? '表达更贴合 · 仍保持清晰边界' : state.bondValue >= 45 ? '熟悉感增加 · 每日有上限' : '从今天开始，慢慢建立默契';
  document.querySelector('#bond-caption').textContent = caption;
}

function setWorkflowActive(index) {
  document.querySelectorAll('.workflow-node').forEach((node, i) => node.classList.toggle('active', i <= index));
}

function modeLabel(mode) {
  return mode === 'dimensional' ? '次元星海' : '晨雾岛屿';
}

function syncModeButtons() {
  document.querySelectorAll('[data-mode]').forEach((button) => button.classList.toggle('active', button.dataset.mode === state.mode));
  document.querySelector('#connection-hint').textContent = `${modeLabel(state.mode)} · 核心记忆共享`;
}

async function loadHistory() {
  try {
    const response = await fetch(`/api/history?user_id=${encodeURIComponent(state.userId)}`);
    if (!response.ok) throw new Error('history request failed');
    const data = await response.json();
    // 页面只展示最近 12 条，避免历史较长时首屏被旧消息淹没；完整历史仍保留在后端记忆库。
    const history = Array.isArray(data.messages) ? data.messages : [];
    state.messages = history.length ? history.slice(-12) : [initialMessage];
    updateInsights(data);
    state.mode = data.mode || state.mode;
    syncModeButtons();
    state.companionAlias = data.companion_alias || state.companionAlias;
    document.querySelector('#companion-alias').value = state.companionAlias;
    if (data.reminder_frequency) document.querySelector('#reminder-frequency').value = data.reminder_frequency;
    if (data.story) document.querySelector('#story-progress').textContent = `剧情进度 ${data.story.progress}%`;
    setRuntime(true, 'API 已连接');
  } catch (error) {
    state.messages = [initialMessage];
    setRuntime(false, '演示模式');
  }
  renderMessages();
}

async function loadSkins() {
  try {
    const response = await fetch('/api/skins');
    const data = await response.json();
    const select = document.querySelector('#skin-select');
    (data.skins || []).forEach((skin) => {
      if (!select.querySelector(`option[value="${skin.id}"]`)) select.insertAdjacentHTML('beforeend', `<option value="${skin.id}">${escapeHtml(skin.name)}</option>`);
    });
  } catch (_) { /* skin list is an enhancement; chat remains usable */ }
}

async function loadMemories() {
  const list = document.querySelector('#memory-list');
  try {
    const response = await fetch(`/api/memories?user_id=${encodeURIComponent(state.userId)}`);
    const data = await response.json();
    const items = Array.isArray(data.memories) ? data.memories : [];
    list.innerHTML = items.length ? items.map((item) => `<div class="memory-item"><span>${escapeHtml(item.content)}</span><button type="button" data-memory-id="${item.id}" title="删除记忆">删除</button></div>`).join('') : '<p class="rail-note">还没有保存的记忆</p>';
    list.querySelectorAll('[data-memory-id]').forEach((button) => button.addEventListener('click', async () => { await fetch(`/api/memories/${button.dataset.memoryId}?user_id=${encodeURIComponent(state.userId)}`, { method: 'DELETE' }); loadMemories(); }));
  } catch (_) { list.innerHTML = '<p class="rail-note">记忆暂时无法加载</p>'; }
}

async function sendMessage(content) {
  const clean = content.trim();
  if (!clean || state.sending) return;
  state.sending = true;
  sendButton.disabled = true;
  inputEl.value = '';
  inputEl.style.height = 'auto';
  state.messages.push({ id: `user-${Date.now()}`, role: 'user', content: clean, status: 'sent' });
  renderMessages();
  setWorkflowActive(0);
  showTyping();
  try {
    setWorkflowActive(1);
    const response = await fetch('/api/chat', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ user_id: state.userId, message: clean, mode: state.mode, companion_alias: state.companionAlias }) });
    if (!response.ok) throw new Error('chat request failed');
    const data = await response.json();
    setWorkflowActive(4);
    document.querySelector('#typing-indicator')?.remove();
    state.messages.push({ id: `assistant-${Date.now()}`, role: 'assistant', content: String(data.reply || '我在。'), status: 'sent' });
    if (window.speechSynthesis && data.reply) { const utterance = new SpeechSynthesisUtterance(String(data.reply)); utterance.lang = 'zh-CN'; window.speechSynthesis.cancel(); window.speechSynthesis.speak(utterance); }
    if (data.safety_notice) document.querySelector('#usage-notice').textContent = '如有现实危险，请立即联系当地急救或心理援助热线';
    else if (data.usage_notice) document.querySelector('#usage-notice').textContent = data.usage_notice;
    updateInsights(data);
    setRuntime(true, 'API 已连接');
  } catch (error) {
    document.querySelector('#typing-indicator')?.remove();
    setRuntime(false, 'API 未连接');
    state.messages.push({ id: `assistant-${Date.now()}`, role: 'assistant', content: '现在还没连上后端。启动 API 后再来找我。', status: 'sent' });
  } finally {
    state.sending = false;
    sendButton.disabled = false;
    renderMessages();
    setTimeout(() => setWorkflowActive(0), 700);
  }
}

document.querySelector('#composer').addEventListener('submit', (event) => { event.preventDefault(); sendMessage(inputEl.value); });
inputEl.addEventListener('input', () => { inputEl.style.height = 'auto'; inputEl.style.height = `${Math.min(inputEl.scrollHeight, 110)}px`; });
inputEl.addEventListener('keydown', (event) => { if ((event.metaKey || event.ctrlKey) && event.key === 'Enter') { event.preventDefault(); sendMessage(inputEl.value); } });
document.querySelectorAll('[data-prompt]').forEach((button) => button.addEventListener('click', () => { inputEl.value = button.dataset.prompt; inputEl.focus(); inputEl.dispatchEvent(new Event('input')); }));
document.querySelectorAll('[data-mode]').forEach((button) => button.addEventListener('click', () => {
  state.mode = button.dataset.mode;
  syncModeButtons();
  fetch('/api/preferences', { method: 'PUT', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ user_id: state.userId, mode: state.mode, companion_alias: state.companionAlias, skin_id: document.querySelector('#skin-select').value, reminder_frequency: document.querySelector('#reminder-frequency').value }) }).catch(() => {});
}));
document.querySelector('#save-alias').addEventListener('click', () => {
  const alias = document.querySelector('#companion-alias').value.trim() || '小屿';
  state.companionAlias = alias.slice(0, 32);
  localStorage.setItem('xinyu-companion-alias', state.companionAlias);
  document.querySelector('#companion-alias').value = state.companionAlias;
  document.querySelector('#connection-hint').textContent = `称呼已保存为“${state.companionAlias}”`;
});
document.querySelector('#skin-select').addEventListener('change', async (event) => {
  try { await fetch('/api/preferences', { method: 'PUT', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ user_id: state.userId, mode: state.mode, companion_alias: state.companionAlias, skin_id: event.target.value, reminder_frequency: 'standard' }) }); } catch (_) {}
});
document.querySelector('#reminder-frequency').addEventListener('change', async (event) => {
  try { await fetch('/api/preferences', { method: 'PUT', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ user_id: state.userId, mode: state.mode, companion_alias: state.companionAlias, skin_id: document.querySelector('#skin-select').value, reminder_frequency: event.target.value }) }); } catch (_) {}
});
document.querySelector('#memory-refresh').addEventListener('click', loadMemories);

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
document.querySelector('#voice-input').addEventListener('click', () => {
  if (!SpeechRecognition) { document.querySelector('#connection-hint').textContent = '当前浏览器不支持语音输入'; return; }
  const recognition = new SpeechRecognition(); recognition.lang = 'zh-CN'; recognition.interimResults = false;
  recognition.onresult = (event) => { inputEl.value = event.results[0][0].transcript; inputEl.dispatchEvent(new Event('input')); };
  recognition.start();
});
document.querySelector('#refresh-button').addEventListener('click', loadHistory);
loadHistory();
loadSkins();
loadMemories();

let activeSeconds = 0;
setInterval(() => {
  if (document.visibilityState === 'visible') activeSeconds += 60;
  if (activeSeconds >= 60) {
    const seconds = activeSeconds; activeSeconds = 0;
    fetch('/api/session', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ user_id: state.userId, active_seconds: seconds }) }).catch(() => {});
  }
}, 60000);
