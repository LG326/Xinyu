"""FastAPI 依赖和用户输入规范化。"""

from __future__ import annotations

from typing import Annotated

from fastapi import Depends, Header, HTTPException, Request

from .auth import AuthAccount, AuthStore
from .services import BackendServices


def get_services(request: Request) -> BackendServices:
    services = getattr(request.app.state, "services", None)
    if services is None:
        detail = getattr(request.app.state, "startup_error", "服务尚未就绪")
        raise HTTPException(status_code=503, detail=detail)
    return services


def normalize_user_id(user_id: str) -> str:
    return user_id.strip() or "default_user"


def get_auth_store(request: Request) -> AuthStore:
    store = getattr(request.app.state, "auth_store", None)
    if store is None:
        raise HTTPException(status_code=503, detail="认证服务尚未就绪")
    return store


def current_account(request: Request, authorization: str | None = Header(default=None)) -> AuthAccount:
    auth_store = get_auth_store(request)
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="请先登录")
    account = auth_store.get_account_by_token(authorization[7:].strip())
    if account is None:
        raise HTTPException(status_code=401, detail="登录已过期，请重新登录")
    return account


CurrentAccount = Annotated[AuthAccount, Depends(current_account)]
