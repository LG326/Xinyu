"""后端运行配置。

配置只从环境变量读取，避免把部署细节散落在路由和业务代码中。
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

from config import get_model_profile


@dataclass(frozen=True)
class Settings:
    app_name: str = "心屿 API"
    app_version: str = "2.0.0"
    api_prefix: str = "/api"
    sqlite_path: Path = Path("data/xinyu.sqlite3")
    chroma_path: Path = Path("data/xinyu_chroma")
    cors_origins: tuple[str, ...] = ()
    provider: str = "deepseek"
    model_name: str = ""

    @classmethod
    def from_env(cls) -> "Settings":
        load_dotenv()
        provider = os.getenv("MODEL_PROVIDER", "deepseek").strip().lower()
        try:
            _, profile = get_model_profile()
        except RuntimeError:
            # 让应用先启动并暴露 degraded/ready 状态，便于编排系统报告配置错误。
            profile = None
        origins = tuple(
            origin.strip()
            for origin in os.getenv("CORS_ORIGINS", "").split(",")
            if origin.strip()
        )
        return cls(
            sqlite_path=Path(os.getenv("SQLITE_PATH", "data/xinyu.sqlite3")),
            chroma_path=Path(os.getenv("CHROMA_PATH", "data/xinyu_chroma")),
            cors_origins=origins,
            provider=provider,
            model_name=profile.model_name if profile else "unknown",
        )
