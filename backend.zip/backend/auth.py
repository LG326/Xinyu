"""Independent account registration, password verification, and bearer sessions."""

from __future__ import annotations

import base64
import hashlib
import hmac
import re
import secrets
import sqlite3
import uuid
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path


USERNAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{2,31}$")
PBKDF2_ITERATIONS = 210_000
SESSION_DAYS = 30


@dataclass(frozen=True)
class AuthAccount:
    id: str
    username: str
    display_name: str


class AuthStore:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path)
        connection.row_factory = sqlite3.Row
        return connection

    def _initialize(self) -> None:
        with self._connect() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS auth_accounts (
                    id TEXT PRIMARY KEY,
                    username TEXT NOT NULL UNIQUE COLLATE NOCASE,
                    display_name TEXT NOT NULL,
                    password_hash TEXT,
                    is_guest INTEGER NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL,
                    last_login_at TEXT
                );
                CREATE TABLE IF NOT EXISTS auth_sessions (
                    token_hash TEXT PRIMARY KEY,
                    account_id TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY (account_id) REFERENCES auth_accounts(id) ON DELETE CASCADE
                );
                CREATE INDEX IF NOT EXISTS idx_auth_sessions_account
                    ON auth_sessions(account_id);
                """
            )

    @staticmethod
    def validate_username(username: str) -> str:
        value = username.strip()
        if not USERNAME_RE.fullmatch(value):
            raise ValueError("账号需为 3-32 位字母、数字、下划线或短横线")
        return value.lower()

    @staticmethod
    def validate_password(password: str) -> str:
        if len(password) < 8 or len(password) > 128:
            raise ValueError("密码长度需为 8-128 位")
        return password

    @staticmethod
    def _hash_password(password: str) -> str:
        salt = secrets.token_bytes(16)
        digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, PBKDF2_ITERATIONS)
        return "pbkdf2_sha256${}${}${}".format(
            PBKDF2_ITERATIONS,
            base64.urlsafe_b64encode(salt).decode(),
            base64.urlsafe_b64encode(digest).decode(),
        )

    @staticmethod
    def _verify_password(password: str, encoded: str | None) -> bool:
        try:
            algorithm, iterations, salt_text, digest_text = (encoded or "").split("$", 3)
            if algorithm != "pbkdf2_sha256":
                return False
            salt = base64.urlsafe_b64decode(salt_text.encode())
            expected = base64.urlsafe_b64decode(digest_text.encode())
            actual = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, int(iterations))
            return hmac.compare_digest(actual, expected)
        except (ValueError, TypeError):
            return False

    @staticmethod
    def _account_from_row(row: sqlite3.Row) -> AuthAccount:
        return AuthAccount(id=row["id"], username=row["username"], display_name=row["display_name"])

    def register(self, username: str, password: str, display_name: str) -> AuthAccount:
        username = self.validate_username(username)
        password = self.validate_password(password)
        display_name = display_name.strip()[:32] or username
        now = datetime.now(timezone.utc).isoformat(timespec="seconds")
        account_id = f"account_{uuid.uuid4().hex}"
        try:
            with self._connect() as connection:
                connection.execute(
                    "INSERT INTO auth_accounts (id, username, display_name, password_hash, created_at) VALUES (?, ?, ?, ?, ?)",
                    (account_id, username, display_name, self._hash_password(password), now),
                )
        except sqlite3.IntegrityError as exc:
            raise ValueError("这个账号名已经被使用") from exc
        return AuthAccount(account_id, username, display_name)

    def authenticate(self, username: str, password: str) -> AuthAccount:
        username = self.validate_username(username)
        with self._connect() as connection:
            row = connection.execute(
                "SELECT * FROM auth_accounts WHERE username = ? COLLATE NOCASE AND is_guest = 0",
                (username,),
            ).fetchone()
            if row is None or not self._verify_password(password, row["password_hash"]):
                raise ValueError("账号名或密码不正确")
            now = datetime.now(timezone.utc).isoformat(timespec="seconds")
            connection.execute("UPDATE auth_accounts SET last_login_at = ? WHERE id = ?", (now, row["id"]))
        return self._account_from_row(row)

    def create_guest(self) -> AuthAccount:
        now = datetime.now(timezone.utc).isoformat(timespec="seconds")
        account_id = f"guest_{uuid.uuid4().hex}"
        username = f"guest_{secrets.token_hex(5)}"
        with self._connect() as connection:
            connection.execute(
                "INSERT INTO auth_accounts (id, username, display_name, is_guest, created_at, last_login_at) VALUES (?, ?, ?, 1, ?, ?)",
                (account_id, username, "游客", now, now),
            )
        return AuthAccount(account_id, username, "游客")

    def create_session(self, account: AuthAccount) -> str:
        token = secrets.token_urlsafe(32)
        now = datetime.now(timezone.utc)
        expires = now + timedelta(days=SESSION_DAYS)
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        with self._connect() as connection:
            connection.execute("DELETE FROM auth_sessions WHERE expires_at <= ?", (now.isoformat(),))
            connection.execute(
                "INSERT INTO auth_sessions (token_hash, account_id, expires_at, created_at) VALUES (?, ?, ?, ?)",
                (token_hash, account.id, expires.isoformat(timespec="seconds"), now.isoformat(timespec="seconds")),
            )
        return token

    def get_account_by_token(self, token: str) -> AuthAccount | None:
        if not token:
            return None
        now = datetime.now(timezone.utc).isoformat()
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        with self._connect() as connection:
            row = connection.execute(
                "SELECT a.* FROM auth_sessions s JOIN auth_accounts a ON a.id = s.account_id WHERE s.token_hash = ? AND s.expires_at > ?",
                (token_hash, now),
            ).fetchone()
        return self._account_from_row(row) if row else None

    def revoke(self, token: str) -> None:
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        with self._connect() as connection:
            connection.execute("DELETE FROM auth_sessions WHERE token_hash = ?", (token_hash,))
