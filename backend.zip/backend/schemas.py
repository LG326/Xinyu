"""HTTP 请求模型和稳定的响应模型。"""

from __future__ import annotations

from pydantic import BaseModel, Field, field_validator


class ChatRequest(BaseModel):
    user_id: str = Field(default="default_user", min_length=1, max_length=64)
    message: str = Field(..., min_length=1, max_length=4000)
    mode: str = Field(default="reality", pattern="^(reality|dimensional)$")
    companion_alias: str = Field(default="小屿", min_length=1, max_length=32)
    skin_id: str = Field(default="island", min_length=1, max_length=32)

    @field_validator("message")
    @classmethod
    def message_must_contain_text(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("message 不能为空")
        return value


class PreferencesRequest(BaseModel):
    user_id: str = Field(default="default_user", min_length=1, max_length=64)
    mode: str = Field(default="reality", pattern="^(reality|dimensional)$")
    companion_alias: str = Field(default="小屿", min_length=1, max_length=32)
    skin_id: str = Field(default="island", min_length=1, max_length=32)
    reminder_frequency: str = Field(default="standard", pattern="^(low|standard|high)$")


class SessionRequest(BaseModel):
    user_id: str = Field(default="default_user", min_length=1, max_length=64)
    active_seconds: int = Field(default=0, ge=0, le=86400)


class InteractionRequest(BaseModel):
    user_id: str = Field(default="default_user", min_length=1, max_length=64)
    event_type: str = Field(..., min_length=1, max_length=64)
    payload: str = Field(default="", max_length=500)


class MemoryUpdateRequest(BaseModel):
    user_id: str = Field(default="default_user", min_length=1, max_length=64)
    content: str = Field(..., min_length=1, max_length=500)

    @field_validator("content")
    @classmethod
    def content_must_contain_text(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("content 不能为空")
        return value


class AuthRegisterRequest(BaseModel):
    username: str = Field(..., min_length=3, max_length=32)
    password: str = Field(..., min_length=8, max_length=128)
    display_name: str = Field(default="", max_length=32)


class AuthLoginRequest(BaseModel):
    username: str = Field(..., min_length=3, max_length=32)
    password: str = Field(..., min_length=8, max_length=128)
