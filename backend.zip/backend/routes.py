"""心屿 API 路由。"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Path, Query, Request

from experience import list_skins, story_snapshot
from persona import mode_label

from .auth import AuthAccount, AuthStore
from .dependencies import CurrentAccount, get_auth_store, get_services
from .schemas import (
    AuthLoginRequest,
    AuthRegisterRequest,
    ChatRequest,
    InteractionRequest,
    MemoryUpdateRequest,
    PreferencesRequest,
    SessionRequest,
)
from .services import BackendServices

logger = logging.getLogger("xinyu.api")
router = APIRouter()
Service = Annotated[BackendServices, Depends(get_services)]


def _account_response(account: AuthAccount, token: str) -> dict[str, object]:
    return {
        "token": token,
        "account": {"id": account.id, "username": account.username, "display_name": account.display_name},
    }


@router.post("/api/auth/register", tags=["auth"])
def register(request: AuthRegisterRequest, auth_store: AuthStore = Depends(get_auth_store)) -> dict[str, object]:
    try:
        account = auth_store.register(request.username, request.password, request.display_name)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return _account_response(account, auth_store.create_session(account))


@router.post("/api/auth/login", tags=["auth"])
def login(request: AuthLoginRequest, auth_store: AuthStore = Depends(get_auth_store)) -> dict[str, object]:
    try:
        account = auth_store.authenticate(request.username, request.password)
    except ValueError as exc:
        raise HTTPException(status_code=401, detail=str(exc)) from exc
    return _account_response(account, auth_store.create_session(account))


@router.post("/api/auth/guest", tags=["auth"])
def guest(auth_store: AuthStore = Depends(get_auth_store)) -> dict[str, object]:
    account = auth_store.create_guest()
    return _account_response(account, auth_store.create_session(account))


@router.get("/api/auth/me", tags=["auth"])
def me(account: CurrentAccount) -> dict[str, object]:
    return {"account": {"id": account.id, "username": account.username, "display_name": account.display_name}}


@router.post("/api/auth/logout", tags=["auth"])
def logout(request: Request, account: CurrentAccount) -> dict[str, bool]:
    header = request.headers.get("authorization", "")
    if header.lower().startswith("bearer "):
        get_auth_store(request).revoke(header[7:].strip())
    return {"logged_out": True}


def _inactivity_notice(last_interaction_at: str | None, mode: str) -> str:
    """Provide a lightweight prompt hint for the island's return letter."""
    if mode != "reality" or not last_interaction_at:
        return "无"
    try:
        last = datetime.fromisoformat(last_interaction_at)
    except ValueError:
        return "无"
    now = datetime.now(last.tzinfo) if last.tzinfo else datetime.now()
    if (now - last).total_seconds() < 72 * 3600:
        return "无"
    days = max(3, int((now - last).total_seconds() // 86400))
    return f"用户约 {days} 天未上线，请用一封简短的岛屿来信迎接，不施加回访压力。"


@router.get("/health", include_in_schema=False)
def health(request: Request) -> dict[str, object]:
    settings = request.app.state.settings
    ready = getattr(request.app.state, "services", None) is not None
    return {
        "status": "ok" if ready else "degraded",
        "ready": ready,
        "provider": settings.provider,
        "model": settings.model_name,
    }


@router.get("/ready", tags=["system"])
def readiness(request: Request) -> dict[str, object]:
    """只有模型、数据库和工作流初始化成功时才返回 200。"""
    if getattr(request.app.state, "services", None) is None:
        raise HTTPException(
            status_code=503,
            detail=getattr(request.app.state, "startup_error", "服务尚未就绪"),
        )
    return {"status": "ready"}


@router.get("/", tags=["system"])
def service_info(request: Request) -> dict[str, object]:
    """返回服务元信息；前端资源不由后端托管。"""
    settings = request.app.state.settings
    return {
        "service": "xinyu-backend",
        "name": settings.app_name,
        "version": settings.app_version,
        "api_prefix": settings.api_prefix,
        "documentation": "/docs",
        "health": "/health",
    }


@router.get("/api/health", tags=["system"])
def api_health(request: Request) -> dict[str, object]:
    return health(request)


@router.get("/api/history", tags=["conversation"])
def history(services: Service, account: CurrentAccount) -> dict[str, object]:
    user_id = account.id
    profile = services.memory_store.get_profile(user_id)
    messages = [
        {
            "id": f"history-{index}",
            "role": "user" if message.type == "human" else "assistant",
            "content": message.content,
            "status": "sent",
        }
        for index, message in enumerate(
            services.memory_store.load_history(user_id, limit=40)
        )
    ]
    return {
        "messages": messages,
        "bond_value": float(profile.bond_value),
        "mode": profile.mode,
        "mode_label": mode_label(profile.mode),
        "companion_alias": profile.companion_alias,
        "skin_id": profile.skin_id,
        "reminder_frequency": profile.reminder_frequency,
        "intimacy": float(profile.bond_value),
    }


@router.post("/api/chat", tags=["conversation"])
def chat(request: ChatRequest, services: Service, account: CurrentAccount) -> dict[str, object]:
    message = request.message.strip()
    user_id = account.id
    profile = services.memory_store.get_profile(user_id)
    services.memory_store.database.set_preferences(
        user_id,
        mode=request.mode,
        companion_alias=request.companion_alias,
        skin_id=request.skin_id,
    )
    profile = services.memory_store.get_profile(user_id)
    state = {
        "user_input": message,
        "history": services.memory_store.load_history(user_id),
        "bond_value": profile.bond_value,
        "mode": request.mode,
        "current_mode": mode_label(request.mode),
        "companion_alias": request.companion_alias,
        "skin_id": request.skin_id,
        "story_progress": profile.story_progress,
        "mode_label": mode_label(request.mode),
        "current_time": datetime.now().astimezone().strftime("%Y-%m-%d %H:%M"),
        "last_interaction_at": profile.last_interaction_at or "",
        "inactivity_notice": _inactivity_notice(profile.last_interaction_at, request.mode),
    }
    try:
        with services.workflow_lock:
            result = services.workflow.invoke(
                state,
                config={
                    "configurable": {
                        "chat_model": services.chat_model,
                        "memory_store": services.memory_store,
                        "user_id": user_id,
                    }
                },
            )
    except Exception as exc:
        logger.exception("chat workflow failed for user_id=%s", user_id)
        raise HTTPException(status_code=502, detail="模型服务暂时不可用") from exc
    usage = services.memory_store.database.get_usage_stats(user_id)
    limits = {"low": (30, 120), "standard": (20, 80), "high": (10, 50)}
    hour_limit, day_limit = limits.get(profile.reminder_frequency, limits["standard"])
    usage_notice = (
        ""
        if usage["last_hour_messages"] < hour_limit
        and usage["today_messages"] < day_limit
        else "你今天已经聊了不少，先休息一下，喝水、吃饭或联系现实中的人吧。"
    )
    bond_value = float(result.get("bond_value", profile.bond_value))
    bond_delta = float(result.get("bond_delta", 0.0))
    return {
        "reply": result["response"],
        "bond_value": bond_value,
        "bond_delta": bond_delta,
        "emotion": result.get("emotion", "平静"),
        "risk_level": result.get("risk_level", "none"),
        "safety_notice": result.get("safety_notice", ""),
        "usage_notice": usage_notice,
        "usage_stats": usage,
        "story": story_snapshot(
            services.memory_store.get_profile(user_id).story_progress
        ),
        "intimacy": bond_value,
        "intimacy_delta": bond_delta,
        "mode": request.mode,
        "mode_label": mode_label(request.mode),
        "memory_event": result.get("memory_event", ""),
        "interaction_event": result.get("interaction_event", ""),
        "command": result.get("command", ""),
        "simulation": bool(result.get("simulation_requested", False)),
    }


@router.get("/api/skins", tags=["catalog"])
def skins() -> dict[str, object]:
    return {"skins": list_skins()}


@router.get("/api/preferences", tags=["profile"])
def preferences(services: Service, account: CurrentAccount) -> dict[str, object]:
    profile = services.memory_store.get_profile(account.id)
    return {
        "user_id": profile.user_id,
        "mode": profile.mode,
        "mode_label": mode_label(profile.mode),
        "companion_alias": profile.companion_alias,
        "skin_id": profile.skin_id,
        "reminder_frequency": profile.reminder_frequency,
    }


@router.put("/api/preferences", tags=["profile"])
def update_preferences(
    request: PreferencesRequest, services: Service, account: CurrentAccount
) -> dict[str, object]:
    user_id = account.id
    services.memory_store.get_profile(user_id)
    services.memory_store.database.set_preferences(
        user_id,
        mode=request.mode,
        companion_alias=request.companion_alias,
        skin_id=request.skin_id,
        reminder_frequency=request.reminder_frequency,
    )
    profile = services.memory_store.get_profile(user_id)
    return {
        "user_id": profile.user_id,
        "mode": profile.mode,
        "mode_label": mode_label(profile.mode),
        "companion_alias": profile.companion_alias,
        "skin_id": profile.skin_id,
        "reminder_frequency": profile.reminder_frequency,
    }


@router.get("/api/memories", tags=["memory"])
def memories(
    services: Service,
    account: CurrentAccount,
    limit: int = Query(50, ge=1, le=200),
) -> dict[str, object]:
    return {
        "memories": services.memory_store.list_memories(
            account.id, limit
        )
    }


@router.delete("/api/memories/{memory_id}", tags=["memory"])
def delete_memory(
    services: Service,
    account: CurrentAccount,
    memory_id: int = Path(..., ge=1),
) -> dict[str, bool]:
    return {
        "deleted": services.memory_store.delete_memory(
            account.id, memory_id
        )
    }


@router.patch("/api/memories/{memory_id}", tags=["memory"])
def update_memory(
    services: Service,
    account: CurrentAccount,
    request: MemoryUpdateRequest,
    memory_id: int = Path(..., ge=1),
) -> dict[str, bool]:
    return {
        "updated": services.memory_store.update_memory(
            account.id, memory_id, request.content
        )
    }


@router.post("/api/session", tags=["profile"])
def record_session(request: SessionRequest, services: Service, account: CurrentAccount) -> dict[str, object]:
    user_id = account.id
    profile = services.memory_store.get_profile(user_id)
    services.memory_store.database.add_active_seconds(user_id, request.active_seconds)
    return {
        "total_active_seconds": services.memory_store.get_profile(
            user_id
        ).total_active_seconds,
        "reminder_frequency": profile.reminder_frequency,
    }


@router.get("/api/story", tags=["story"])
def story(services: Service, account: CurrentAccount) -> dict[str, object]:
    return story_snapshot(
        services.memory_store.get_profile(account.id).story_progress
    )


@router.get("/api/interactions", tags=["analytics"])
def interactions(
    services: Service,
    account: CurrentAccount,
    limit: int = Query(50, ge=1, le=200),
) -> dict[str, object]:
    return {
        "events": services.memory_store.database.list_interactions(
            account.id, limit
        )
    }


@router.post("/api/interactions", tags=["analytics"])
def record_interaction(
    request: InteractionRequest, services: Service, account: CurrentAccount
) -> dict[str, bool]:
    user_id = account.id
    services.memory_store.get_profile(user_id)
    services.memory_store.database.record_interaction(
        user_id, request.event_type, request.payload
    )
    return {"recorded": True}
