"""FastAPI 应用工厂。

前端由独立的 Vite/Nginx 服务部署；本应用只提供 JSON API。
"""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .routes import router
from .auth import AuthStore
from .services import create_services
from .settings import Settings

logger = logging.getLogger("xinyu.api")


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or Settings.from_env()

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        try:
            app.state.services = create_services(settings)
            app.state.startup_error = None
        except Exception as exc:
            app.state.services = None
            app.state.startup_error = "模型服务配置不完整，聊天接口暂不可用"
            logger.exception("backend startup failed")
        yield
        app.state.services = None

    app = FastAPI(
        title=settings.app_name,
        version=settings.app_version,
        lifespan=lifespan,
        description="心屿健康陪伴智能体的 JSON API。前端资源由独立服务托管。",
    )
    app.state.settings = settings
    app.state.auth_store = AuthStore(settings.sqlite_path)
    app.state.services = None
    app.state.startup_error = None
    if settings.cors_origins:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=list(settings.cors_origins),
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )
    app.include_router(router)
    return app


app = create_app()
