"""应用服务容器。

路由不直接创建模型、数据库或工作流，便于测试、替换实现和控制资源生命周期。
"""

from __future__ import annotations

from dataclasses import dataclass
from threading import Lock

from memory_store import MemoryStore
from model_factory import build_chat_model
from workflow import build_workflow

from .settings import Settings


@dataclass
class BackendServices:
    memory_store: MemoryStore
    chat_model: object
    workflow: object
    workflow_lock: Lock


@dataclass
class AccountServices:
    auth_store: AuthStore


def create_services(settings: Settings) -> BackendServices:
    """创建一组进程级共享服务。"""
    return BackendServices(
        memory_store=MemoryStore(settings.sqlite_path, settings.chroma_path),
        chat_model=build_chat_model(_model_profile(settings)),
        workflow=build_workflow(),
        workflow_lock=Lock(),
    )


def _model_profile(settings: Settings):
    from config import MODEL_PROFILES

    return MODEL_PROFILES[settings.provider]
